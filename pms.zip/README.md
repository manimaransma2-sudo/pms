# Parayar Maha Sabai Community Portal

A standalone public website and small Node.js backend/dashboard for Parayar Maha Sabai. It is kept separate from the Raid Action Wing application and does not import RAWF pages, branding or records.

The page structure takes inspiration from the existing site's clear hero, navigation, service directory, initiatives, membership, request-tracking and administrator areas. The content, identity, colours and workflows here are rewritten for Parayar Maha Sabai's community and education mission; RAWF's law-enforcement branding and claims are not carried over.

## Start locally

Requirements: Node.js 20 or newer. No package installation is required.

```powershell
cd D:\pms\raidactionwing\parayarmahasabai\website-system
Copy-Item .env.example .env
```

Set a local admin password, then start the portal:

```powershell
$env:ADMIN_USERNAME = "admin"
$env:ADMIN_PASSWORD = "choose-a-long-local-password"
node --env-file=.env server.mjs
```

Open `http://localhost:4173`. Visit **Admin** in the top utility bar to sign in. For a local-only quick preview, the server prints its demo password (`pms-local-demo`) when `ADMIN_PASSWORD` is not set. Do not use that demo password for a deployment.

Node 20.6+ loads local settings from `.env` with the command above. The example file includes the SMTP host, port and mailbox name; add the mailbox password only to your ignored local `.env` file. Never publish `.env`.

Run the backend and API tests with:

```powershell
npm test
```

## Included features

- Responsive public homepage using the supplied Parayar Maha Sabai emblem and banner.
- Mission and community-work pages based on the seven goals in the supplied website-details image: unity, awareness, arts/culture, education/employment, social/economic progress, quality of life and civic participation.
- Searchable Tamil Nadu public-service library with 18 practical guides, eligibility context, suggested document checklists, process steps and direct links to government portals. Guides include a link to the complete live e-Sevai catalogue (which currently describes 119 certificate/licence services), e-Sevai certificates, patta/Chitta, ration-card services, birth/death records, school education, scholarships, RTE, Naan Mudhalvan, TNPSC, welfare, disability certification, the CM Helpline and voter services.
- Bilingual English/Tamil membership registration using the supplied form fields, with separate required Tamil name, parent/spouse name and full address inputs, ₹500 UPI payment instructions/QR, member number assignment at registration, a printable photo ID card and public reference tracking.
- Tamil name and address inputs include up to 16 offline English-to-Tamil phonetic suggestions, including alternate Tamil vowels and consonants such as ன் / ண் / ந் and ல் / ள் / ழ். A Tamil address draft is generated from English address fields for review, and older records without a Tamil address show a transliterated draft on the card. The card back displays Tamil and English versions of ward, local-body type/name, Assembly and Parliament constituency fields.
- Homepage membership-card download: members enter their membership number and registered email, receive a time-limited one-time verification code by SMTP, and download a two-page PDF card after verification. Both admin print and member download use the supplied 640×1018 front/back artwork and the replacement 2317×580 front footer without stretching; the front barcode encodes the member number and the white “7” uses the supplied `assets-reference\id-card-front-7.png`, while the back displays the full logo as a transparent watermark. Tamil name and address lines use the member-provided Tamil-script fields; labels include Tamil and English, dates include Tamil numerals, and Aadhaar is never printed.
- All successful registrations become active members immediately; UPI references remain pending until an administrator verifies the payment in the dashboard. Entering a UTR alone does not establish payment.
- Membership address fields follow a consistent sequence: district, revenue taluk, local-government type/name, ward, Assembly constituency, Parliament constituency, PIN code, then street and village/area details. The form includes all 234 Tamil Nadu Assembly constituencies, all 39 Parliament constituencies and their current Assembly-to-Parliament mapping; selecting an Assembly constituency preselects its corresponding Parliament constituency, and the server rejects mismatched pairs.
- Selecting a district filters its taluk list; selecting a local-government type reveals only its matching corporation, municipality, town-panchayat or village-panchayat field. Unlisted taluks can be entered manually.
- The PIN lookup searches 11,878 Tamil Nadu post-office records by PIN, post-office name, taluk or postal district. It is a lookup aid, not an address-boundary validator: postal districts may differ from current revenue districts, and multiple offices can share a PIN. Members can enter any six-digit PIN manually if it is not in the snapshot, and should confirm current details against their postal records.
- Admin sign-in, session-protected dashboard, member/payment review, support-request status updates and printable member ID cards. Admin accounts are separate from member accounts.
- Persistent records in `data\records.json`, outside the public web root.
- Optional MySQL persistence for cPanel deployments; set all of `DB_HOST`, `DB_NAME`, `DB_USER` and `DB_PASSWORD` to enable it. The application creates a private InnoDB state table and serializes updates transactionally.
- Server-side field validation, image-size/type checks, request-size limit, sign-in throttling, security headers and production password/encryption-key enforcement.

### Email verification setup

The local `.env.example` has the supplied SMTP host, SSL port and mailbox name. Put the mailbox password in the ignored local `.env` file to enable membership-card OTP emails; never put it in browser code or a committed file. When SMTP settings are missing, the card-download form reports that verification is unavailable rather than bypassing email verification.

### cPanel deployment

The ready-to-upload Node.js package and cPanel setup instructions are in `cpanel_deplay\`. It requires a cPanel host that supports Node.js applications (Node 20+) and MySQL. Set database, SMTP, administrator and encryption-key values in the cPanel application's private environment settings; never upload a populated `.env` file. See the deployment README for database initialization and photo/card notes.

### Address lookup data

- The Assembly/Parliament list and crosswalk represent the current 2008 delimitation arrangement (234 Assembly segments mapped once each to 39 Parliament constituencies). Names are based on constituency indexes and segment listings available on [Wikipedia's Tamil Nadu constituency categories](https://en.wikipedia.org/wiki/Category:Assembly_constituencies_of_Tamil_Nadu) and [Tamil Nadu Lok Sabha constituency category](https://en.wikipedia.org/wiki/Category:Lok_Sabha_constituencies_in_Tamil_Nadu), cross-checked for 234/39 coverage on 2026-10-21. Constituency boundaries and names can change through official delimitation or renaming; verify against Election Commission records before relying on them for official work.
- The postal snapshot contains Tamil Nadu post-office records from the All India PIN directory distributed via [data.gov.in](https://www.data.gov.in/) (snapshot downloaded 2026-10-21; source mirror: [India-Pincode-Lookup](https://github.com/mithunsasidharan/India-Pincode-Lookup)). Postal records are offered as suggestions only; they do not determine the member's Assembly or Parliament constituency.

## Service information and privacy

Service steps are general navigation help, not legal or scheme determinations. Government eligibility, accepted documents, timelines, application windows and fees change; users should confirm the current notice on the linked official portal or at an authorised service centre. Parayar Maha Sabai is an independent community organisation and cannot issue government certificates, approve benefits or modify government application records.

The supplied `front-idcard.png` and `back-idcard.png` include personal identity/contact details. The public templates retain the artwork but remove those sample member details before publication. A fresh member card is generated from each member's registration details and uploaded photograph; Aadhaar is optional, encrypted at rest, never exposed in dashboard API responses and never printed. If an existing member has no saved photograph, the front photo frame remains blank without printing a placeholder. The supplied membership payment QR is published with the user's approval and is used for the ₹500 membership payment instructions.

Membership and support-request records contain personal contact information. Uploaded photos and optional Aadhaar numbers are encrypted using AES-256-GCM before saving. Local development creates a private `data\.encryption-key` automatically. For production, configure `DATA_ENCRYPTION_KEY` with exactly 64 random hexadecimal characters and keep it separate from the data store; losing the key makes encrypted photos/Aadhaar unrecoverable. MySQL credentials are supplied through `DB_HOST`, `DB_NAME`, `DB_USER` and `DB_PASSWORD`. Set a strong administrator password, use HTTPS, limit dashboard access to trusted staff, and arrange secure backups and retention/deletion practices before deployment. The UPI payment recipient is the personal recipient displayed by the supplied QR; payment references must be checked manually in the recipient's UPI/bank records.

## Project layout

```text
website-system\
  data\                 Private runtime records (created automatically)
  public\
    assets\             Public organisation emblem, banner and approved payment QR
    app.js              Public views, service guide data and dashboard UI
    app.css             Responsive styles and printable member ID layout
    constituency-data.js Browser constituency options and Assembly/Parliament crosswalk
    constituency-data.json Server-side constituency validation data
    location-data.js    Tamil Nadu district and taluk options
    postal-directory.json Searchable Tamil Nadu post-office PIN snapshot
    index.html          Site entry point
  test\                  Node built-in API tests
  server.mjs             Static server and JSON API
```
