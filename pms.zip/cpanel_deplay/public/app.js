const services = [
  {
    title: 'Community certificate',
    group: 'E-Sevai',
    category: 'esevai',
    icon: '◈',
    summary: 'Understand the application route for a Tamil Nadu community certificate.',
    eligibility: 'Applicants who need a community certificate for education, employment or another eligible purpose. The competent revenue authority decides eligibility.',
    documents: ['Applicant identity and address proof as listed by the portal', 'Parents’ community certificate or other supporting records, if applicable', 'School or birth records, if requested', 'Mobile number for OTP and application updates'],
    steps: ['Check the current service name, eligibility and required records on the Tamil Nadu e-Sevai portal or at an authorised centre.', 'Register or sign in using the applicant’s own mobile number; choose the relevant certificate service.', 'Complete the form and submit the supporting records requested by the official system.', 'Pay only the fee displayed by the official portal or centre, and keep the acknowledgement number.', 'Track the application using the acknowledgement; download the digitally signed certificate if approved.'],
    portal: 'https://www.tnesevai.tn.gov.in/',
    note: 'Names, accepted evidence and approval timelines can vary by case. The Tahsildar/revenue authority—not this organisation—decides the application.'
  },
  {
    title: 'Income certificate',
    group: 'E-Sevai',
    category: 'esevai',
    icon: '₹',
    summary: 'A practical checklist for requesting a certificate of family income.',
    eligibility: 'Residents applying for an eligible scholarship, concession or public programme that asks for an income certificate.',
    documents: ['Identity and residence proof', 'Income details and supporting evidence, where available', 'Ration card or family particulars, if requested', 'Self-declaration and applicant photograph if the live form requires them'],
    steps: ['Confirm that the receiving institution accepts a Tamil Nadu income certificate and check the validity period they require.', 'Apply through Tamil Nadu e-Sevai or an authorised e-Sevai centre; select the correct applicant and family details.', 'Enter income sources accurately and provide only the evidence requested by the official system.', 'Pay the displayed official service charge, save the receipt and note the acknowledgement number.', 'Track the application and download the certificate after approval.'],
    portal: 'https://www.tnesevai.tn.gov.in/',
    note: 'Do not guess or understate income. The competent revenue authority verifies and decides the application.'
  },
  {
    title: 'Nativity / residence certificate',
    group: 'E-Sevai',
    category: 'esevai',
    icon: '⌂',
    summary: 'Find the appropriate residence or nativity certificate service and prepare evidence.',
    eligibility: 'Tamil Nadu residents whose school, college, employer or government scheme requires the specific certificate.',
    documents: ['Identity and current address proof', 'Records showing residence/history as applicable', 'Parent or guardian records for a minor, if applicable', 'Applicant photograph or declaration if requested'],
    steps: ['Ask the institution which exact certificate it needs; “nativity”, “residence” and “domicile” are not always interchangeable.', 'Check the latest eligibility and evidence list on e-Sevai or with the authorised centre.', 'Submit the application with truthful residence details and requested supporting records.', 'Keep the acknowledgement and track the application through the official service.', 'Download the certificate only after approval and check all printed details.'],
    portal: 'https://www.tnesevai.tn.gov.in/',
    note: 'The issuing authority determines which residence evidence is sufficient.'
  },
  {
    title: 'First graduate certificate',
    group: 'E-Sevai',
    category: 'esevai',
    icon: '1st',
    summary: 'Guidance for families seeking a first-graduate certificate for eligible admissions.',
    eligibility: 'Students whose family may meet the applicable first-graduate criteria; the institution and revenue authority confirm qualification.',
    documents: ['Applicant and family identity/address records', 'Parents’ and siblings’ education particulars or declarations, as requested', 'School transfer / study records if requested', 'Admission or application details, where relevant'],
    steps: ['Check the current rules with the college/admission authority before applying; family eligibility rules matter.', 'Use the e-Sevai portal or an authorised centre and select the currently listed first-graduate service.', 'Enter family members’ education details consistently with their records.', 'Submit only the supporting documents requested; retain the application acknowledgement.', 'Share the approved certificate with the institution before its stated deadline.'],
    portal: 'https://www.tnesevai.tn.gov.in/',
    note: 'Eligibility is based on the current government rules and verified family records, not only on the student’s statement.'
  },
  {
    title: 'Legal heir certificate',
    group: 'E-Sevai',
    category: 'esevai',
    icon: '▤',
    summary: 'A careful starting checklist for the legal-heir certificate process.',
    eligibility: 'Eligible family members applying to the competent revenue authority after a death. Complex disputes may need legal advice.',
    documents: ['Death certificate', 'Applicant identity and residence proof', 'Relationship / family-member evidence requested by the authority', 'Details and declarations for all legal heirs, as required'],
    steps: ['Obtain the official death certificate and confirm which authority/service is appropriate for the case.', 'Check the current document list and whether any heir details or declarations are required.', 'Apply through e-Sevai or the authorised channel and provide complete, accurate family information.', 'Keep the acknowledgement; respond to any verification or document query from the authority.', 'For disputes, omitted heirs or property litigation, seek independent legal advice before relying on a certificate.'],
    portal: 'https://www.tnesevai.tn.gov.in/',
    note: 'This certificate is not a substitute for a court’s decision in a contested succession or property dispute.'
  },
  {
    title: 'Patta, Chitta & land records',
    group: 'Revenue & land',
    category: 'revenue',
    icon: '⌖',
    summary: 'View or verify Tamil Nadu land records and locate application-status options.',
    eligibility: 'Anyone checking records for a land parcel; mutation or correction requests must be made by an eligible applicant.',
    documents: ['Survey number and subdivision number, where known', 'District, taluk and village', 'Patta number or owner details as requested', 'Registered deed and supporting records for a transfer/correction request'],
    steps: ['Open the Tamil Nadu Government e-Services of Land Records portal.', 'Choose the relevant district/taluk/village and enter the survey or patta details requested.', 'Review the online record carefully; a public record search is not a title opinion.', 'For transfer, correction or a record that is not available online, follow the official application route or contact the Tahsildar office.', 'Keep the acknowledgement for any submitted request and track it through the portal.'],
    portal: 'https://eservices.tn.gov.in/eservicesnew/index.html',
    note: 'Online land records do not by themselves establish ownership or resolve boundary/title disputes. Seek a qualified professional for legal review.'
  },
  {
    title: 'Smart ration card services',
    group: 'E-Sevai',
    category: 'esevai',
    icon: '▣',
    summary: 'Find official routes for family-card changes, status and public distribution queries.',
    eligibility: 'Tamil Nadu smart-family-card holders and eligible households applying under the current public distribution rules.',
    documents: ['Existing family-card number for updates', 'Identity and residence details', 'Relevant proof for the requested change (member, address or mobile)', 'Registered mobile for OTP, where required'],
    steps: ['Use the Tamil Nadu Public Distribution System portal or the nearest designated service point.', 'Choose the specific request—such as adding/removing a member, address change or card-status enquiry.', 'Enter card and family details exactly as they appear on official records.', 'Submit the requested evidence and save the acknowledgement/reference.', 'Use the portal’s status or grievance route if the update is delayed.'],
    portal: 'https://www.tnpds.gov.in/',
    note: 'Current eligibility, required documents and available online services are set by the Civil Supplies and Consumer Protection Department.'
  },
  {
    title: 'Birth & death registration',
    group: 'E-Sevai',
    category: 'esevai',
    icon: '＋',
    summary: 'Locate the Tamil Nadu civil-registration route for certificates and record searches.',
    eligibility: 'Parents, family members or authorised applicants requesting a record from the correct local registration jurisdiction.',
    documents: ['Registration number, date and place of event if available', 'Applicant identity and relationship/authorisation details', 'Hospital or local-body details for a registration query', 'Additional records requested for late registration or correction'],
    steps: ['Search the official civil-registration service for the local body and event details.', 'For a registered event, request a certificate/search using the available registration particulars.', 'If no record appears, contact the registrar for the place where the event occurred before making a duplicate application.', 'For delayed registration or a correction, ask the local registrar for the applicable procedure and evidence.', 'Keep the receipt or acknowledgement and verify spellings and dates on the certificate.'],
    portal: 'https://crstn.org/birth_death_tn/',
    note: 'Late registrations and corrections may require an in-person process or additional approval.'
  },
  {
    title: 'Scholarship application support',
    group: 'Education',
    category: 'education',
    icon: '✦',
    summary: 'Prepare for eligible state or centrally sponsored scholarships without missing the institution step.',
    eligibility: 'Eligibility depends on the individual scholarship, course, institution, class, community/income rules and current notice.',
    documents: ['Student identity and bank details in the student’s own name if required', 'Current study / bonafide certificate and previous marks', 'Income, community or nativity certificate only where that scheme asks for it', 'Fee receipt and application/renewal number'],
    steps: ['Ask the school or college scholarship nodal officer which scheme and portal apply to the student.', 'Read that scheme’s current notice for eligibility, amount, documents and deadline.', 'Create or update the student profile using the student’s correct details; avoid duplicate applications.', 'Submit the form and supporting records, then note the application ID.', 'Check both the portal and institution verification status; correct returned applications before the deadline.'],
    portal: 'https://ssp.tn.gov.in/',
    note: 'The scheme portal and deadlines can change. This guide does not promise eligibility or a scholarship award.'
  },
  {
    title: 'School admissions & student support',
    group: 'Education',
    category: 'education',
    icon: '⌂',
    summary: 'Get connected with government-school information, admission support and student services.',
    eligibility: 'Parents/guardians and students seeking information from a Tamil Nadu school or education authority.',
    documents: ['Child’s birth or age proof where required', 'Previous school transfer / study certificate for transfers', 'Parent or guardian identity and contact information', 'Address and category records only if the specific admission scheme asks for them'],
    steps: ['Contact the nearest government school or Block Educational Office for the current admission window and class availability.', 'Ask whether the request is a standard admission, transfer or a separate scheme-based application.', 'Submit the school’s current form and the records it requests; retain a copy of the acknowledgement.', 'For a denied admission or records issue, ask the head teacher first, then use the Block/District education office channel.', 'Use the official school-education portal for published notices and department contacts.'],
    portal: 'https://www.tnschools.gov.in/',
    note: 'Admissions and special-entry routes follow current department notices and local school availability.'
  },
  {
    title: 'RTE 25% admission information',
    group: 'Education',
    category: 'education',
    icon: '25%',
    summary: 'Check the annual Right to Education entry-level admission notice and application window.',
    eligibility: 'Children meeting the age, neighbourhood and other criteria published in the current Tamil Nadu RTE admission notification.',
    documents: ['Child’s date-of-birth proof', 'Address proof showing the eligible neighbourhood', 'Income / community / other eligibility evidence only where the current notice requires it', 'Parent/guardian contact details'],
    steps: ['Read the current annual RTE notification before applying; eligible classes, age cut-offs and dates are set for that year.', 'Use the official Tamil Nadu RTE admission portal when the application window opens.', 'Select schools according to the official distance/eligibility rules and enter details carefully.', 'Upload only the listed evidence and save the acknowledgement.', 'Follow the official selection and document-verification notices; contact the local education office if help is needed.'],
    portal: 'https://www.tnschools.gov.in/',
    note: 'The portal may be active only during the notified annual application period. Selection is handled by the department, not by the Sabai.'
  },
  {
    title: 'Naan Mudhalvan skills & career pathways',
    group: 'Education',
    category: 'education',
    icon: '↗',
    summary: 'Explore state skill-development, career guidance and learning opportunities for students.',
    eligibility: 'Students and young people meeting the eligibility rules for the current course or programme.',
    documents: ['Student profile and current course details', 'Mobile/email for registration', 'Institution information if the course is institution-linked', 'Any prerequisite or identity record listed for that course'],
    steps: ['Explore active courses and announcements on the official Naan Mudhalvan portal.', 'Check the course’s audience, prerequisites, schedule and whether registration is through an institution.', 'Register with accurate contact and education details.', 'Complete any assigned learning or assessment steps and monitor official notices.', 'Contact the school/college coordinator or programme support for access issues.'],
    portal: 'https://naanmudhalvan.tn.gov.in/',
    note: 'Course availability and eligibility are programme-specific; confirm current details before planning.'
  },
  {
    title: 'TNPSC examination & recruitment',
    group: 'Education & jobs',
    category: 'education',
    icon: '✎',
    summary: 'Find official recruitment notices, examination instructions and candidate services.',
    eligibility: 'Applicants who meet the age, qualification, reservation and other criteria in a specific TNPSC notification.',
    documents: ['One-time registration details, if required', 'Educational certificates and mark statements', 'Community / disability / other certificates where claimed and requested', 'Recent photo, signature and payment details as specified in the notice'],
    steps: ['Use the TNPSC site to find the current notification and read it end to end.', 'Check post-wise age, education, reservation, fee exemption and certificate rules.', 'Complete or update the official candidate registration and application before the stated deadline.', 'Pay any fee through the official payment option and save the receipt/application number.', 'Monitor the TNPSC portal for hall-ticket, exam, result and certificate-verification updates.'],
    portal: 'https://www.tnpsc.gov.in/',
    note: 'Only the current examination notification is authoritative. Never share login credentials or pay unofficial intermediaries.'
  },
  {
    title: 'Social welfare scheme information',
    group: 'Welfare',
    category: 'welfare',
    icon: '♡',
    summary: 'Find department information for applicable welfare programmes and local support.',
    eligibility: 'Varies by programme, household circumstances, income and current government rules.',
    documents: ['Identity and residence information', 'Income or community evidence only when a scheme requires it', 'Bank account details only on the official application channel', 'Programme-specific records listed by the department'],
    steps: ['Identify the exact scheme and read its latest eligibility and benefit rules on the department website.', 'Ask the local government office or authorised e-Sevai centre whether the scheme has an online application.', 'Prepare only the required records and submit through the stated official channel.', 'Keep the application receipt and follow the department’s verification or appeal process.', 'If uncertain, contact the District Social Welfare Office before sharing personal information.'],
    portal: 'https://www.tnsocialwelfare.tn.gov.in/',
    note: 'The Sabai can help residents understand the route but does not sanction, guarantee or distribute government benefits.'
  },
  {
    title: 'Disability certificate & UDID',
    group: 'Welfare',
    category: 'welfare',
    icon: '◎',
    summary: 'Learn where to apply for disability assessment and a Unique Disability ID.',
    eligibility: 'Persons seeking assessment/registration under the current disability certification process.',
    documents: ['Identity and address proof', 'Recent photograph and contact details', 'Available medical records, if any', 'Any additional information asked by the authorised medical authority'],
    steps: ['Read the official UDID instructions and locate the designated medical authority for the applicant’s district.', 'Register the application using accurate identity and contact details.', 'Submit the documents required by the portal and attend assessment as instructed.', 'Use the official application number to check assessment/card status.', 'For accessibility or portal assistance, contact the district medical authority or helpline listed on the portal.'],
    portal: 'https://www.swavlambancard.gov.in/',
    note: 'Certification and assessment are decided only by the authorised medical board.'
  },
  {
    title: 'Chief Minister’s Helpline',
    group: 'Public help',
    category: 'public',
    icon: '☎',
    summary: 'Submit or follow up a grievance to a Tamil Nadu Government department.',
    eligibility: 'Residents seeking a government response to a public-service grievance covered by the helpline.',
    documents: ['A short, factual description and relevant dates', 'Department/office and location involved', 'Earlier petition or acknowledgement number if available', 'Contact information for follow-up'],
    steps: ['Open the Tamil Nadu CM Helpline portal and choose the relevant grievance route.', 'Describe what happened, where, when and what action you are requesting.', 'Attach only relevant records through the government portal; redact unrelated sensitive details.', 'Save the grievance reference and use the official status/appeal options to follow up.', 'For emergencies or immediate danger, contact the appropriate emergency service instead of waiting for a grievance response.'],
    portal: 'https://cmhelpline.tnega.org/portal/en/home',
    note: 'This Sabai portal is not the CM Helpline and cannot see or change government grievance records.'
  },
  {
    title: 'Voter registration & electoral roll',
    group: 'Public help',
    category: 'public',
    icon: '✓',
    summary: 'Use the Election Commission’s official route to register, update or search voter details.',
    eligibility: 'Indian citizens who meet the current age and electoral-registration requirements.',
    documents: ['Proof of age for first-time enrolment', 'Proof of ordinary residence in the constituency', 'Existing EPIC details for a correction or transfer request', 'A recent photograph if required by the form'],
    steps: ['Use the Election Commission of India’s official Voters’ Service Portal.', 'Choose new enrolment, correction, shifting or electoral-roll search as applicable.', 'Submit accurate information and the evidence listed in the form.', 'Save the application reference and check the portal for verification/status updates.', 'Contact the local Electoral Registration Officer for an appeal or unresolved roll issue.'],
    portal: 'https://voters.eci.gov.in/',
    note: 'Electoral registration is administered by election authorities; the Sabai does not issue voter IDs.'
  },
  {
    title: 'Browse the complete e-Sevai catalogue',
    group: 'E-Sevai',
    category: 'esevai',
    icon: '▤',
    summary: 'Open the live Tamil Nadu e-Sevai catalogue for the full range of currently available certificates and services.',
    eligibility: 'The portal serves citizens seeking an e-Sevai service. Each individual certificate, licence or department service has its own eligibility.',
    documents: ['The name of the service you need', 'Applicant mobile number for portal sign-in or OTP, if required', 'Service-specific documents shown on the official portal or by an authorised centre'],
    steps: ['Open the official Tamil Nadu e-Sevai citizen portal and browse the live service catalogue.', 'Search for the exact service name; check which services can be submitted online and which require an authorised e-Sevai centre.', 'Read that service’s current eligibility, document list and displayed fee before entering personal details.', 'Apply through the official route, retain the acknowledgement and track status in the same portal.', 'If the service is unavailable or the catalogue does not cover your case, contact the relevant department or authorised service centre.'],
    portal: 'https://www.tnesevai.tn.gov.in/',
    note: 'The e-Sevai portal currently describes 119 certificate and licence services. The catalogue and participating services may change; the live official portal is the complete current source.'
  }
];

const focusAreas = [
  ['01', 'Unity & fellowship', 'Build solidarity, mutual respect and a strong community voice.'],
  ['02', 'Awareness & dignity', 'Support awareness, self-confidence and equal participation.'],
  ['03', 'Arts & culture', 'Celebrate community arts, culture, heritage and expression.'],
  ['04', 'Education & opportunity', 'Help learners reach education, skills and meaningful work.'],
  ['05', 'Social & economic progress', 'Encourage wellbeing, livelihoods and inclusive development.'],
  ['06', 'Quality of life', 'Work towards a healthy, secure and hopeful community life.'],
  ['07', 'Civic participation', 'Promote informed, peaceful participation in public life.']
];

const categoryLabels = [
  ['all', 'All guides'],
  ['esevai', 'E-Sevai'],
  ['education', 'Education'],
  ['revenue', 'Revenue & land'],
  ['welfare', 'Welfare'],
  ['public', 'Public help']
];

const pageNames = {
  home: 'Home',
  services: 'Public services',
  education: 'Education',
  community: 'Our work',
  join: 'Membership',
  help: 'Get help',
  admin: 'Admin dashboard'
};

const main = document.getElementById('main-content');
const nav = document.getElementById('primary-nav');
const toastRegion = document.getElementById('toast-region');
let currentPage = pageNames[location.hash.slice(1)] ? location.hash.slice(1) : 'home';
let activeCategory = 'all';
let serviceSearch = '';
let membershipLanguage = 'en';
let lastRegisteredMember = null;
let postalDirectoryPromise = null;
let postalDirectory = null;
let pinSuggestionIndex = -1;
let adminToken = localStorage.getItem('pms_admin_token') || '';
let adminTab = 'members';
let adminMemberSearch = '';
let adminMemberStatusFilter = 'active';
let adminPaymentFilter = 'all';
let dashboardData = null;
let serviceDialog = null;
let idDialog = null;
let idCardMember = null;
let memberDialog = null;
let memberCardChallengeId = '';
let memberCardDownloadToken = '';

function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
}

function formatDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '—' : new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }).format(date);
}

function setActiveNav() {
  nav.querySelectorAll('[data-page]').forEach((link) => {
    link.classList.toggle('is-active', link.dataset.page === currentPage);
  });
}

function closeActiveDialogs() {
  for (const dialog of [serviceDialog, idDialog, memberDialog]) {
    if (dialog?.open) dialog.close();
    dialog?.remove();
  }
  serviceDialog = null;
  idDialog = null;
  memberDialog = null;
}

function goTo(page) {
  if (!pageNames[page]) return;
  if (location.hash.slice(1) !== page) history.pushState(null, '', `#${page}`);
  closeActiveDialogs();
  currentPage = page;
  nav.classList.remove('is-open');
  document.getElementById('menu-toggle').setAttribute('aria-expanded', 'false');
  renderPage();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showToast(message, isError = false) {
  const toast = document.createElement('div');
  toast.className = `toast${isError ? ' is-error' : ''}`;
  toast.textContent = message;
  toastRegion.append(toast);
  window.setTimeout(() => toast.remove(), 4800);
}

async function api(path, options = {}) {
  const headers = new Headers(options.headers || {});
  if (options.body) headers.set('Content-Type', 'application/json');
  if (adminToken) headers.set('Authorization', `Bearer ${adminToken}`);
  const response = await fetch(path, { ...options, headers });
  let payload;
  try {
    payload = await response.json();
  } catch {
    throw new Error('The server returned an unreadable response.');
  }
  if (!response.ok || payload.success === false) {
    if (response.status === 401 && adminToken) {
      adminToken = '';
      localStorage.removeItem('pms_admin_token');
    }
    throw new Error(payload.message || `Request failed (${response.status}).`);
  }
  return payload;
}

function pageBanner(kicker, title, description) {
  return `<section class="page-banner"><div class="container"><div class="breadcrumbs"><a href="#home" data-page="home">Home</a><span>/</span><span>${escapeHtml(kicker)}</span></div><p class="eyebrow">${escapeHtml(kicker)}</p><h1>${escapeHtml(title)}</h1><p>${escapeHtml(description)}</p></div></section>`;
}

function updateTalukOptions(form, district, language = membershipLanguage) {
  const select = form.querySelector('#member-taluk-select');
  const other = form.querySelector('#member-taluk-other');
  const placeholder = new Option(language === 'ta' ? 'மாவட்டத்தைத் தேர்ந்தெடுக்கவும்' : 'Choose a taluk', '');
  placeholder.dataset.en = 'Choose a taluk';
  placeholder.dataset.ta = 'வட்டத்தைத் தேர்ந்தெடுக்கவும்';
  select.replaceChildren(placeholder);
  const taluks = window.pmsLocationData.districts[district] || [];
  for (const taluk of taluks) {
    const option = new Option(taluk, taluk);
    option.dataset.en = taluk;
    option.dataset.ta = taluk;
    select.add(option);
  }
  const otherOption = new Option(language === 'ta' ? 'பட்டியலில் இல்லை — கைமுறையாக உள்ளிடவும்' : 'Not listed — enter manually', '__other__');
  otherOption.dataset.en = 'Not listed — enter manually';
  otherOption.dataset.ta = 'பட்டியலில் இல்லை — கைமுறையாக உள்ளிடவும்';
  select.add(otherOption);
  select.disabled = !district;
  select.value = '';
  other.value = '';
  other.hidden = true;
  other.disabled = true;
  other.required = false;
}

function updateLocalBodyFields(form) {
  const type = form.elements.localBodyType.value;
  const selected = window.pmsLocationData.localBodyTypes.find((item) => item.value === type);
  for (const { field } of window.pmsLocationData.localBodyTypes) {
    const wrapper = form.querySelector(`[data-location-field="${field}"]`);
    const input = wrapper.querySelector('input');
    const visible = selected?.field === field;
    wrapper.hidden = !visible;
    input.disabled = !visible;
    input.required = visible;
    if (!visible) input.value = '';
  }
  const ward = form.querySelector('[data-location-field="wardNumber"]');
  const wardInput = ward.querySelector('input');
  ward.hidden = !selected;
  wardInput.disabled = !selected;
  if (!selected) wardInput.value = '';
}

function updateParliamentOptions(form, assembly) {
  const select = form.querySelector('#member-parliament');
  const placeholder = new Option(
    membershipLanguage === 'ta' ? 'தேர்வு செய்யவும்' : 'Choose an option',
    '',
  );
  placeholder.dataset.en = 'Choose an option';
  placeholder.dataset.ta = 'தேர்வு செய்யவும்';
  select.replaceChildren(placeholder);
  for (const name of window.pmsConstituencyData.parliamentaryConstituencies) {
    const option = new Option(name, name);
    option.dataset.en = name;
    option.dataset.ta = name;
    select.add(option);
  }
  select.disabled = !assembly;
  select.required = Boolean(assembly);
  select.value = window.pmsConstituencyData.parliamentByAssembly[assembly] || '';
}

async function loadPostalDirectory() {
  if (postalDirectory) return postalDirectory;
  if (!postalDirectoryPromise) {
    postalDirectoryPromise = fetch('/postal-directory.json')
      .then(async (response) => {
        if (!response.ok) throw new Error(`Postal directory request failed (${response.status}).`);
        const data = await response.json();
        if (!Array.isArray(data.records) || data.records.length < 10000) {
          throw new Error('The postal directory data is incomplete.');
        }
        postalDirectory = data.records;
        return postalDirectory;
      })
      .catch((error) => {
        postalDirectoryPromise = null;
        throw error;
      });
  }
  return postalDirectoryPromise;
}

function closePinSuggestions(form) {
  const input = form?.querySelector('#member-pin');
  const list = form?.querySelector('#member-pin-suggestions');
  if (!input || !list) return;
  list.hidden = true;
  list.replaceChildren();
  input.setAttribute('aria-expanded', 'false');
  input.removeAttribute('aria-activedescendant');
  pinSuggestionIndex = -1;
}

function renderPinSuggestions(input) {
  const form = input.form;
  const list = form.querySelector('#member-pin-suggestions');
  const query = input.value.trim().toLowerCase();
  if (!postalDirectory || query.length < 2) {
    closePinSuggestions(form);
    return;
  }

  const numericQuery = /^\d+$/.test(query);
  const results = [];
  const seenPins = new Set();
  for (const [pin, office, taluk, district] of postalDirectory) {
    const matches = numericQuery
      ? pin.startsWith(query)
      : `${office} ${taluk} ${district}`.toLowerCase().includes(query);
    if (!matches || seenPins.has(pin)) continue;
    seenPins.add(pin);
    results.push([pin, office, taluk, district]);
    if (results.length === 12) break;
  }

  pinSuggestionIndex = -1;
  list.replaceChildren();
  if (!results.length) {
    const empty = document.createElement('div');
    empty.className = 'lookup-empty';
    empty.textContent = membershipLanguage === 'ta'
      ? 'பொருத்தமான அஞ்சல் அலுவலகம் இல்லை. PIN குறியீட்டை நேரடியாக உள்ளிடலாம்.'
      : 'No matching post office. You can still enter a PIN code directly.';
    list.append(empty);
    list.hidden = false;
    input.setAttribute('aria-expanded', 'true');
    input.removeAttribute('aria-activedescendant');
    return;
  }

  results.forEach(([pin, office, taluk, district], index) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.id = `member-pin-option-${index}`;
    button.className = 'lookup-option';
    button.setAttribute('role', 'option');
    button.setAttribute('aria-selected', 'false');
    button.dataset.pinValue = pin;
    button.textContent = `${office} · ${taluk || district} · ${pin}`;
    list.append(button);
  });
  list.hidden = false;
  input.setAttribute('aria-expanded', 'true');
  input.removeAttribute('aria-activedescendant');
}

function initializePinLookup(form) {
  const status = form.querySelector('#member-pin-status');
  status.textContent = membershipLanguage === 'ta'
    ? 'அஞ்சல் குறியீட்டு பட்டியல் ஏற்றப்படுகிறது…'
    : 'Loading the Tamil Nadu postal lookup…';
  loadPostalDirectory().then(() => {
    if (!form.isConnected) return;
    status.textContent = membershipLanguage === 'ta'
      ? 'குறியீடு அல்லது அஞ்சல் அலுவலகப் பெயரால் தேடவும். பட்டியலில் இல்லாத செல்லுபடியான 6 இலக்க PIN-ஐ நேரடியாக உள்ளிடலாம்.'
      : 'Search by PIN or post-office name. You can manually enter a valid 6-digit PIN if it is not listed.';
    const input = form.querySelector('#member-pin');
    if (input.value.trim()) renderPinSuggestions(input);
  }).catch((error) => {
    console.error('Tamil Nadu postal lookup could not be loaded.', error);
    if (!form.isConnected) return;
    status.textContent = membershipLanguage === 'ta'
      ? 'அஞ்சல் பட்டியலை ஏற்ற முடியவில்லை. உங்கள் பதிவில் உள்ள 6 இலக்க PIN-ஐ நேரடியாக உள்ளிடலாம்.'
      : 'The postal lookup could not be loaded. Enter the 6-digit PIN from your records.';
    status.classList.add('lookup-error');
  });
}

function initializeLocationForm() {
  const form = document.getElementById('membership-form');
  if (!form) return;
  const district = form.elements.district.value;
  const localBodyType = form.elements.localBodyType;
  localBodyType.disabled = !district;
  updateTalukOptions(form, district);
  updateLocalBodyFields(form);
  updateParliamentOptions(form, form.elements.assemblyConstituency.value);
  initializePinLookup(form);
}

function focusCards() {
  return focusAreas.map(([number, title, copy]) => `<article class="value-card"><span class="value-number">${number}</span><h3>${escapeHtml(title)}</h3><p>${escapeHtml(copy)}</p></article>`).join('');
}

function serviceCard(service, index) {
  return `<article class="service-card">
    <div class="service-top"><span class="service-icon" aria-hidden="true">${escapeHtml(service.icon)}</span><span class="service-tag">${escapeHtml(service.group)}</span></div>
    <h3>${escapeHtml(service.title)}</h3><p>${escapeHtml(service.summary)}</p>
    <div class="service-bottom"><button class="button-text" type="button" data-service="${index}">View process <span aria-hidden="true">→</span></button><a class="button-text" href="${escapeHtml(service.portal)}" target="_blank" rel="noopener noreferrer" aria-label="Open official portal for ${escapeHtml(service.title)}">Official portal ↗</a></div>
  </article>`;
}

function servicesGrid(list) {
  if (!list.length) return '<div class="no-results">No guide matched. Try a broader search or choose another category.</div>';
  return list.map(({ service, index }) => serviceCard(service, index)).join('');
}

function homePage() {
  memberCardChallengeId = '';
  memberCardDownloadToken = '';
  const featuredIndices = [0, 1, 5, 8, 9, 14];
  return `<section class="hero"><div class="container hero-grid">
    <div><p class="eyebrow">Community · Education · Opportunity</p>
      <h1>Rooted in unity.<br /><em>Growing together.</em></h1>
      <p class="hero-copy">Parayar Maha Sabai works alongside our community to widen access to education, public services and opportunity—grounded in dignity, participation and shared progress.</p>
      <div class="hero-actions"><a class="button" href="#community" data-page="community">Explore our purpose <span aria-hidden="true">↗</span></a><a class="button button-outline" href="#services" data-page="services">Find a public-service guide</a></div>
      <p class="hero-note"><span class="stamp-mark" aria-hidden="true">i</span><span><strong>Independent community organisation.</strong> We help people navigate public information; government departments alone decide applications and benefits.</span></p>
    </div>
    <div class="hero-art"><img src="/assets/cover-group.jpg.png" alt="Parayar Maha Sabai community members gathered together" /><div class="hero-stamp"><span class="stamp-mark" aria-hidden="true">7</span><span><strong>Seven community focus areas</strong><small>Unity · learning · culture · civic voice</small></span></div></div>
  </div></section>
  <div class="rainbow-rule" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div>
  <section class="trust-row"><div class="container trust-grid">
    <div class="trust-item"><span class="trust-icon" aria-hidden="true">◎</span><span><strong>Community first</strong><small>Local guidance, shared progress</small></span></div>
    <div class="trust-item"><span class="trust-icon" aria-hidden="true">▤</span><span><strong>Education & skills</strong><small>Resources for learners and families</small></span></div>
    <div class="trust-item"><span class="trust-icon" aria-hidden="true">↗</span><span><strong>Official service links</strong><small>Connect directly to public portals</small></span></div>
    <div class="trust-item"><span class="trust-icon" aria-hidden="true">✓</span><span><strong>Clear next steps</strong><small>Checklists, process and tracking</small></span></div>
  </div></section>
  <section class="section"><div class="container">
    <div class="section-heading"><div><p class="section-kicker">Public information desk</p><h2>Start with the right service</h2><p>Plain-language guides for common Tamil Nadu services, with a document checklist, a step-by-step route and a link to the official authority.</p></div><a class="button button-outline" href="#services" data-page="services">Browse all ${services.length} guides <span aria-hidden="true">→</span></a></div>
    <div class="service-grid">${servicesGrid(featuredIndices.map((index) => ({ service: services[index], index })))}</div>
  </div></section>
  <section class="section section-soft"><div class="container">
    <div class="section-heading"><div><p class="section-kicker">Our shared purpose</p><h2>Seven goals. One community.</h2><p>The seven focus areas shown in the supplied organisation material are the foundation for this community portal.</p></div></div>
    <div class="values-grid">${focusCards()}</div>
  </div></section>
  <section class="section"><div class="container"><div class="education-banner"><div><p class="section-kicker" style="color:#b8e1ff">Education opens doors</p><h2>Support for the next step in every learner’s journey.</h2><p>Explore scholarship guidance, school support, RTE admissions, skills programmes and recruitment information. Always confirm current eligibility and deadlines with the official department.</p><div class="edu-meta"><span>School & student support</span><span>Scholarships</span><span>Skills & careers</span></div></div><a class="button button-light" href="#education" data-page="education">Explore education guides <span aria-hidden="true">→</span></a></div></div></section>
  <section class="section section-soft"><div class="container">
    <div class="section-heading"><div><p class="section-kicker">How we can help</p><h2>A clear route from question to next step</h2><p>Use official channels for applications. Our site is a community guide—not a government application portal.</p></div></div>
    <div class="steps-grid"><article class="step-card"><span>01 / UNDERSTAND</span><h3>Choose the service</h3><p>Start with the service guide and check which authority is responsible.</p></article><article class="step-card"><span>02 / PREPARE</span><h3>Check your documents</h3><p>Use the live official list; requirements vary by scheme and applicant.</p></article><article class="step-card"><span>03 / APPLY</span><h3>Use the official route</h3><p>Submit through the authorised portal, e-Sevai centre or department.</p></article><article class="step-card"><span>04 / FOLLOW UP</span><h3>Keep the acknowledgement</h3><p>Track status with the application number and contact the authority.</p></article></div>
  </div></section>
  <section class="section"><div class="container"><div class="cta-panel"><div><h2>Would you like to take part?</h2><p>Join the Sabai, share your area of interest, or ask our community team for guidance. Membership applications are reviewed by the organisation.</p></div><a class="button" href="#join" data-page="join">Membership enquiry <span aria-hidden="true">→</span></a></div></div></section>
  <section class="section section-soft"><div class="container"><div class="member-card-download">
    <div class="section-heading"><div><p class="section-kicker">Member access</p><h2>Download your membership card</h2><p>Enter your membership number and the email address registered with the Sabai. We’ll send a one-time code to verify your email before you can download your card PDF.</p></div></div>
    <div id="member-card-message" class="form-message" role="status" aria-live="polite"></div>
    <form id="member-card-request-form" class="member-card-access-form">
      <div class="field"><label for="member-card-number">Membership number *</label><input id="member-card-number" name="membershipId" autocomplete="off" placeholder="PMS-2026-0001" maxlength="40" required /></div>
      <div class="field"><label for="member-card-email">Registered email address *</label><input id="member-card-email" name="email" type="email" autocomplete="email" maxlength="254" required /></div>
      <button class="button" type="submit">Send verification code</button>
    </form>
    <form id="member-card-otp-form" class="member-card-access-form" hidden>
      <div class="field"><label for="member-card-otp">Six-digit email code *</label><input id="member-card-otp" name="otp" inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{6}" maxlength="6" required /></div>
      <button class="button" type="submit">Verify email</button>
      <button class="button button-outline" type="button" id="member-card-resend">Send a new code</button>
    </form>
    <div id="member-card-download-actions" hidden><button class="button" type="button" id="member-card-download">Download membership card PDF</button></div>
    <p class="member-card-privacy">The verification code is sent only to the email saved on the active member record. Never share your code with anyone.</p>
  </div></div></section>
  <section class="section section-soft"><div class="container"><div class="disclaimer"><strong>Please note:</strong> Parayar Maha Sabai is an independent community organisation, not a government department or e-Sevai centre. It cannot issue certificates, approve schemes, guarantee benefits or change government applications. Use the linked official portal for current rules and charges. Do not share Aadhaar numbers, OTPs, passwords or original documents in a public message.</div></div></section>`;
}

function serviceDirectoryPage({ category = 'all', query = '' } = {}) {
  const filtered = services.map((service, index) => ({ service, index })).filter(({ service }) => {
    const matchesCategory = category === 'all' || service.category === category;
    const text = `${service.title} ${service.summary} ${service.group}`.toLowerCase();
    return matchesCategory && text.includes(query.toLowerCase().trim());
  });
  return `${pageBanner('Tamil Nadu public-service guides', 'Know the route. Apply with confidence.', 'Practical checklists and steps for common e-Sevai, education, revenue, welfare and public services. Every application must be made through the official authority.')}
    <section class="section"><div class="container">
      <div class="filter-bar"><div class="filter-chips" aria-label="Filter services">${categoryLabels.map(([key, label]) => `<button class="filter-chip${category === key ? ' is-active' : ''}" type="button" data-category="${key}" aria-pressed="${category === key}">${label}</button>`).join('')}</div><label class="search-box"><span class="visually-hidden"></span><input id="service-search" type="search" value="${escapeHtml(query)}" placeholder="Search certificates, school, land…" aria-label="Search public-service guides" /></label></div>
      <div id="service-results" class="service-grid">${servicesGrid(filtered)}</div>
      <div class="disclaimer official-note"><strong>Before applying:</strong> Check the current eligibility, accepted documents, application window and any official fee on the destination portal or at an authorised centre. These guides are general public information and may not cover every case.</div>
    </div></section>`;
}

function educationPage() {
  const education = services.map((service, index) => ({ service, index })).filter(({ service }) => service.category === 'education');
  return `${pageBanner('Education & opportunity', 'Learning, skills and a pathway forward.', 'A practical starting point for students and families looking for school support, scholarships, RTE admissions, skills programmes and public recruitment information.')}
    <section class="section"><div class="container">
      <div class="section-heading"><div><p class="section-kicker">Education service desk</p><h2>Pick the next step</h2><p>Eligibility and deadlines are set by each scheme or institution. Read the current official notice before sharing documents or making a payment.</p></div></div>
      <div class="service-grid">${servicesGrid(education)}</div>
      <div class="disclaimer official-note"><strong>For students and parents:</strong> Start with your school/college office or its scholarship nodal officer. They can confirm the correct scheme, application portal, current documents and whether institution verification is needed. Never pay an unverified agent for a guaranteed seat, scholarship or job.</div>
    </div></section>`;
}

function communityPage() {
  return `${pageBanner('About Parayar Maha Sabai', 'A community for shared dignity and progress.', 'Inspired by the vision and seven goals in the supplied organisation material, this portal brings community participation, education and public-service guidance together.')}
    <section class="section"><div class="container">
      <div class="section-heading"><div><p class="section-kicker">Our vision · எங்கள் நோக்கம்</p><h2>Seven connected commitments</h2><p>We value unity, awareness, culture, learning, social and economic progress, quality of life and informed civic participation.</p></div></div>
      <div class="values-grid">${focusCards()}</div>
    </div></section>
    <section class="section section-soft"><div class="container">
      <div class="section-heading"><div><p class="section-kicker">How we serve</p><h2>Community-led. Respectful. Practical.</h2><p>Our role is to listen, share reliable public information and help people find the right public office or support route.</p></div></div>
      <div class="steps-grid"><article class="step-card"><span>COMMUNITY</span><h3>Participation & fellowship</h3><p>Create welcoming ways for members to contribute and support neighbours.</p></article><article class="step-card"><span>EDUCATION</span><h3>Learning & opportunity</h3><p>Share information about study, skills, scholarships and public programmes.</p></article><article class="step-card"><span>PUBLIC GUIDANCE</span><h3>Know-how for services</h3><p>Make official process information easier to understand and follow.</p></article><article class="step-card"><span>DIGNITY</span><h3>Equal respect</h3><p>Encourage inclusive, peaceful and rights-aware community engagement.</p></article></div>
    </div></section>
    <section class="section"><div class="container"><div class="cta-panel"><div><h2>Help shape the work in your area.</h2><p>Tell us which district you are from and the kind of community work you would like to support.</p></div><a class="button" href="#join" data-page="join">Become a member <span aria-hidden="true">→</span></a></div></div></section>
    <section class="section section-soft"><div class="container"><div class="disclaimer"><strong>Our role:</strong> The Sabai is an independent community organisation. It has no government enforcement or certification powers. Government applications, benefits, recruitment and grievance decisions remain with the relevant authorities.</div></div></section>`;
}

function membershipPage() {
  const t = (english, tamil) => `<span class="lang-en">${escapeHtml(english)}</span><span class="lang-ta">${escapeHtml(tamil)}</span>`;
  const option = (english, tamil, value = english) => `<option value="${escapeHtml(value)}" data-en="${escapeHtml(english)}" data-ta="${escapeHtml(tamil)}">${escapeHtml(membershipLanguage === 'ta' ? tamil : english)}</option>`;
  const districtNames = [
    'Ariyalur', 'Chengalpattu', 'Chennai', 'Coimbatore', 'Cuddalore', 'Dharmapuri', 'Dindigul', 'Erode',
    'Kallakurichi', 'Kancheepuram', 'Kanniyakumari', 'Karur', 'Krishnagiri', 'Madurai', 'Mayiladuthurai',
    'Nagapattinam', 'Namakkal', 'Perambalur', 'Pudukkottai', 'Ramanathapuram', 'Ranipet', 'Salem',
    'Sivaganga', 'Tenkasi', 'Thanjavur', 'Theni', 'Thoothukudi', 'Tiruchirappalli', 'Tirunelveli',
    'Tirupathur', 'Tiruppur', 'Tiruvallur', 'Tiruvannamalai', 'Tiruvarur', 'Vellore', 'Viluppuram',
    'Virudhunagar'
  ];
  const districtTamilNames = [
    'அரியலூர்', 'செங்கல்பட்டு', 'சென்னை', 'கோயம்புத்தூர்', 'கடலூர்', 'தருமபுரி', 'திண்டுக்கல்', 'ஈரோடு',
    'கள்ளக்குறிச்சி', 'காஞ்சிபுரம்', 'கன்னியாகுமரி', 'கரூர்', 'கிருஷ்ணகிரி', 'மதுரை', 'மயிலாடுதுறை',
    'நாகப்பட்டினம்', 'நாமக்கல்', 'பெரம்பலூர்', 'புதுக்கோட்டை', 'இராமநாதபுரம்', 'இராணிப்பேட்டை', 'சேலம்',
    'சிவகங்கை', 'தென்காசி', 'தஞ்சாவூர்', 'தேனி', 'தூத்துக்குடி', 'திருச்சிராப்பள்ளி', 'திருநெல்வேலி',
    'திருப்பத்தூர்', 'திருப்பூர்', 'திருவள்ளூர்', 'திருவண்ணாமலை', 'திருவாரூர்', 'வேலூர்', 'விழுப்புரம்',
    'விருதுநகர்'
  ];
  const districts = districtNames.map((name, index) => option(name, districtTamilNames[index], name)).join('');
  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown']
    .map((group) => option(group === 'Unknown' ? 'Not known' : group, group === 'Unknown' ? 'தெரியாது' : group, group)).join('');
  const field = (id, name, label, tamilLabel, type = 'text', extra = '') => `
    <div class="field"><label for="${id}">${t(label, tamilLabel)}${extra.includes('required') ? ' *' : ''}</label><input id="${id}" name="${name}" type="${type}" ${extra} /></div>`;
  const selectField = (id, name, label, tamilLabel, options, required = true) => `
    <div class="field"><label for="${id}">${t(label, tamilLabel)}${required ? ' *' : ''}</label><select id="${id}" name="${name}" ${required ? 'required' : ''}>${option('Choose an option', 'தேர்வு செய்யவும்', '')}${options}</select></div>`;
  const locationField = (id, name, english, tamil) => `
    <div class="field" data-location-field="${name}" hidden><label for="${id}">${t(english, tamil)} *</label><input id="${id}" name="${name}" type="text" maxlength="100" disabled /></div>`;
  const upiId = 'mastersuresh345@okaxis';
  const upiName = 'Suresh Suresh';
  const payUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(upiName)}&am=500&cu=INR&tn=${encodeURIComponent('Parayar Maha Sabai membership')}`;
  return `<div class="membership-page" data-language="${membershipLanguage}">
    ${pageBanner('Membership registration · உறுப்பினர் பதிவு', 'Join Parayar Maha Sabai.', 'Complete the registration form in English or Tamil. Membership is activated when you submit the form; the ₹500 UPI receipt will be checked by the administrator.')}
    <section class="section"><div class="container">
      <div class="membership-topbar"><div><p class="section-kicker">${t('Membership Form · Reg. No. 49/2014', 'உறுப்பினர் படிவம் · பதிவு எண் 49/2014')}</p><p class="membership-intro">${t('Fill in the details as they appear on your records. Fields marked * are required.', 'உங்கள் ஆவணங்களில் உள்ளபடி விவரங்களை நிரப்பவும். * குறியிட்டவை கட்டாயம்.')}</p></div><div class="language-switch" role="group" aria-label="Choose form language"><button type="button" data-membership-language="en" aria-pressed="${membershipLanguage === 'en'}">English</button><button type="button" data-membership-language="ta" aria-pressed="${membershipLanguage === 'ta'}">தமிழ்</button></div></div>
      <div class="membership-layout">
      <div class="membership-form-column">
        <div class="form-card membership-form-card"><h2>${t('Basic information', 'அடிப்படை விவரங்கள்')}</h2><div id="membership-message" class="form-message" role="status"></div>
          <form id="membership-form" novalidate>
            <div class="membership-section-title">${t('1. Personal details', '1. தனிப்பட்ட விவரங்கள்')}</div>
            <div class="form-grid">
              ${field('member-name', 'fullName', 'Full name (as on records)', 'முழுப் பெயர் (ஆவணங்களில் உள்ளபடி)', 'text', 'autocomplete="name" maxlength="100" required')}
              <div class="field tamil-input-field"><label for="member-name-ta">${t('Name in Tamil', 'பெயர் தமிழில்')} *</label><input id="member-name-ta" name="fullNameTamil" type="text" lang="ta" maxlength="100" placeholder="வெ. சுரேஷ்" autocomplete="off" role="combobox" aria-autocomplete="list" aria-expanded="false" required data-tamil-input /><div id="member-name-ta-suggestions" class="tamil-suggestions" role="listbox" aria-label="${membershipLanguage === 'ta' ? 'தமிழ் பெயர் பரிந்துரைகள்' : 'Tamil name suggestions'}" hidden></div><small>${t('Type in English for Tamil suggestions, then choose a suggestion or edit it.', 'தமிழ் பரிந்துரைகளைப் பெற ஆங்கிலத்தில் தட்டச்சு செய்து, பரிந்துரையைத் தேர்ந்தெடுக்கவும் அல்லது திருத்தவும்.')}</small></div>
              ${selectField('member-gender', 'gender', 'Gender', 'பாலினம்', `${option('Male', 'ஆண்')} ${option('Female', 'பெண்')} ${option('Other', 'மற்றவை')}`)}
              <div class="field"><label for="guardian-relation">${t('Relationship to parent / spouse', 'பெற்றோர் / துணைவர் உறவு')} *</label><select id="guardian-relation" name="guardianRelation" required>${option('Choose', 'தேர்வு செய்யவும்', '')}${option('Son of (S/o)', 'மகன் (S/o)', 'S/o')}${option('Daughter of (D/o)', 'மகள் (D/o)', 'D/o')}${option('Wife of (W/o)', 'மனைவி (W/o)', 'W/o')}</select></div>
              ${field('guardian-name', 'guardianName', 'Father / spouse full name', 'தந்தை / கணவர் முழுப் பெயர்', 'text', 'maxlength="100" required')}
              <div class="field tamil-input-field"><label for="guardian-name-ta">${t('Parent / spouse name in Tamil', 'பெற்றோர் / துணைவர் பெயர் தமிழில்')} *</label><input id="guardian-name-ta" name="guardianNameTamil" type="text" lang="ta" maxlength="100" autocomplete="off" role="combobox" aria-autocomplete="list" aria-expanded="false" required data-tamil-input /><div id="guardian-name-ta-suggestions" class="tamil-suggestions" role="listbox" aria-label="${membershipLanguage === 'ta' ? 'தமிழ் பெயர் பரிந்துரைகள்' : 'Tamil name suggestions'}" hidden></div></div>
              ${field('member-dob', 'dateOfBirth', 'Date of birth', 'பிறந்த தேதி', 'date', 'required')}
              ${field('member-occupation', 'occupation', 'Occupation', 'தொழில்', 'text', 'maxlength="100" required')}
              ${selectField('member-blood-group', 'bloodGroup', 'Blood group', 'இரத்த வகை', bloodGroups)}
              <div class="field field-full"><label for="member-photo">${t('Recent passport-size photo (JPEG / PNG / WebP, up to 250 KB)', 'சமீபத்திய பாஸ்போர்ட் அளவு புகைப்படம் (JPEG / PNG / WebP, அதிகபட்சம் 250 KB)')} *</label><div class="photo-upload-row"><input id="member-photo" name="photo" type="file" accept="image/jpeg,image/png,image/webp" required /><img id="member-photo-preview" alt="${t('Photo preview', 'புகைப்பட முன்னோட்டம்')}" hidden /></div><small>${t('Your photo is stored privately and used for your membership card.', 'உங்கள் புகைப்படம் பாதுகாப்பாகச் சேமிக்கப்பட்டு உறுப்பினர் அட்டைக்குப் பயன்படுத்தப்படும்.')}</small></div>
            </div>
            <div class="membership-section-title">${t('2. Contact and address', '2. தொடர்பு மற்றும் முகவரி')}</div>
            <div class="form-grid">
              ${field('member-mobile', 'mobile', 'Mobile number', 'கைபேசி எண்', 'tel', 'autocomplete="tel" inputmode="tel" maxlength="18" required')}
              ${field('member-email', 'email', 'Email address', 'மின்னஞ்சல் முகவரி', 'email', 'autocomplete="email" maxlength="254"')}
              ${field('member-whatsapp', 'whatsapp', 'WhatsApp number (if different)', 'வாட்ஸ்அப் எண் (வேறுபட்டால்)', 'tel', 'inputmode="tel" maxlength="18"')}
              ${field('member-country', 'country', 'Country', 'நாடு', 'text', 'value="India" maxlength="80" required')}
              ${field('member-state', 'state', 'State', 'மாநிலம்', 'text', 'value="Tamil Nadu" maxlength="80" required')}
              ${selectField('member-district', 'district', 'District', 'மாவட்டம்', districts)}
              <div class="field"><label for="member-taluk-select">${t('Revenue taluk', 'வருவாய் வட்டம்')} *</label><select id="member-taluk-select" required disabled><option value="">${t('Select a district first', 'முதலில் மாவட்டத்தைத் தேர்ந்தெடுக்கவும்')}</option></select><input id="member-taluk-other" type="text" maxlength="80" placeholder="${t('Enter taluk name as on your records', 'ஆவணங்களில் உள்ளபடி வட்டத்தின் பெயரை உள்ளிடவும்')}" hidden disabled /></div>
              ${selectField('member-local-body-type', 'localBodyType', 'Local government type', 'உள்ளாட்சி அமைப்பு வகை', window.pmsLocationData.localBodyTypes.map(({ value, en, ta }) => option(en, ta, value)).join(''))}
              <p class="location-guidance field-full">${t('Choose the local body shown on your address records. Urban addresses use a corporation, municipality or town panchayat; rural addresses use a village panchayat. Taluk is revenue administration; Assembly / Parliament constituency and PIN code follow their own official boundaries.', 'உங்கள் முகவரி ஆவணங்களில் உள்ள உள்ளாட்சி அமைப்பைத் தேர்ந்தெடுக்கவும். நகர்ப்புற முகவரிக்கு மாநகராட்சி, நகராட்சி அல்லது பேரூராட்சி; கிராமப்புற முகவரிக்கு கிராம ஊராட்சி. வட்டம் வருவாய் நிர்வாகப் பிரிவு; சட்டமன்ற / நாடாளுமன்றத் தொகுதி மற்றும் அஞ்சல் குறியீடு தனித்தனி அதிகாரப்பூர்வ எல்லைகளைக் கொண்டவை.')}</p>
              ${locationField('member-corporation', 'corporation', 'Municipal corporation', 'மாநகராட்சி')}
              ${locationField('member-municipality', 'municipality', 'Municipality', 'நகராட்சி')}
              ${locationField('member-town-panchayat', 'townPanchayat', 'Town panchayat', 'பேரூராட்சி')}
              ${locationField('member-panchayat', 'panchayat', 'Village panchayat', 'கிராம ஊராட்சி')}
              <div class="field" data-location-field="wardNumber" hidden><label for="member-ward">${t('Ward number (if applicable)', 'வார்டு எண் (பொருந்தினால்)')}</label><input id="member-ward" name="wardNumber" type="text" maxlength="30" disabled /></div>
              ${selectField('member-assembly', 'assemblyConstituency', 'MLA / Assembly constituency', 'சட்டமன்றத் தொகுதி', window.pmsConstituencyData.assemblyConstituencies.map((name) => option(name, name, name)).join(''))}
              ${selectField('member-parliament', 'parliamentaryConstituency', 'MP / Parliamentary constituency', 'நாடாளுமன்றத் தொகுதி', window.pmsConstituencyData.parliamentaryConstituencies.map((name) => option(name, name, name)).join(''))}
              <p class="location-guidance field-full constituency-guidance">${t('Choosing an Assembly constituency preselects its corresponding Parliament constituency under the current electoral boundaries. Confirm both against your official records.', 'சட்டமன்றத் தொகுதியைத் தேர்ந்தெடுத்ததும் தற்போதைய தேர்தல் எல்லைகளின்படி தொடர்புடைய நாடாளுமன்றத் தொகுதி முன்தேர்வு செய்யப்படும். உங்கள் அதிகாரப்பூர்வ ஆவணங்களுடன் இரண்டையும் சரிபார்க்கவும்.')}</p>
              <div class="field pin-lookup-field"><label for="member-pin">${t('PIN code', 'அஞ்சல் குறியீடு')} *</label><input id="member-pin" name="pinCode" type="text" inputmode="text" autocomplete="postal-code" pattern="[0-9]{6}" maxlength="100" required role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="member-pin-suggestions" aria-describedby="member-pin-status" /><div id="member-pin-suggestions" class="lookup-suggestions" role="listbox" aria-label="${membershipLanguage === 'ta' ? 'அஞ்சல் குறியீடு பரிந்துரைகள்' : 'PIN code suggestions'}" hidden></div><small id="member-pin-status" class="lookup-status" aria-live="polite"></small></div>
              ${field('member-street', 'street', 'Door number / Street', 'கதவு எண் / தெரு', 'text', 'autocomplete="street-address" maxlength="160" required')}
              ${field('member-area', 'villageArea', 'Village / Area', 'கிராமம் / பகுதி', 'text', 'maxlength="120" required')}
              <div class="field field-full tamil-input-field"><label for="member-address-ta">${t('Full address in Tamil', 'முழு முகவரி தமிழில்')} *</label><textarea id="member-address-ta" name="addressTamil" lang="ta" rows="3" maxlength="500" placeholder="வீட்டு எண், தெரு, பகுதி, வட்டம், மாவட்டம், PIN குறியீடு" autocomplete="off" role="combobox" aria-autocomplete="list" aria-expanded="false" required data-tamil-input></textarea><div id="member-address-ta-suggestions" class="tamil-suggestions" role="listbox" aria-label="${membershipLanguage === 'ta' ? 'தமிழ் முகவரி பரிந்துரைகள்' : 'Tamil address suggestions'}" hidden></div><small>${t('A Tamil draft is generated from your English address. Review and edit it before submitting; you can also type English here to see alternatives. This address appears on the card.', 'உங்கள் ஆங்கில முகவரியிலிருந்து தமிழ் வரைவு உருவாக்கப்படும். சமர்ப்பிக்கும் முன் சரிபார்த்து திருத்தவும்; மாற்றுப் பரிந்துரைகளுக்கு இங்கே ஆங்கிலத்தில் தட்டச்சு செய்யலாம். இந்த முகவரி அட்டையில் அச்சிடப்படும்.')}</small></div>
              <div class="field field-full"><label for="member-aadhaar">${t('Aadhaar number (optional)', 'ஆதார் எண் (விருப்பத்தேர்வு)')}</label><input id="member-aadhaar" name="aadhaarNumber" type="text" inputmode="numeric" autocomplete="off" pattern="[0-9 ]{12,14}" maxlength="14" aria-describedby="aadhaar-note" /><small id="aadhaar-note">${t('Optional. If provided, it is encrypted before storage and never printed on your membership card.', 'விருப்பத்தேர்வு. அளித்தால் சேமிப்பதற்கு முன் குறியாக்கம் செய்யப்படும்; உறுப்பினர் அட்டையில் அச்சிடப்படாது.')}</small></div>
            </div>
            <div class="membership-section-title">${t('3. UPI membership fee · ₹500', '3. UPI உறுப்பினர் கட்டணம் · ₹500')}</div>
            <div class="payment-panel"><div class="payment-qr"><img src="/assets/membership-payment-qr.jpeg" alt="${t('Parayar Maha Sabai UPI payment QR code', 'பறையர் மகா சபை UPI கட்டண QR குறியீடு')}" /><span>${t('Scan using any UPI app', 'எந்த UPI செயலி மூலமும் ஸ்கேன் செய்யவும்')}</span></div><div class="payment-details"><span class="payment-amount">₹500 <small>${t('one-time membership fee', 'ஒருமுறை உறுப்பினர் கட்டணம்')}</small></span><p>${t('Pay to the UPI recipient shown in the supplied QR. The secure UPI button pre-fills exactly ₹500.', 'வழங்கப்பட்ட QR-ல் உள்ள UPI பெறுநருக்குச் செலுத்தவும். பாதுகாப்பான UPI பொத்தான் சரியாக ₹500-ஐ நிரப்பும்.')}</p><p class="payment-recipient"><strong>${escapeHtml(upiName)}</strong><span>${escapeHtml(upiId)}</span></p><div class="payment-actions"><a class="button" href="${payUri}">${t('Pay ₹500 in UPI app', 'UPI செயலியில் ₹500 செலுத்தவும்')} <span aria-hidden="true">↗</span></a><button class="button button-outline button-small" type="button" id="copy-upi-id">${t('Copy UPI ID', 'UPI ID நகலெடு')}</button></div></div></div>
            <div class="field payment-reference-field"><label for="upi-transaction">${t('UPI transaction ID / UTR number after payment', 'பணம் செலுத்திய பின் UPI பரிவர்த்தனை எண் / UTR')} *</label><input id="upi-transaction" name="upiTransactionId" type="text" autocomplete="off" inputmode="text" maxlength="30" pattern="[A-Za-z0-9\\- ]{6,30}" placeholder="Enter the UTR / transaction reference" required /><small>${t('Membership activates after registration. The admin will verify this UPI reference separately; submitting a number does not itself confirm payment.', 'பதிவுக்குப் பிறகு உறுப்பினர் நிலை செயல்படும். இந்த UPI குறிப்பை நிர்வாகி தனியாகச் சரிபார்ப்பார்; எண்ணை உள்ளிடுவது மட்டும் கட்டண உறுதிப்படுத்தல் அல்ல.')}</small></div>
            <div class="membership-section-title">${t('4. Declaration', '4. உறுதிமொழி')}</div>
            <p class="declaration-text">${t('I declare that the information provided is true to the best of my knowledge. I will participate in the activities of Tamil Nadu Parayar Maha Sabai with dedication and support its objectives and vision. I understand that the ₹500 payment must be verified by the organisation.', 'நான் அளித்துள்ள தகவல்கள் எனது அறிவுக்கு எட்டியவரை உண்மையானவை என உறுதியளிக்கிறேன். தமிழ்நாடு பறையர் மகா சபையின் செயல்பாடுகளில் அர்ப்பணிப்புடன் பங்கேற்று அதன் நோக்கத்திற்கும் தொலைநோக்கிற்கும் ஆதரவளிப்பேன். ₹500 கட்டணம் அமைப்பால் சரிபார்க்கப்பட வேண்டும் என்பதைப் புரிந்துகொள்கிறேன்.')}</p>
            <div class="form-grid">
              ${field('member-signature', 'signatureName', 'Type your full name as digital signature', 'மின்னணு கையொப்பமாக உங்கள் முழுப் பெயரைத் தட்டச்சு செய்யவும்', 'text', 'maxlength="100" autocomplete="name" required')}
              ${field('member-date', 'applicationDate', 'Application date', 'விண்ணப்ப தேதி', 'text', 'readonly')}
            </div>
            <label class="checkbox-row"><input type="checkbox" name="consent" required /><span>${t('I confirm this declaration, agree to be contacted about my membership, and consent to private storage of my application details. Aadhaar is optional.', 'இந்த உறுதிமொழியை ஏற்கிறேன்; உறுப்பினர் தொடர்பாக என்னை அணுக ஒப்புக்கொள்கிறேன்; எனது விண்ணப்ப விவரங்களைப் பாதுகாப்பாகச் சேமிக்க சம்மதிக்கிறேன். ஆதார் விருப்பத்தேர்வு.')}</span></label>
            <div class="form-submit-row"><button class="button" type="submit">${t('Register & generate membership ID', 'பதிவு செய்து உறுப்பினர் அட்டை பெறவும்')} <span aria-hidden="true">→</span></button><small>${t('Admin accounts are not member accounts.', 'நிர்வாகி கணக்குகள் உறுப்பினர் கணக்குகள் அல்ல.')}</small></div>
          </form>
        </div>
        <div class="form-card membership-result-card" id="membership-result-card" hidden></div>
        <div class="track-card membership-track-card"><h3>${t('Already registered? Check membership status', 'ஏற்கனவே பதிவு செய்துவிட்டீர்களா? உறுப்பினர் நிலையைப் பார்க்கவும்')}</h3><p>${t('Enter the membership reference from your confirmation.', 'உறுதிப்படுத்தலில் உள்ள உறுப்பினர் குறிப்பை உள்ளிடவும்.')}</p><form class="track-form" data-track-form><div class="track-row"><input name="reference" aria-label="Membership reference" placeholder="PMS-M-…" maxlength="40" required /><button class="button button-small" type="submit">${t('Check status', 'நிலையைப் பார்க்கவும்')}</button></div><div class="tracking-result" aria-live="polite"></div></form></div>
      </div>
      <aside class="membership-aside"><div class="membership-aside-card"><p class="section-kicker">${t('Registration details', 'பதிவு விவரங்கள்')}</p><h2>${t('Your membership starts here.', 'உங்கள் உறுப்பினர் பதிவு இங்கே தொடங்குகிறது.')}</h2><ul><li>${t('Complete the form in English or Tamil.', 'ஆங்கிலம் அல்லது தமிழில் படிவத்தை நிரப்பவும்.')}</li><li>${t('Pay the one-time ₹500 fee using the QR or the pre-filled UPI link.', 'QR அல்லது முன் நிரப்பப்பட்ட UPI இணைப்பைப் பயன்படுத்தி ஒருமுறை ₹500 செலுத்தவும்.')}</li><li>${t('Enter the transaction reference. Payment verification is handled separately by the administrator.', 'பரிவர்த்தனை எண்ணை உள்ளிடவும். கட்டண சரிபார்ப்பை நிர்வாகி தனியாக மேற்கொள்வார்.')}</li><li>${t('Your member number and printable card are issued on successful registration.', 'பதிவு முடிந்ததும் உறுப்பினர் எண் மற்றும் அச்சிடக்கூடிய அட்டை வழங்கப்படும்.')}</li></ul><div class="disclaimer"><strong>${t('Privacy notice:', 'தனியுரிமை அறிவிப்பு:')}</strong> ${t('The optional Aadhaar number and uploaded photo are encrypted before saving. Aadhaar is never shown to the public or printed on the card. Only the admin can review member records.', 'விருப்ப ஆதார் எண் மற்றும் புகைப்படம் சேமிப்பதற்கு முன் குறியாக்கம் செய்யப்படும். ஆதார் பொதுவில் காட்டப்படாது; அட்டையிலும் அச்சிடப்படாது. உறுப்பினர் பதிவுகளை நிர்வாகி மட்டுமே பார்வையிட முடியும்.')}</div></div></aside>
      </div>
    </div></section></div>`;
}

function helpPage() {
  const options = [...new Set(services.map((service) => service.title))];
  return `${pageBanner('Community help desk', 'Tell us what support you need.', 'Request help understanding a public-service process or finding the right official channel. For an application itself, submit directly to the government portal.')}
    <section class="section"><div class="container form-layout">
      <aside class="form-aside"><p class="section-kicker">A safe place to start</p><h2>Share the question, not your private documents.</h2><p>Our community team can help identify the next step or point you to the responsible public authority.</p><ul><li>Use the official portal for scheme and certificate applications.</li><li>Do not include Aadhaar numbers, account details, passwords or OTPs.</li><li>Do not upload original certificates or sensitive case papers here.</li><li>For an emergency or immediate risk, contact the appropriate emergency service directly.</li></ul><p>Contact: <a href="mailto:parayar7@gmail.com">parayar7@gmail.com</a></p></aside>
      <div class="form-card"><h2>Community support request</h2><p class="form-intro">A short description is enough. This form is not a government grievance filing.</p><div id="help-message" class="form-message" role="status"></div>
        <form id="help-form" novalidate><div class="form-grid">
          <div class="field"><label for="help-name">Your name *</label><input id="help-name" name="name" autocomplete="name" maxlength="100" required /></div>
          <div class="field"><label for="help-mobile">Mobile number *</label><input id="help-mobile" name="mobile" type="tel" autocomplete="tel" inputmode="tel" maxlength="18" required /></div>
          <div class="field field-full"><label for="help-category">Area you need help with *</label><select id="help-category" name="category" required><option value="">Choose an area</option>${options.map((option) => `<option>${escapeHtml(option)}</option>`).join('')}<option>Other public service</option></select></div>
          <div class="field field-full"><label for="help-details">How can we help? *</label><textarea id="help-details" name="message" maxlength="1400" placeholder="Please avoid sensitive identity numbers or private documents." required></textarea></div>
        </div><label class="checkbox-row"><input type="checkbox" name="consent" required /><span>I agree that the Sabai team may contact me about this request. I have not included OTPs, passwords or sensitive identity numbers.</span></label>
        <div class="form-submit-row"><button class="button" type="submit">Send support request <span aria-hidden="true">→</span></button><small>Keep the request reference to check status.</small></div></form>
        <div class="track-card"><h3>Track a support request</h3><p>Check a request already sent through this community help desk.</p><form class="track-form" data-track-form><div class="track-row"><input name="reference" aria-label="Support request reference number" placeholder="e.g. PMS-H-20261020-ABCDEF0123456789" maxlength="40" required /><button class="button button-small" type="submit">Check status</button></div><div class="tracking-result" aria-live="polite"></div></form></div>
      </div>
    </div></section>`;
}

function adminPage() {
  if (!adminToken) return `<section class="section section-soft"><div class="container admin-login-wrap"><form class="admin-login" id="admin-login" novalidate>
    <a class="brand" href="#home" data-page="home"><img src="/assets/logo.png" alt="" /><span><strong>பறையர் மகா சபை</strong><small>ADMINISTRATOR ACCESS</small></span></a>
    <h1>Team dashboard</h1><p>Sign in to review membership enquiries and community support requests.</p><div id="admin-login-message" class="form-message" role="status"></div>
    <div class="field"><label for="admin-username">Username</label><input id="admin-username" name="username" autocomplete="username" required /></div>
    <div class="field"><label for="admin-password">Password</label><input id="admin-password" name="password" type="password" autocomplete="current-password" required /></div>
    <button class="button" type="submit">Sign in to dashboard <span aria-hidden="true">→</span></button>
  </form></div></section>`;
  return `<section class="section section-soft"><div class="container"><div id="dashboard-root"><div class="admin-login-wrap"><p>Loading the secure dashboard…</p></div></div></div></section>`;
}

function stripInlineStyles(markup) {
  return markup.replace(/\sstyle="[^"]*"/g, '');
}

function renderPage() {
  document.documentElement.lang = currentPage === 'join' ? membershipLanguage : 'en';
  setActiveNav();
  switch (currentPage) {
    case 'services':
      main.innerHTML = stripInlineStyles(serviceDirectoryPage({ category: activeCategory, query: serviceSearch }));
      break;
    case 'education':
      main.innerHTML = stripInlineStyles(educationPage());
      break;
    case 'community':
      main.innerHTML = stripInlineStyles(communityPage());
      break;
    case 'join':
      main.innerHTML = stripInlineStyles(membershipPage());
      initializeLocationForm();
      const applicationDate = document.getElementById('member-date');
      if (applicationDate) {
        const now = new Date();
        applicationDate.value = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
      }
      break;
    case 'help':
      main.innerHTML = stripInlineStyles(helpPage());
      break;
    case 'admin':
      main.innerHTML = stripInlineStyles(adminPage());
      if (adminToken) loadDashboard();
      break;
    default:
      currentPage = 'home';
      main.innerHTML = stripInlineStyles(homePage());
  }
}

function openService(index) {
  const service = services[index];
  if (!service) return;
  if (serviceDialog) serviceDialog.remove();
  serviceDialog = document.createElement('dialog');
  serviceDialog.className = 'dialog';
  const list = (items) => items.map((item) => `<li>${escapeHtml(item)}</li>`).join('');
  serviceDialog.innerHTML = `<div class="dialog-head"><div><span class="service-tag">${escapeHtml(service.group)}</span><h2>${escapeHtml(service.title)}</h2><p>${escapeHtml(service.summary)}</p></div><button type="button" class="dialog-close" data-close-dialog aria-label="Close service guide">×</button></div>
    <div class="dialog-content"><section class="detail-block"><h3>Who may be eligible</h3><p>${escapeHtml(service.eligibility)}</p></section>
    <section class="detail-block"><h3>Prepare these records (confirm the live list)</h3><ul>${list(service.documents)}</ul></section>
    <section class="detail-block"><h3>Step-by-step process</h3><ol>${list(service.steps)}</ol></section>
    <div class="disclaimer"><strong>Important:</strong> ${escapeHtml(service.note)}</div>
    <div class="detail-actions"><a class="button" href="${escapeHtml(service.portal)}" target="_blank" rel="noopener noreferrer">Open official portal <span aria-hidden="true">↗</span></a><button class="button button-outline" type="button" data-request-service="${index}">Ask our community team</button></div></div>`;
  document.body.append(serviceDialog);
  serviceDialog.showModal();
}

function showFormMessage(id, text, kind = 'error') {
  const element = document.getElementById(id);
  if (!element) return;
  element.className = `form-message is-visible is-${kind}`;
  element.textContent = text;
}

function formValues(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function transliterateTamilCandidates(value, limit = 16) {
  const consonants = {
    zh: ['ழ்'], ng: ['ங்'], nj: ['ஞ்'], ny: ['ஞ்'], sh: ['ஷ்', 'ச்'], ch: ['ச்', 'ஷ்'],
    th: ['த்', 'ட்'], dh: ['த்', 'ட்'], kh: ['க்'], gh: ['க்'], ph: ['ப்'], bh: ['ப்'],
    wh: ['வ்'], k: ['க்'], g: ['க்'], c: ['ச்', 'க்'], s: ['ச்', 'ஸ்', 'ஷ்'], j: ['ஜ்'],
    t: ['ட்', 'த்'], d: ['ட்', 'த்'], p: ['ப்'], b: ['ப்'], m: ['ம்'], y: ['ய்'],
    r: ['ர்', 'ற்'], l: ['ல்', 'ள்', 'ழ்'], v: ['வ்'], w: ['வ்'], n: ['ன்', 'ண்', 'ந்'],
    h: ['ஹ்'], f: ['ஃப்'], q: ['க்'], x: ['க்ஸ்'],
  };
  const vowels = {
    ew: { independent: ['ஊ', 'உ'], signs: ['ூ', 'ு'] },
    aa: { independent: ['ஆ'], signs: ['ா'] }, ee: { independent: ['ஈ', 'ஏ'], signs: ['ீ', 'ே'] },
    ii: { independent: ['ஈ', 'இ'], signs: ['ீ', 'ி'] }, oo: { independent: ['ஊ', 'ஓ'], signs: ['ூ', 'ோ'] },
    uu: { independent: ['ஊ', 'உ'], signs: ['ூ', 'ு'] }, ai: { independent: ['ஐ'], signs: ['ை'] },
    au: { independent: ['ஆ', 'ஔ', 'ஓ'], signs: ['ா', 'ௌ', 'ோ'] },
    ou: { independent: ['ஔ', 'ஓ'], signs: ['ௌ', 'ோ'] }, a: { independent: ['அ', 'ஆ'], signs: ['', 'ா'] },
    i: { independent: ['இ', 'ஈ'], signs: ['ி', 'ீ'] }, u: { independent: ['உ', 'ஊ'], signs: ['ு', 'ூ'] },
    e: { independent: ['ஏ', 'எ'], signs: ['ே', 'ெ'] }, o: { independent: ['ஒ', 'ஓ'], signs: ['ொ', 'ோ'] },
  };
  const consonantKeys = Object.keys(consonants).sort((left, right) => right.length - left.length);
  const vowelKeys = Object.keys(vowels).sort((left, right) => right.length - left.length);
  const maxWordCandidates = 32;
  const expandCandidates = (candidates, additions, maxCandidates) => candidates
    .flatMap(({ text, score }) => additions.map((addition, index) => ({
      text: `${text}${addition}`,
      score: score + index,
    })))
    .sort((left, right) => left.score - right.score)
    .filter((candidate, index, all) => all.findIndex((item) => item.text === candidate.text) === index)
    .slice(0, maxCandidates);
  const wordCandidates = (word) => {
    let candidates = [{ text: '', score: 0 }];
    let index = 0;
    while (index < word.length) {
      const vowelKey = vowelKeys.find((key) => word.startsWith(key, index));
      const consonantKey = consonantKeys.find((key) => word.startsWith(key, index));
      let additions;
      let consumed;
      if (vowelKey && (!consonantKey || vowelKey.length >= consonantKey.length)) {
        let choices = vowels[vowelKey].independent;
        if (vowelKey === 'a' && /nd|nt/.test(word.slice(index + 1, index + 3))) choices = [...choices].reverse();
        additions = choices;
        consumed = vowelKey.length;
      } else if (consonantKey) {
        if (consonantKey.length === 1 && word.startsWith(consonantKey.repeat(2), index)) {
          const nextIndex = index + 2;
          const followingVowel = vowelKeys.find((key) => word.startsWith(key, nextIndex));
          let choices = consonants[consonantKey];
          if (consonantKey === 'n') choices = ['ண்', 'ன்', 'ந்'];
          const pairs = [
            ...choices.map((choice) => [choice, choice]),
            ...choices.flatMap((first, firstIndex) => choices
              .filter((_, secondIndex) => secondIndex !== firstIndex)
              .map((second) => [first, second])),
          ];
          additions = pairs.flatMap(([first, second]) => {
            const firstBase = first.replace(/்$/, '');
            const secondBase = second.replace(/்$/, '');
            const signs = followingVowel ? vowels[followingVowel].signs : ['்'];
            return signs.map((sign) => `${firstBase}்${secondBase}${sign}`);
          });
          consumed = 2 + (followingVowel?.length || 0);
          candidates = expandCandidates(candidates, additions, maxWordCandidates);
          index += consumed;
          continue;
        }
        const nextIndex = index + consonantKey.length;
        const followingVowel = vowelKeys.find((key) => word.startsWith(key, nextIndex));
        let consonantChoices = consonants[consonantKey];
        if (consonantKey === 'n' && /^[dt]/.test(word.slice(nextIndex))) {
          consonantChoices = ['ண்', 'ன்', 'ந்'];
        }
        if (consonantKey === 's' && /^[bcdfghjklmnpqrstvwxyz]/.test(word.slice(nextIndex))) {
          consonantChoices = ['ஸ்', 'ச்', 'ஷ்'];
        }
        if (followingVowel) {
          additions = consonantChoices.flatMap((consonant) => {
            const base = consonant.replace(/்$/, '');
            return vowels[followingVowel].signs.map((sign) => `${base}${sign}`);
          });
          consumed = consonantKey.length + followingVowel.length;
        } else {
          additions = consonantChoices;
          consumed = consonantKey.length;
        }
      } else {
        additions = [word[index]];
        consumed = 1;
      }
      candidates = expandCandidates(candidates, additions, maxWordCandidates);
      index += consumed;
    }
    return candidates.map(({ text }) => text);
  };

  let candidates = [{ text: '', score: 0 }];
  const commonTamilAddressTerms = [
    [/\bTamil\s+Nadu\b/gi, 'தமிழ்நாடு'],
    [/\bTirunelveli\b/gi, 'திருநெல்வேலி'],
    [/\bChennai\b/gi, 'சென்னை'],
    [/\bKanyakumari\b/gi, 'கன்னியாகுமரி'],
    [/\bCoimbatore\b/gi, 'கோயம்புத்தூர்'],
    [/\bMadurai\b/gi, 'மதுரை'],
    [/\bSalem\b/gi, 'சேலம்'],
    [/\bMain\s+Road\b/gi, 'மெயின் ரோடு'],
    [/\bStreet\b/gi, 'தெரு'],
    [/\bRoad\b/gi, 'ரோடு'],
  ];
  const source = commonTamilAddressTerms.reduce(
    (text, [pattern, replacement]) => text.replace(pattern, replacement),
    String(value),
  );
  const parts = source.split(/([A-Za-z]\.|[A-Za-z]+)/g);
  for (const token of parts) {
    if (!token) continue;
    if (!/^[A-Za-z]/.test(token)) {
      candidates = candidates.map((candidate) => ({ ...candidate, text: `${candidate.text}${token}` }));
      continue;
    }
    const initial = token.length === 2 && token.endsWith('.');
    const word = initial ? token[0].toLowerCase() : token.toLowerCase();
    let options = wordCandidates(word);
    if (initial && consonants[word]) {
      const base = consonants[word][0].replace(/்$/, '');
      options = [`${base}ெ.`, `${base}ி.`, `${base}.`];
    }
    candidates = expandCandidates(candidates, options, limit);
  }
  return candidates.map(({ text }) => text);
}

function renderTamilSuggestions(input) {
  const field = input.closest('.tamil-input-field');
  const list = field?.querySelector('.tamil-suggestions');
  if (!list) return;
  const value = input.value.trim();
  if (!/[A-Za-z]/.test(value)) {
    list.hidden = true;
    list.replaceChildren();
    input.setAttribute('aria-expanded', 'false');
    input.removeAttribute('aria-controls');
    input.removeAttribute('aria-activedescendant');
    return;
  }

  const suggestions = transliterateTamilCandidates(value)
    .filter((suggestion) => /[\u0B80-\u0BFF]/.test(suggestion));
  list.innerHTML = suggestions.map((suggestion, index) => (
    `<button class="lookup-option" type="button" role="option" aria-selected="false" id="${escapeHtml(input.id)}-suggestion-${index}" data-tamil-suggestion="${escapeHtml(suggestion)}" data-tamil-input="${escapeHtml(input.id)}">${escapeHtml(suggestion)}</button>`
  )).join('');
  list.hidden = suggestions.length === 0;
  list.dataset.activeIndex = '-1';
  input.setAttribute('aria-expanded', String(suggestions.length > 0));
  if (suggestions.length) input.setAttribute('aria-controls', list.id);
}

function getFormAddressForTamil(form) {
  const value = (name) => {
    const field = form.elements.namedItem(name);
    if (!field || !('value' in field)) return '';
    if (field instanceof HTMLSelectElement) {
      if (!field.value) return '';
      const option = field.selectedOptions[0];
      return String(option?.dataset.ta || field.value || '').trim();
    }
    return String(field.value || '').trim();
  };
  const talukSelect = form.querySelector('#member-taluk-select');
  const taluk = talukSelect?.value === '__other__'
    ? form.querySelector('#member-taluk-other')?.value
    : (talukSelect?.value ? talukSelect.selectedOptions[0]?.textContent : value('taluk'));
  const localBodyType = value('localBodyType');
  const localBody = value(localBodyType);
  return [
    value('street'),
    value('villageArea'),
    localBody,
    taluk,
    value('district'),
    value('state'),
    value('pinCode'),
  ].filter(Boolean).join(', ');
}

function isEnglishAddressField(field) {
  return ['street', 'villageArea', 'localBodyType', 'corporation', 'municipality', 'townPanchayat', 'panchayat', 'taluk', 'district', 'state', 'pinCode'].includes(field.name)
    || ['member-taluk-select', 'member-taluk-other'].includes(field.id);
}

function updateTamilAddressSuggestion(form, fallbackAddress = '') {
  const input = form.querySelector('[name="addressTamil"]');
  if (!input || (input.value.trim() && input.dataset.generatedTamil !== input.value)) return;
  const englishAddress = getFormAddressForTamil(form) || fallbackAddress;
  if (!englishAddress) return;
  const suggestion = transliterateTamilCandidates(englishAddress, 1)[0]?.trim();
  if (!suggestion) return;
  input.value = suggestion;
  input.dataset.generatedTamil = suggestion;
  input.dispatchEvent(new Event('input', { bubbles: true }));
}

function closeTamilSuggestions(input) {
  const field = input.closest('.tamil-input-field');
  const list = field?.querySelector('.tamil-suggestions');
  if (!list) return;
  list.hidden = true;
  list.replaceChildren();
  delete list.dataset.activeIndex;
  input.setAttribute('aria-expanded', 'false');
  input.removeAttribute('aria-controls');
  input.removeAttribute('aria-activedescendant');
}

function applyTamilSuggestion(input, suggestion) {
  input.value = suggestion;
  closeTamilSuggestions(input);
  input.focus();
  input.dispatchEvent(new Event('input', { bubbles: true }));
}

async function prepareMemberPhoto(file) {
  if (!file || !/^image\/(jpeg|png|webp)$/.test(file.type)) {
    throw new Error('Choose a JPEG, PNG or WebP member photo.');
  }
  if (file.size > 12 * 1024 * 1024) throw new Error('Choose a photo smaller than 12 MB.');
  const imageSource = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('The selected photo could not be read.'));
    reader.readAsDataURL(file);
  });
  const image = new Image();
  await new Promise((resolve, reject) => {
    image.onload = resolve;
    image.onerror = () => reject(new Error('The selected photo could not be opened.'));
    image.src = imageSource;
  });
  const scale = Math.min(1, 1000 / Math.max(image.naturalWidth, image.naturalHeight));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
  canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Photo processing is unavailable in this browser.');
  context.fillStyle = '#ffffff';
  context.fillRect(0, 0, canvas.width, canvas.height);
  for (let attempt = 0; attempt < 6; attempt += 1) {
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', Math.max(0.48, 0.86 - attempt * 0.08));
    const encodedSize = Math.ceil((dataUrl.length - dataUrl.indexOf(',') - 1) * 0.75);
    if (encodedSize <= 250 * 1024) return dataUrl;
    canvas.width = Math.max(1, Math.round(canvas.width * 0.82));
    canvas.height = Math.max(1, Math.round(canvas.height * 0.82));
  }
  throw new Error('This photo cannot be compressed below 250 KB. Choose a smaller photo.');
}

async function submitMembership(form) {
  const button = form.querySelector('button[type="submit"]');
  const data = formValues(form);
  const photoFile = data.photo;
  delete data.photo;
  data.consent = form.elements.consent.checked;
  button.disabled = true;
  try {
    data.photoData = await prepareMemberPhoto(photoFile);
    const talukSelect = form.querySelector('#member-taluk-select');
    data.taluk = talukSelect.value === '__other__'
      ? form.querySelector('#member-taluk-other').value.trim()
      : talukSelect.value;
    const result = await api('/api/members', { method: 'POST', body: JSON.stringify(data) });
    lastRegisteredMember = result.member;
    const resultCard = document.getElementById('membership-result-card');
    resultCard.innerHTML = `<h2>Registration complete</h2><p>${escapeHtml(result.message)}</p><span class="membership-result-number">${escapeHtml(result.membershipId)}</span><p><strong>Reference:</strong> ${escapeHtml(result.reference)}<br /><strong>Payment:</strong> ${escapeHtml(result.paymentStatus)} · ₹${escapeHtml(result.fee)}</p><div class="form-submit-row"><button class="button" type="button" data-new-member-card>Print member ID card</button><button class="button button-outline" type="button" data-new-member-reset>Register another member</button></div>`;
    resultCard.hidden = false;
    form.closest('.membership-form-card').hidden = true;
    const trackingInput = document.querySelector('.membership-track-card [name="reference"]');
    if (trackingInput) trackingInput.value = result.reference;
    form.reset();
    const preview = document.getElementById('member-photo-preview');
    if (preview) {
      if (preview.dataset.objectUrl) URL.revokeObjectURL(preview.dataset.objectUrl);
      preview.removeAttribute('src');
      preview.hidden = true;
      delete preview.dataset.objectUrl;
    }
  } catch (error) {
    showFormMessage('membership-message', error.message);
  } finally {
    button.disabled = false;
  }
}

async function submitHelp(form) {
  const button = form.querySelector('button[type="submit"]');
  const data = formValues(form);
  data.consent = form.elements.consent.checked;
  button.disabled = true;
  try {
    const result = await api('/api/requests', { method: 'POST', body: JSON.stringify(data) });
    showFormMessage('help-message', `${result.message} Reference: ${result.reference}`, 'success');
    form.reset();
  } catch (error) {
    showFormMessage('help-message', error.message);
  } finally {
    button.disabled = false;
  }
}

async function submitTrack(form) {
  const result = form.querySelector('.tracking-result');
  const reference = form.elements.reference.value.trim().toUpperCase();
  result.textContent = 'Checking…';
  try {
    const data = await api(`/api/track/${encodeURIComponent(reference)}`);
    const membershipDetails = data.paymentStatus
      ? `<br />Membership ID ${escapeHtml(data.membershipId)} · Payment ${escapeHtml(data.paymentStatus)} · Fee ₹${escapeHtml(data.fee)}`
      : '';
    result.innerHTML = `<div class="form-message is-visible is-success"><strong>${escapeHtml(data.type)}</strong><br />Reference ${escapeHtml(data.reference)} · <span class="status-pill" data-status="${escapeHtml(data.status)}">${escapeHtml(data.status)}</span>${membershipDetails}<br />Received ${escapeHtml(formatDate(data.received))} · Updated ${escapeHtml(formatDate(data.updated))}</div>`;
  } catch (error) {
    result.innerHTML = `<div class="form-message is-visible is-error">${escapeHtml(error.message)}</div>`;
  }
}

function statusPill(status) {
  return `<span class="status-pill" data-status="${escapeHtml(status)}">${escapeHtml(status)}</span>`;
}

function memberRows(members) {
  const rows = members.map((member) => `<tr data-member-search="${escapeHtml([
    member.fullName, member.membershipId, member.id, member.mobile, member.email,
    member.district, member.localBodyName, member.taluk, member.pinCode,
    member.assemblyConstituency, member.parliamentaryConstituency,
  ].join(' ').toLowerCase())}">
    <td><strong>${escapeHtml(member.fullName)}</strong><small>${escapeHtml(member.membershipId || member.id)} · ${escapeHtml(member.district)}</small><small>${escapeHtml(member.gender || '')} · DOB ${escapeHtml(formatDate(member.dateOfBirth))}</small>${member.archivedAt ? `<small>${statusPill('Archived')}</small>` : ''}</td>
    <td>${escapeHtml(member.mobile)}${member.email ? `<small>${escapeHtml(member.email)}</small>` : ''}${member.whatsapp ? `<small>WhatsApp ${escapeHtml(member.whatsapp)}</small>` : ''}</td>
    <td><strong>${escapeHtml(member.occupation || '—')}</strong><small>${escapeHtml(member.localBodyName || '')}${member.street ? `, ${escapeHtml(member.street)}` : ''}${member.villageArea ? `, ${escapeHtml(member.villageArea)}` : ''} · ${escapeHtml(member.district)} · ${escapeHtml(member.pinCode || '')}</small><small>Assembly: ${escapeHtml(member.assemblyConstituency || '—')} · Parliament: ${escapeHtml(member.parliamentaryConstituency || '—')}</small><small>UTR ${escapeHtml(member.upiTransactionId || 'Not provided')}</small></td>
    <td>${statusPill(member.archivedAt ? 'Archived' : member.status || 'Active member')}<small>${statusPill(member.paymentStatus || 'Pending verification')}</small><small>₹${escapeHtml(member.membershipFee || 500)} · ${escapeHtml(formatDate(member.createdAt))}</small></td>
    <td><div class="table-actions">${!member.archivedAt ? `<select aria-label="Payment verification status for ${escapeHtml(member.membershipId || member.id)}" data-payment-status="${escapeHtml(member.id)}">${['Pending verification', 'Verified', 'Needs review'].map((status) => `<option${status === (member.paymentStatus || 'Pending verification') ? ' selected' : ''}>${status}</option>`).join('')}</select><button class="mini-button is-positive" type="button" data-update-payment="${escapeHtml(member.id)}">Update payment</button><button class="mini-button" type="button" data-edit-member="${escapeHtml(member.id)}">Edit details</button><button class="mini-button" type="button" data-print-card="${escapeHtml(member.id)}">Generate ID card</button><button class="mini-button is-danger" type="button" data-archive-member="${escapeHtml(member.id)}">Archive member</button>` : `<button class="mini-button is-positive" type="button" data-restore-member="${escapeHtml(member.id)}">Restore member</button>`}</div></td>
  </tr>`).join('');
  return `${rows}<tr data-empty-members${members.length ? ' hidden' : ''}><td class="table-empty" colspan="5">No members match these filters.</td></tr>`;
}

function updateAdminMemberSearch() {
  const root = document.getElementById('dashboard-root');
  if (!root) return;
  const query = adminMemberSearch.trim().toLowerCase();
  const rows = [...root.querySelectorAll('tr[data-member-search]')];
  let visible = 0;
  for (const row of rows) {
    row.hidden = !row.dataset.memberSearch.includes(query);
    if (!row.hidden) visible += 1;
  }
  const emptyRow = root.querySelector('[data-empty-members]');
  if (emptyRow) emptyRow.hidden = visible !== 0;
  const count = root.querySelector('.admin-result-count');
  if (count) count.textContent = `Showing ${visible} of ${dashboardData?.members.length || 0} members`;
}

function requestRows(requests) {
  if (!requests.length) return '<tr><td class="table-empty" colspan="5">No community support requests yet.</td></tr>';
  const statuses = ['Received', 'In progress', 'Referred', 'Resolved', 'Closed'];
  return requests.map((item) => `<tr>
    <td><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.id)}</small></td>
    <td>${escapeHtml(item.mobile)}</td>
    <td><strong>${escapeHtml(item.category)}</strong><small>${escapeHtml(item.message)}</small></td>
    <td>${statusPill(item.status)}<small>${escapeHtml(formatDate(item.createdAt))}</small></td>
    <td><div class="table-actions"><select aria-label="New status for ${escapeHtml(item.id)}" data-request-status="${escapeHtml(item.id)}">${statuses.map((status) => `<option${status === item.status ? ' selected' : ''}>${status}</option>`).join('')}</select><button class="mini-button" type="button" data-update-request="${escapeHtml(item.id)}">Update</button></div></td>
  </tr>`).join('');
}

function drawDashboard() {
  const root = document.getElementById('dashboard-root');
  if (!root || !dashboardData) return;
  const { stats, members, requests } = dashboardData;
  const memberTab = adminTab === 'members';
  const filteredMembers = members.filter((member) => {
    const archived = Boolean(member.archivedAt);
    if (adminMemberStatusFilter === 'active' && archived) return false;
    if (adminMemberStatusFilter === 'archived' && !archived) return false;
    if (adminPaymentFilter !== 'all' && member.paymentStatus !== adminPaymentFilter) return false;
    return true;
  });
  root.innerHTML = `<div class="dashboard-head"><div><p class="section-kicker">Parayar Maha Sabai · Team access</p><h1>Community dashboard</h1><p>Manage member records, payment verification, support requests and printable ID cards.</p></div><div class="dashboard-head-actions"><button class="button button-outline button-small" type="button" id="admin-refresh">Refresh data</button><button class="button button-outline button-small" type="button" id="admin-logout">Sign out</button></div></div>
    <div class="stat-grid"><article class="stat-card"><span>ACTIVE MEMBERS</span><strong>${stats.members}</strong></article><article class="stat-card"><span>ARCHIVED MEMBERS</span><strong>${stats.archivedMembers || 0}</strong></article><article class="stat-card"><span>PAYMENTS TO VERIFY</span><strong>${stats.pendingPayments}</strong></article><article class="stat-card"><span>SUPPORT REQUESTS</span><strong>${stats.requests}</strong></article><article class="stat-card"><span>OPEN REQUESTS</span><strong>${stats.openRequests}</strong></article></div>
    <section class="dashboard-panel"><div class="dashboard-tabs" role="tablist" aria-label="Dashboard records"><button class="dashboard-tab${memberTab ? ' is-active' : ''}" role="tab" aria-selected="${memberTab}" type="button" data-dashboard-tab="members">Membership (${members.length})</button><button class="dashboard-tab${!memberTab ? ' is-active' : ''}" role="tab" aria-selected="${!memberTab}" type="button" data-dashboard-tab="requests">Support requests (${requests.length})</button></div>
    ${memberTab ? `<div class="admin-toolbar"><label class="admin-search"><span>Search members</span><input id="admin-member-search" type="search" value="${escapeHtml(adminMemberSearch)}" placeholder="Name, ID, mobile, district, PIN…" /></label><label><span>Record view</span><select id="admin-member-filter"><option value="active"${adminMemberStatusFilter === 'active' ? ' selected' : ''}>Active members</option><option value="archived"${adminMemberStatusFilter === 'archived' ? ' selected' : ''}>Archived members</option><option value="all"${adminMemberStatusFilter === 'all' ? ' selected' : ''}>All members</option></select></label><label><span>Payment</span><select id="admin-payment-filter"><option value="all"${adminPaymentFilter === 'all' ? ' selected' : ''}>All payment states</option>${['Pending verification', 'Verified', 'Needs review'].map((status) => `<option value="${escapeHtml(status)}"${adminPaymentFilter === status ? ' selected' : ''}>${escapeHtml(status)}</option>`).join('')}</select></label><button class="button button-small" type="button" data-add-member>Add member</button><button class="button button-outline button-small" type="button" id="admin-export-members">Export CSV</button><span class="admin-result-count">Showing ${filteredMembers.length} of ${members.length}</span></div>` : ''}
    <div class="table-wrap"><table class="dashboard-table"><thead><tr>${memberTab ? '<th>Member</th><th>Contact</th><th>Address / electoral / UTR</th><th>Membership / payment</th><th>Actions</th>' : '<th>Requester</th><th>Contact</th><th>Request</th><th>Status</th><th>Update status</th>'}</tr></thead><tbody>${memberTab ? memberRows(filteredMembers) : requestRows(requests)}</tbody></table></div></section>
    <p class="hero-note"><span class="stamp-mark" aria-hidden="true">!</span><span>Handle member contact details carefully. Do not ask applicants to send Aadhaar numbers, OTPs, passwords or identity scans by email or public message.</span></p>`;
  updateAdminMemberSearch();
}

function openAdminMemberDialog(member = null) {
  const editing = Boolean(member);
  const districts = Object.keys(window.pmsLocationData.districts);
  const bodyTypes = window.pmsLocationData.localBodyTypes;
  const setSelectValue = (select, value) => {
    const normalized = String(value ?? '').trim().toLowerCase();
    const option = [...select.options].find((item) => item.value.toLowerCase() === normalized);
    select.value = option?.value || '';
    return Boolean(option);
  };
  const selectOptions = (items, value = '') => items.map((item) => `<option value="${escapeHtml(item.value)}"${item.value === value ? ' selected' : ''}>${escapeHtml(item.label)}</option>`).join('');
  const textField = (name, label, type = 'text', required = true, extra = '') => `<label class="field"><span>${escapeHtml(label)}${required ? ' *' : ''}</span><input name="${name}" type="${type}" ${required ? 'required' : ''} ${extra} /></label>`;
  const tamilTextField = (name, label, required, placeholder = '') => {
    const id = `admin-${name}`;
    return `<div class="field tamil-input-field"><label for="${id}">${escapeHtml(label)}${required ? ' *' : ''}</label><input id="${id}" name="${name}" type="text" lang="ta" maxlength="100" autocomplete="off" role="combobox" aria-autocomplete="list" aria-expanded="false" ${placeholder ? `placeholder="${escapeHtml(placeholder)}"` : ''} ${required ? 'required' : ''} data-tamil-input /><div id="${id}-suggestions" class="tamil-suggestions" role="listbox" aria-label="Tamil suggestions" hidden></div><small>Type in English for Tamil suggestions, then choose a suggestion or edit it.</small></div>`;
  };
  const tamilAddressField = () => {
    const id = 'admin-addressTamil';
    return `<div class="field field-full tamil-input-field"><label for="${id}">Full address in Tamil${editing ? '' : ' *'}</label><textarea id="${id}" name="addressTamil" lang="ta" rows="3" maxlength="500" placeholder="வீட்டு எண், தெரு, பகுதி, வட்டம், மாவட்டம், PIN குறியீடு" autocomplete="off" role="combobox" aria-autocomplete="list" aria-expanded="false" ${editing ? '' : 'required'} data-tamil-input></textarea><div id="${id}-suggestions" class="tamil-suggestions" role="listbox" aria-label="Tamil suggestions" hidden></div><small>A Tamil draft is generated from the English address fields. Review and edit it before saving; typing English here shows alternate suggestions.</small></div>`;
  };
  const selectField = (name, label, options, required = true, id = '') => `<label class="field"><span>${escapeHtml(label)}${required ? ' *' : ''}</span><select name="${name}" ${id ? `id="${id}"` : ''} ${required ? 'required' : ''}><option value="">Choose an option</option>${options}</select></label>`;
  const bodyFields = bodyTypes.map(({ field: name, en }) => `<label class="field" data-location-field="${name}" hidden><span>${escapeHtml(en)} *</span><input name="${name}" type="text" maxlength="100" disabled required /></label>`).join('');
  if (memberDialog) memberDialog.remove();
  memberDialog = document.createElement('dialog');
  memberDialog.className = 'dialog member-edit-dialog';
  memberDialog.innerHTML = `<div class="dialog-head"><div><h2>${editing ? 'Edit member details' : 'Add a member'}</h2><p>${editing ? `Membership ID ${escapeHtml(member.membershipId || member.id)} · Leave the Aadhaar field blank to keep the current encrypted value.` : 'Create a member record and assign a membership ID. A photo and Aadhaar number are optional.'}</p></div><button type="button" class="dialog-close" data-close-dialog aria-label="Close member form">×</button></div>
    <form id="admin-member-form" class="dialog-content admin-member-form" novalidate data-member-id="${editing ? escapeHtml(member.id) : ''}">
      <div class="admin-form-section">Personal details</div>
      <div class="admin-member-grid">
        ${textField('fullName', 'Full name')}
        ${tamilTextField('fullNameTamil', 'Name in Tamil', !editing, 'வெ. சுரேஷ்')}
        ${selectField('gender', 'Gender', selectOptions([{ value: 'Male', label: 'Male' }, { value: 'Female', label: 'Female' }, { value: 'Other', label: 'Other' }] ))}
        ${selectField('guardianRelation', 'Parent / spouse relationship', selectOptions([{ value: 'S/o', label: 'Son of (S/o)' }, { value: 'D/o', label: 'Daughter of (D/o)' }, { value: 'W/o', label: 'Wife of (W/o)' }] ))}
        ${textField('guardianName', 'Parent / spouse name')}
        ${tamilTextField('guardianNameTamil', 'Parent / spouse name in Tamil', !editing)}
        ${textField('dateOfBirth', 'Date of birth', 'date')}
        ${textField('occupation', 'Occupation')}
        ${selectField('bloodGroup', 'Blood group', selectOptions(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown'].map((value) => ({ value, label: value === 'Unknown' ? 'Not known' : value }))))}
        ${textField('mobile', 'Mobile number', 'tel', true, 'inputmode="tel" maxlength="18" autocomplete="tel"')}
        ${textField('email', 'Email address', 'email', false, 'maxlength="254" autocomplete="email"')}
        ${textField('whatsapp', 'WhatsApp number', 'tel', false, 'inputmode="tel" maxlength="18"')}
        ${textField('country', 'Country')}
        ${textField('state', 'State')}
      </div>
      <div class="admin-form-section">Address and representation</div>
      <div class="admin-member-grid">
        ${selectField('district', 'District', selectOptions(districts.map((value) => ({ value, label: value })), ''), true, 'member-district')}
        <label class="field"><span>Revenue taluk *</span><select id="member-taluk-select" name="taluk" required disabled><option value="">Choose a district first</option></select><input id="member-taluk-other" type="text" maxlength="80" placeholder="Enter taluk name" hidden disabled /></label>
        ${selectField('localBodyType', 'Local government type', selectOptions(bodyTypes.map(({ value, en }) => ({ value, label: en }))), true, 'member-local-body-type')}
        ${bodyFields}
        <label class="field" data-location-field="wardNumber" hidden><span>Ward number (if applicable)</span><input name="wardNumber" type="text" maxlength="30" disabled /></label>
        ${selectField('assemblyConstituency', 'Assembly constituency', selectOptions(window.pmsConstituencyData.assemblyConstituencies.map((value) => ({ value, label: value }))), true, 'member-assembly')}
        ${selectField('parliamentaryConstituency', 'Parliament constituency', selectOptions(window.pmsConstituencyData.parliamentaryConstituencies.map((value) => ({ value, label: value }))), true, 'member-parliament')}
        ${textField('pinCode', 'PIN code', 'text', true, 'inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="postal-code"')}
        ${textField('street', 'Door number / street')}
        ${textField('villageArea', 'Village / area')}
        ${tamilAddressField()}
      </div>
      <div class="admin-form-section">Membership and verification</div>
      <div class="admin-member-grid">
        ${selectField('status', 'Membership status', selectOptions([{ value: 'Active member', label: 'Active member' }, { value: 'Inactive', label: 'Inactive' }]))}
        ${selectField('paymentStatus', 'Payment verification', selectOptions(['Pending verification', 'Verified', 'Needs review'].map((value) => ({ value, label: value }))))}
        ${textField('upiTransactionId', 'UPI transaction ID / UTR', 'text', false, 'maxlength="30"')}
        <label class="field admin-photo-field"><span>${editing ? 'Replace member photo (optional)' : 'Member photo (optional)'}</span><input id="admin-member-photo" name="adminPhoto" type="file" accept="image/jpeg,image/png,image/webp" /><small id="admin-photo-status" class="admin-photo-status">${editing && member.photoData ? 'Current photo is saved. Select a file to replace it.' : 'No photo saved. Select a photo to add it to the membership card.'}</small><img id="admin-photo-preview" class="admin-photo-preview" alt="Selected member photo preview" hidden /></label>
        <label class="field"><span>Set / replace Aadhaar number (optional)</span><input name="aadhaarNumber" type="password" inputmode="numeric" autocomplete="off" maxlength="14" placeholder="Leave blank to keep existing value" /></label>
      </div>
      <p class="admin-privacy-note">Aadhaar is never shown in the dashboard and is encrypted when saved. Member photos are also encrypted at rest. Verify payment against the recipient’s records; a UTR alone is not proof of payment.</p>
      <p id="admin-member-save-status" class="admin-save-status" role="status" aria-live="polite" hidden></p>
      <div class="admin-form-actions"><button class="button button-outline" type="button" data-close-dialog>Cancel</button><button class="button" type="submit">${editing ? 'Save member changes' : 'Create member'}</button></div>
    </form>`;
  document.body.append(memberDialog);
  const form = memberDialog.querySelector('#admin-member-form');
  const districtSelect = form.querySelector('#member-district');
  const talukSelect = form.querySelector('#member-taluk-select');
  const otherTaluk = form.querySelector('#member-taluk-other');
  if (member?.photoData) {
    const photoPreview = form.querySelector('#admin-photo-preview');
    photoPreview.src = member.photoData;
    photoPreview.hidden = false;
  }
  if (member) {
    const dependentSelects = new Set(['district', 'taluk', 'localBodyType', 'assemblyConstituency', 'parliamentaryConstituency']);
    for (const [name, value] of Object.entries(member)) {
      if (dependentSelects.has(name)) continue;
      const input = form.elements.namedItem(name);
      if (!input || !('value' in input) || ['photoData', 'photoEncrypted', 'aadhaarEncrypted'].includes(name)) continue;
      if (input instanceof HTMLSelectElement) setSelectValue(input, value);
      else input.value = value ?? '';
    }
    setSelectValue(districtSelect, member.district);
  } else {
    form.elements.country.value = 'India';
    form.elements.state.value = 'Tamil Nadu';
    form.elements.status.value = 'Active member';
    form.elements.paymentStatus.value = 'Pending verification';
  }
  updateTalukOptions(form, districtSelect.value);
  if (member?.taluk) {
    if (!setSelectValue(talukSelect, member.taluk)) {
      talukSelect.value = '__other__';
      otherTaluk.hidden = false;
      otherTaluk.disabled = false;
      otherTaluk.required = true;
      otherTaluk.value = member.taluk;
    }
  }
  form.elements.localBodyType.disabled = !districtSelect.value;
  updateLocalBodyFields(form);
  if (member) {
    if (!setSelectValue(form.elements.localBodyType, member.localBodyType)) {
      const inferredType = bodyTypes.find(({ field }) => member[field]);
      if (inferredType) setSelectValue(form.elements.localBodyType, inferredType.value);
    }
    updateLocalBodyFields(form);
    const selectedBody = bodyTypes.find(({ value }) => value === form.elements.localBodyType.value);
    if (selectedBody) {
      form.elements.namedItem(selectedBody.field).value = member[selectedBody.field] || member.localBodyName || '';
    }
    setSelectValue(form.elements.assemblyConstituency, member.assemblyConstituency);
    updateParliamentOptions(form, form.elements.assemblyConstituency.value);
    if (member.parliamentaryConstituency) {
      const mappedParliament = form.elements.parliamentaryConstituency.value;
      if (!setSelectValue(form.elements.parliamentaryConstituency, member.parliamentaryConstituency)) {
        form.elements.parliamentaryConstituency.value = mappedParliament;
      }
    }
  } else {
    updateParliamentOptions(form, '');
  }
  if (member) updateTamilAddressSuggestion(form, memberAddress(member));
  memberDialog.showModal();
}

function exportMembersCsv(members) {
  const columns = [
    ['Membership ID', 'membershipId'], ['Name', 'fullName'], ['பெயர்', 'fullNameTamil'], ['Mobile', 'mobile'], ['Email', 'email'],
    ['Gender', 'gender'], ['Date of birth', 'dateOfBirth'], ['Occupation', 'occupation'],
    ['Country', 'country'], ['State', 'state'], ['District', 'district'], ['Taluk', 'taluk'],
    ['Local body type', 'localBodyType'], ['Local body', 'localBodyName'], ['Ward', 'wardNumber'],
    ['Assembly constituency', 'assemblyConstituency'], ['Parliament constituency', 'parliamentaryConstituency'],
    ['PIN code', 'pinCode'], ['Street', 'street'], ['Area', 'villageArea'], ['முழு முகவரி', 'addressTamil'], ['Membership status', 'status'],
    ['Payment status', 'paymentStatus'], ['UPI reference', 'upiTransactionId'], ['Registered', 'createdAt'],
    ['Archived', 'archivedAt'],
  ];
  const quote = (value) => {
    let text = String(value ?? '');
    if (/^[\s]*[=+\-@]/.test(text)) text = `'${text}`;
    return `"${text.replaceAll('"', '""')}"`;
  };
  const csv = [columns.map(([label]) => quote(label)).join(','),
    ...members.map((member) => columns.map(([, key]) => quote(member[key])).join(','))].join('\r\n');
  const url = URL.createObjectURL(new Blob([`\uFEFF${csv}`], { type: 'text/csv;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = `parayar-mahasabai-members-${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

async function loadDashboard() {
  const root = document.getElementById('dashboard-root');
  if (!root) return;
  root.innerHTML = '<div class="admin-login-wrap"><p>Loading the secure dashboard…</p></div>';
  try {
    dashboardData = await api('/api/admin/overview');
    drawDashboard();
  } catch (error) {
    adminToken = '';
    localStorage.removeItem('pms_admin_token');
    dashboardData = null;
    root.innerHTML = '<div class="admin-login-wrap"><div class="admin-login"><h1>Sign in again</h1><p>Your admin session could not be verified.</p><button class="button" type="button" id="admin-retry">Return to sign in</button></div></div>';
    showToast(error.message, true);
  }
}

async function handleAdminLogin(form) {
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  try {
    const result = await api('/api/admin/login', { method: 'POST', body: JSON.stringify(formValues(form)) });
    adminToken = result.token;
    localStorage.setItem('pms_admin_token', adminToken);
    dashboardData = null;
    renderPage();
  } catch (error) {
    showFormMessage('admin-login-message', error.message);
  } finally {
    button.disabled = false;
  }
}

async function updateMemberPayment(id, paymentStatus) {
  const result = await api(`/api/admin/members/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify({ paymentStatus }) });
  dashboardData.members = dashboardData.members.map((member) => member.id === id ? result.member : member);
  await loadDashboard();
  showToast(`Payment status updated to ${paymentStatus}.`);
}

async function saveAdminMember(form) {
  if (!form.reportValidity()) return;
  const button = form.querySelector('[type="submit"]');
  const saveStatus = form.querySelector('#admin-member-save-status');
  const photoStatus = form.querySelector('#admin-photo-status');
  const originalButtonText = button.textContent;
  const setStatus = (message) => {
    saveStatus.textContent = message;
    saveStatus.hidden = false;
  };
  button.disabled = true;
  button.textContent = 'Saving…';
  setStatus('Saving member details. Please wait…');
  try {
    const memberId = form.dataset.memberId;
    const body = formValues(form);
    if (body.taluk === '__other__') body.taluk = form.querySelector('#member-taluk-other').value.trim();
    if (!body.taluk) throw new Error('Enter or select a revenue taluk.');
    const photo = form.elements.adminPhoto.files[0];
    if (photo) {
      if (photoStatus) photoStatus.textContent = 'Preparing photo for secure upload…';
      body.photoData = await prepareMemberPhoto(photo);
      setStatus('Photo prepared. Saving member details…');
    }
    const result = await api(memberId
      ? `/api/admin/members/${encodeURIComponent(memberId)}`
      : '/api/admin/members', {
      method: memberId ? 'PUT' : 'POST',
      body: JSON.stringify(body),
    });
    memberDialog?.close();
    memberDialog?.remove();
    memberDialog = null;
    await loadDashboard();
    showToast(memberId ? 'Member details updated.' : `Member created with ID ${result.member.membershipId}.`);
    if (!memberId) openMemberCard(result.member);
  } catch (error) {
    setStatus(`Could not save member details: ${error.message}`);
    if (photoStatus && form.elements.adminPhoto.files[0]) {
      photoStatus.textContent = 'Photo was not saved. Check the image and try again.';
    }
    showToast(error.message, true);
  } finally {
    if (button.isConnected) {
      button.disabled = false;
      button.textContent = originalButtonText;
    }
  }
}

async function archiveMember(id) {
  const member = dashboardData?.members.find((item) => item.id === id);
  if (!member || !window.confirm(`Archive ${member.fullName} (${member.membershipId})? This hides the member from the active list but keeps the record recoverable.`)) return;
  const result = await api(`/api/admin/members/${encodeURIComponent(id)}`, { method: 'DELETE' });
  dashboardData.members = dashboardData.members.map((item) => item.id === id ? result.member : item);
  await loadDashboard();
  showToast('Member archived. You can restore the record from the archived view.');
}

async function restoreMember(id) {
  await api(`/api/admin/members/${encodeURIComponent(id)}/restore`, { method: 'POST', body: '{}' });
  await loadDashboard();
  showToast('Member restored to the active list.');
}

async function updateRequest(id) {
  const select = document.querySelector(`[data-request-status="${CSS.escape(id)}"]`);
  if (!select) return;
  const result = await api(`/api/admin/requests/${encodeURIComponent(id)}`, { method: 'PUT', body: JSON.stringify({ status: select.value }) });
  dashboardData.requests = dashboardData.requests.map((item) => item.id === id ? result.request : item);
  dashboardData.stats.openRequests = dashboardData.requests.filter((item) => !['Resolved', 'Closed'].includes(item.status)).length;
  drawDashboard();
  showToast('Support request status updated.');
}

function setMemberCardMessage(message, kind = '') {
  const status = document.getElementById('member-card-message');
  if (!status) return;
  status.className = `form-message${message ? ` is-visible${kind ? ` is-${kind}` : ''}` : ''}`;
  status.textContent = message;
}

async function requestMemberCardCode(form, { resend = false } = {}) {
  if (!form.reportValidity()) return;
  const button = form.querySelector('[type="submit"]');
  if (button) button.disabled = true;
  setMemberCardMessage('Requesting a verification code…');
  try {
    const result = await api('/api/member-card/request-otp', {
      method: 'POST',
      body: JSON.stringify({
        membershipId: form.elements.membershipId.value.trim(),
        email: form.elements.email.value.trim(),
      }),
    });
    memberCardChallengeId = result.challengeId;
    memberCardDownloadToken = '';
    if (!resend) {
      document.getElementById('member-card-otp-form').hidden = false;
      form.hidden = true;
    }
    setMemberCardMessage(result.message, 'success');
  } catch (error) {
    setMemberCardMessage(error.message, 'error');
  } finally {
    if (button?.isConnected) button.disabled = false;
  }
}

async function verifyMemberCardCode(form) {
  if (!form.reportValidity() || !memberCardChallengeId) return;
  const button = form.querySelector('[type="submit"]');
  button.disabled = true;
  setMemberCardMessage('Verifying your email…');
  try {
    const result = await api('/api/member-card/verify-otp', {
      method: 'POST',
      body: JSON.stringify({ challengeId: memberCardChallengeId, otp: form.elements.otp.value.trim() }),
    });
    memberCardDownloadToken = result.downloadToken;
    form.hidden = true;
    document.getElementById('member-card-download-actions').hidden = false;
    setMemberCardMessage(result.message, 'success');
  } catch (error) {
    setMemberCardMessage(error.message, 'error');
  } finally {
    if (button.isConnected) button.disabled = false;
  }
}

function loadCardImage(source) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('A card image could not be loaded.'));
    image.src = source;
  });
}

function fitCardText(context, text, x, y, maxWidth, size = 20, weight = 500, color = '#14243a') {
  const value = String(text || '—');
  context.fillStyle = color;
  let fittedSize = size;
  context.font = `${weight} ${fittedSize}px "Nirmala UI", Arial, sans-serif`;
  while (fittedSize > 12 && context.measureText(value).width > maxWidth) {
    fittedSize -= 1;
    context.font = `${weight} ${fittedSize}px "Nirmala UI", Arial, sans-serif`;
  }
  context.fillText(value, x, y, maxWidth);
}

function drawMembershipBarcode(context, value, x, y, width, height) {
  const patterns = {
    '0': 'nnnwwnwnn', '1': 'wnnwnnnnw', '2': 'nnwwnnnnw', '3': 'wnwwnnnnn',
    '4': 'nnnwwnnnw', '5': 'wnnwwnnnn', '6': 'nnwwwnnnn', '7': 'nnnwnnwnw',
    '8': 'wnnwnnwnn', '9': 'nnwwnnwnn', A: 'wnnnnwnnw', B: 'nnwnnwnnw',
    C: 'wnwnnwnnn', D: 'nnnnwwnnw', E: 'wnnnwwnnn', F: 'nnwnwwnnn',
    G: 'nnnnwnwnw', H: 'wnnnwnwnn', I: 'nnwnwnwnn', J: 'nnnnwwwnn',
    K: 'wnnnnnwwn', L: 'nnwnnnwwn', M: 'wnwnnnnwn', N: 'nnnwnnnww',
    O: 'wnnwnnnwn', P: 'nnwwnnnwn', Q: 'nnnnnwnww', R: 'wnnnnwnwn',
    S: 'nnwnnwnwn', T: 'nnnnwwnwn', U: 'wwnnnnnnw', V: 'nwwnnnnnw',
    W: 'wwwnnnnnn', X: 'nwnwnnnnw', Y: 'wwnwnnnnn', Z: 'nwwwnnnnn',
    '-': 'nwnnnnwnw', '.': 'wwnnnnwnn', ' ': 'nwwnnnwnn', '$': 'nwnwnwnnn',
    '/': 'nwnwnnnwn', '+': 'nwnnnwnwn', '%': 'nnnwnwnwn', '*': 'nwnnwnwnn',
  };
  const characters = `*${String(value || '').toUpperCase().replace(/[^0-9A-Z .$/+%-]/g, '')}*`;
  const narrowUnits = 1;
  const wideUnits = 3;
  const characterGapUnits = 1;
  const totalUnits = [...characters].reduce((total, character) => {
    const pattern = patterns[character];
    return total + (pattern ? [...pattern].reduce((sum, bar) => sum + (bar === 'w' ? wideUnits : narrowUnits), 0) : 0);
  }, 0) + Math.max(0, characters.length - 1) * characterGapUnits;
  const unit = width / totalUnits;
  let cursor = x;
  context.fillStyle = '#111111';
  for (const character of characters) {
    const pattern = patterns[character];
    if (!pattern) continue;
    [...pattern].forEach((bar, index) => {
      const barWidth = (bar === 'w' ? wideUnits : narrowUnits) * unit;
      if (index % 2 === 0) context.fillRect(cursor, y, barWidth, height);
      cursor += barWidth;
    });
    if (character !== characters[characters.length - 1]) cursor += characterGapUnits * unit;
  }
}

function tamilDigits(value) {
  return String(value).replace(/\d/g, (digit) => '௦௧௨௩௪௫௬௭௮௯'[Number(digit)]);
}

function cardDate(value, tamil = false) {
  const match = String(value || '').match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (!match) return '—';
  const date = `${match[3]}.${match[2]}.${match[1]}`;
  return tamil ? tamilDigits(date) : date;
}

function wrapCardLines(context, value, maxWidth, maxLines = 3) {
  const words = String(value || '—').split(/\s+/);
  const lines = [];
  let line = '';
  for (const word of words) {
    const candidate = line ? `${line} ${word}` : word;
    if (line && context.measureText(candidate).width > maxWidth) {
      lines.push(line);
      line = word;
    } else {
      line = candidate;
    }
  }
  if (line) lines.push(line);
  if (lines.length > maxLines) {
    lines.length = maxLines;
    lines[maxLines - 1] = `${lines[maxLines - 1].slice(0, -1)}…`;
  }
  return lines;
}

function memberAddress(member) {
  if (member.address) return member.address;
  return [
    member.street,
    member.villageArea,
    member.localBodyName || member.townPanchayat || member.municipality || member.corporation || member.panchayat,
    member.taluk,
    member.district,
    member.state,
    member.pinCode,
  ].filter(Boolean).join(', ');
}

function tamilCardValue(value) {
  const text = String(value || '').trim();
  return text && !/[\u0B80-\u0BFF]/.test(text)
    ? transliterateTamilCandidates(text, 1)[0] || text
    : text || '—';
}

function createCardWatermark(logo) {
  const watermark = document.createElement('canvas');
  watermark.width = logo.width;
  watermark.height = logo.height;
  const context = watermark.getContext('2d', { willReadFrequently: true });
  if (!context) throw new Error('Membership card watermark is unavailable in this browser.');
  context.drawImage(logo, 0, 0);
  const image = context.getImageData(0, 0, watermark.width, watermark.height);
  for (let index = 0; index < image.data.length; index += 4) {
    const sourceAlpha = image.data[index + 3];
    const lightness = (image.data[index] + image.data[index + 1] + image.data[index + 2]) / 3;
    image.data[index + 3] = Math.round(sourceAlpha * Math.min(1, Math.max(0, 250 - lightness) / 80));
  }
  context.putImageData(image, 0, 0);
  return watermark;
}

function drawReferenceCard(canvas, template, member, photo, footer, logo, frontSeven, back = false) {
  const scale = 2;
  canvas.width = 640 * scale;
  canvas.height = 1018 * scale;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Membership card preview is unavailable in this browser.');
  context.scale(scale, scale);
  context.drawImage(template, 0, 0, 640, 1018);
  context.textBaseline = 'alphabetic';
  if (!back) {
    drawMembershipBarcode(context, member.membershipId, 18, 242, 272, 34);
    fitCardText(context, member.membershipId, 338, 271, 286, 35, 400, '#0064bd');
    context.drawImage(frontSeven, 0, 280, 640, 629);
    if (photo) {
      context.save();
      context.beginPath();
      context.roundRect(187, 301, 240, 315, 8);
      context.clip();
      const imageScale = Math.max(240 / photo.width, 315 / photo.height);
      const width = photo.width * imageScale;
      const height = photo.height * imageScale;
      context.drawImage(photo, 187 + (240 - width) / 2, 301 + (315 - height) / 2, width, height);
      context.restore();
    }
    context.strokeStyle = '#111111';
    context.lineWidth = 3;
    context.beginPath();
    context.roundRect(183, 297, 248, 323, 10);
    context.stroke();
    const valueX = 255;
    fitCardText(context, 'பெயர்:', 127, 660, 124, 30, 400, '#101010');
    fitCardText(context, member.fullNameTamil || '—', valueX, 660, 365, 30, 400, '#101010');
    fitCardText(context, 'NAME:', 127, 700, 124, 30, 400, '#101010');
    fitCardText(context, member.fullName, valueX, 700, 365, 30, 400, '#101010');
    fitCardText(context, 'த/பெ:', 137, 739, 114, 30, 400, '#101010');
    fitCardText(context, member.guardianNameTamil || '—', valueX, 739, 365, 30, 400, '#101010');
    const relationshipLabel = member.guardianRelation === 'W/o'
      ? 'W/o'
      : member.gender === 'Female'
        ? 'D/o'
        : member.gender === 'Male'
          ? 'S/o'
          : member.guardianRelation || 'S/o';
    fitCardText(context, `${relationshipLabel}:`, 172, 778, 79, 30, 400, '#101010');
    fitCardText(context, member.guardianName, valueX, 778, 365, 30, 400, '#101010');
    fitCardText(context, 'பி.நா.:', 127, 817, 124, 30, 400, '#101010');
    fitCardText(context, cardDate(member.dateOfBirth, true), valueX, 817, 365, 30, 400, '#101010');
    fitCardText(context, 'D.O.B:', 127, 855, 124, 30, 400, '#101010');
    fitCardText(context, cardDate(member.dateOfBirth), valueX, 855, 365, 30, 400, '#101010');
    const footerHeight = footer.height * 640 / footer.width;
    context.drawImage(footer, 0, 1018 - footerHeight, 640, footerHeight);
    return;
  }

  context.save();
  context.globalAlpha = 0.3;
  context.drawImage(createCardWatermark(logo), 45, 105, 550, 452);
  context.restore();
  fitCardText(context, `Blood Group : ${member.bloodGroup || '—'}`, 105, 88, 500, 26, 400, '#101010');
  fitCardText(context, `Membership No.: ${member.membershipId}`, 105, 128, 500, 25, 400, '#101010');
  fitCardText(context, `வார்டு எண்: ${member.wardNumber || '—'}`, 79, 207, 530, 24, 700, '#101010');
  fitCardText(context, `Ward No.: ${member.wardNumber || '—'}`, 79, 243, 530, 24, 700, '#101010');
  const localBodyName = member.localBodyName || member.townPanchayat || member.municipality || member.corporation || member.panchayat || '—';
  const localBodyLabels = {
    corporation: ['மாநகராட்சி', 'Corporation'],
    municipality: ['நகராட்சி', 'Municipality'],
    townPanchayat: ['பேரூராட்சி', 'Town Panchayat'],
    panchayat: ['கிராம ஊராட்சி', 'Village Panchayat'],
  };
  const [localBodyTamilLabel, localBodyEnglishLabel] = localBodyLabels[member.localBodyType] || ['உள்ளாட்சி அமைப்பு', 'Local body'];
  fitCardText(context, `${localBodyTamilLabel}: ${tamilCardValue(localBodyName)}`, 79, 279, 540, 24, 700, '#101010');
  fitCardText(context, `${localBodyEnglishLabel}: ${localBodyName}`, 79, 315, 540, 24, 700, '#101010');
  fitCardText(context, `சட்டமன்றத் தொகுதி: ${tamilCardValue(member.assemblyConstituency)}`, 79, 351, 530, 24, 700, '#101010');
  fitCardText(context, `MLA Constituency: ${member.assemblyConstituency || '—'}`, 79, 387, 530, 24, 700, '#101010');
  fitCardText(context, `நாடாளுமன்றத் தொகுதி: ${tamilCardValue(member.parliamentaryConstituency)}`, 79, 423, 530, 24, 700, '#101010');
  fitCardText(context, `MP Constituency: ${member.parliamentaryConstituency || '—'}`, 79, 459, 530, 24, 700, '#101010');
  context.font = '600 20px "Nirmala UI", Arial, sans-serif';
  const tamilAddress = member.addressTamil || transliterateTamilCandidates(memberAddress(member), 1)[0] || '—';
  const addressLines = wrapCardLines(context, `முகவரி: ${tamilAddress}`, 530, 3);
  addressLines.forEach((line, index) => {
    fitCardText(context, line, 79, 495 + index * 28, 530, 20, 600, '#101010');
  });
  const englishAddressLines = wrapCardLines(context, `Address: ${memberAddress(member)}`, 530, 2);
  englishAddressLines.forEach((line, index) => {
    fitCardText(context, line, 79, 583 + index * 28, 530, 20, 600, '#101010');
  });
}

async function renderMemberCardCanvases(member) {
  const [front, back, footer, photo, logo, frontSeven] = await Promise.all([
    loadCardImage('/assets/membership-card-front-template.png'),
    loadCardImage('/assets/membership-card-back-template.png'),
    loadCardImage('/assets/membership-card-footer.png?v=2'),
    member.photoData ? loadCardImage(member.photoData) : Promise.resolve(null),
    loadCardImage('/assets/logo.png'),
    loadCardImage('/assets/id-card-front-7.png'),
  ]);
  const frontCanvas = document.createElement('canvas');
  const backCanvas = document.createElement('canvas');
  drawReferenceCard(frontCanvas, front, member, photo, footer, logo, frontSeven);
  drawReferenceCard(backCanvas, back, member, photo, footer, logo, frontSeven, true);
  return [frontCanvas, backCanvas];
}

async function buildMemberCardPdf(member) {
  const canvases = await renderMemberCardCanvases(member);
  const encode = (value) => new TextEncoder().encode(value);
  const concatenate = (chunks) => {
    const result = new Uint8Array(chunks.reduce((total, chunk) => total + chunk.length, 0));
    let offset = 0;
    for (const chunk of chunks) {
      result.set(chunk, offset);
      offset += chunk.length;
    }
    return result;
  };
  const images = await Promise.all(canvases.map((canvas) => new Promise((resolve, reject) => {
    canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('The membership card PDF could not be created.')), 'image/jpeg', 0.96);
  })));
  const imageBytes = await Promise.all(images.map(async (image) => new Uint8Array(await image.arrayBuffer())));
  const pageWidth = 85 * 72 / 25.4;
  const pageHeight = pageWidth * 1018 / 640;
  const objects = [
    encode('<< /Type /Catalog /Pages 2 0 R >>'),
    encode('<< /Type /Pages /Kids [3 0 R 6 0 R] /Count 2 >>'),
  ];
  canvases.forEach((canvas, index) => {
    const pageObject = 3 + index * 3;
    const imageObject = pageObject + 1;
    const contentObject = pageObject + 2;
    const content = encode(`q\n${pageWidth} 0 0 ${pageHeight} 0 0 cm\n/Im0 Do\nQ\n`);
    objects.push(
      encode(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /XObject << /Im0 ${imageObject} 0 R >> >> /Contents ${contentObject} 0 R >>`),
      concatenate([encode(`<< /Type /XObject /Subtype /Image /Width ${canvas.width} /Height ${canvas.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${imageBytes[index].length} >>\nstream\n`), imageBytes[index], encode('\nendstream')]),
      concatenate([encode(`<< /Length ${content.length} >>\nstream\n`), content, encode('endstream')]),
    );
  });
  const chunks = [encode('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n')];
  const offsets = [0];
  let byteLength = chunks[0].length;
  objects.forEach((object, index) => {
    offsets.push(byteLength);
    const wrapped = concatenate([encode(`${index + 1} 0 obj\n`), object, encode('\nendobj\n')]);
    chunks.push(wrapped);
    byteLength += wrapped.length;
  });
  const xrefOffset = byteLength;
  const xref = `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n${offsets.slice(1).map((offset) => `${String(offset).padStart(10, '0')} 00000 n \n`).join('')}trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
  chunks.push(encode(xref));
  return new Blob([concatenate(chunks)], { type: 'application/pdf' });
}

async function downloadMemberCard() {
  const button = document.getElementById('member-card-download');
  if (!button || !memberCardChallengeId || !memberCardDownloadToken) return;
  button.disabled = true;
  setMemberCardMessage('Preparing your membership card PDF…');
  const token = memberCardDownloadToken;
  memberCardDownloadToken = '';
  try {
    const response = await fetch('/api/member-card/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ challengeId: memberCardChallengeId }),
    });
    const result = await response.json();
    if (!response.ok || result.success === false) throw new Error(result.message || `Request failed (${response.status}).`);
    const pdf = await buildMemberCardPdf(result.member);
    const url = URL.createObjectURL(pdf);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${result.member.membershipId.toLowerCase()}-membership-card.pdf`;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    memberCardChallengeId = '';
    document.getElementById('member-card-download-actions').hidden = true;
    document.getElementById('member-card-request-form').hidden = false;
    document.getElementById('member-card-request-form').reset();
    document.getElementById('member-card-otp-form').reset();
    setMemberCardMessage('Your membership card PDF has been downloaded.', 'success');
  } catch (error) {
    setMemberCardMessage(error.message, 'error');
  } finally {
    if (button.isConnected) button.disabled = false;
  }
}

async function openMemberCard(idOrMember) {
  const member = typeof idOrMember === 'string'
    ? dashboardData?.members.find((item) => item.id === idOrMember)
    : idOrMember;
  if (!member || !member.membershipId) {
    showToast('This member record does not have a membership number.', true);
    return;
  }
  idCardMember = member;
  if (idDialog) idDialog.remove();
  idDialog = document.createElement('dialog');
  idDialog.className = 'dialog id-dialog';
  idDialog.innerHTML = stripInlineStyles(`<div class="dialog-head no-print"><div><h2>Printable member ID</h2><p>Check the member details before printing. The card intentionally contains no Aadhaar number.</p></div><button type="button" class="dialog-close" data-close-dialog aria-label="Close member card">×</button></div>
    <div id="id-print-area" class="id-print-area">
      <figure class="member-id-card"><canvas id="member-id-front" class="member-id-artwork" aria-label="Front of membership card"></canvas><figcaption class="id-card-caption no-print">Front</figcaption></figure>
      <figure class="member-id-card"><canvas id="member-id-back" class="member-id-artwork" aria-label="Back of membership card"></canvas><figcaption class="id-card-caption no-print">Back</figcaption></figure>
    </div><div class="id-print-actions no-print"><button class="button button-outline" type="button" data-close-dialog>Close</button><button class="button" type="button" id="print-member-card" disabled>Save / print as PDF</button></div>`);
  document.body.append(idDialog);
  idDialog.showModal();
  try {
    const [front, back] = await renderMemberCardCanvases(member);
    if (!idDialog.isConnected) return;
    front.id = 'member-id-front';
    front.className = 'member-id-artwork';
    front.setAttribute('aria-label', 'Front of membership card');
    back.id = 'member-id-back';
    back.className = 'member-id-artwork';
    back.setAttribute('aria-label', 'Back of membership card');
    document.getElementById('member-id-front').replaceWith(front);
    document.getElementById('member-id-back').replaceWith(back);
    document.getElementById('print-member-card').disabled = false;
  } catch (error) {
    idDialog.close();
    idDialog.remove();
    idDialog = null;
    showToast(error.message, true);
  }
}

document.addEventListener('click', async (event) => {
  if (!event.target.closest('.pin-lookup-field')) closePinSuggestions(document.getElementById('membership-form'));
  if (!event.target.closest('.tamil-input-field')) {
    document.querySelectorAll('.tamil-input-field [data-tamil-input]').forEach(closeTamilSuggestions);
  }
  const target = event.target.closest('[data-page], [data-service], [data-category], [data-request-service], [data-close-dialog], [data-dashboard-tab], [data-update-payment], [data-print-card], [data-new-member-card], [data-new-member-reset], [data-membership-language], [data-pin-value], [data-tamil-suggestion], [data-edit-member], [data-archive-member], [data-restore-member], [data-add-member], #admin-refresh, #admin-export-members, #copy-upi-id, #menu-toggle, #admin-logout, #admin-retry, #print-member-card, #member-card-resend, #member-card-download');
  if (!target) return;
  if (target.matches('[data-tamil-suggestion]')) {
    const input = document.getElementById(target.dataset.tamilInput);
    if (input) applyTamilSuggestion(input, target.dataset.tamilSuggestion);
    return;
  }
  if (target.matches('[data-pin-value]')) {
    const input = target.closest('form').querySelector('#member-pin');
    input.value = target.dataset.pinValue;
    input.setCustomValidity('');
    closePinSuggestions(input.form);
    return;
  }
  if (target.matches('[data-page]')) {
    event.preventDefault();
    goTo(target.dataset.page);
    return;
  }
  if (target.id === 'menu-toggle') {
    const isOpen = nav.classList.toggle('is-open');
    target.setAttribute('aria-expanded', String(isOpen));
    return;
  }
  if (target.matches('[data-service]')) {
    openService(Number(target.dataset.service));
    return;
  }
  if (target.matches('[data-category]')) {
    activeCategory = target.dataset.category;
    main.innerHTML = serviceDirectoryPage({ category: activeCategory, query: serviceSearch });
    return;
  }
  if (target.matches('[data-request-service]')) {
    const service = services[Number(target.dataset.requestService)];
    if (serviceDialog?.open) serviceDialog.close();
    goTo('help');
    const category = document.getElementById('help-category');
    if (category) category.value = service.title;
    return;
  }
  if (target.matches('[data-close-dialog]')) {
    target.closest('dialog')?.close();
    return;
  }
  if (target.matches('[data-membership-language]')) {
    membershipLanguage = target.dataset.membershipLanguage;
    document.documentElement.lang = membershipLanguage;
    const page = document.querySelector('.membership-page');
    if (page) {
      page.dataset.language = membershipLanguage;
      page.querySelectorAll('[data-membership-language]').forEach((button) => {
        button.setAttribute('aria-pressed', String(button.dataset.membershipLanguage === membershipLanguage));
      });
      page.querySelectorAll('option[data-en][data-ta]').forEach((item) => {
        item.textContent = item.dataset[membershipLanguage];
      });
      const talukOther = page.querySelector('#member-taluk-other');
      if (talukOther) talukOther.placeholder = membershipLanguage === 'ta'
        ? 'ஆவணங்களில் உள்ளபடி வட்டத்தின் பெயரை உள்ளிடவும்'
        : 'Enter taluk name as on your records';
      const pinStatus = page.querySelector('#member-pin-status');
      if (pinStatus) {
        pinStatus.textContent = postalDirectory
          ? (membershipLanguage === 'ta'
            ? 'குறியீடு அல்லது அஞ்சல் அலுவலகப் பெயரால் தேடவும். பட்டியலில் இல்லாத செல்லுபடியான 6 இலக்க PIN-ஐ நேரடியாக உள்ளிடலாம்.'
            : 'Search by PIN or post-office name. You can manually enter a valid 6-digit PIN if it is not listed.')
          : (membershipLanguage === 'ta'
            ? 'அஞ்சல் பட்டியல் இன்னும் ஏற்றப்படவில்லை. உங்கள் பதிவில் உள்ள 6 இலக்க PIN-ஐ நேரடியாக உள்ளிடலாம்.'
            : 'The postal lookup is not loaded yet. Enter the 6-digit PIN from your records.');
      }
    }
    return;
  }
  if (target.id === 'copy-upi-id') {
    try {
      await navigator.clipboard.writeText('mastersuresh345@okaxis');
      showToast('UPI ID copied.');
    } catch {
      showToast('Copy is unavailable. UPI ID: mastersuresh345@okaxis', true);
    }
    return;
  }
  if (target.matches('[data-new-member-card]')) {
    openMemberCard(lastRegisteredMember);
    return;
  }
  if (target.matches('[data-new-member-reset]')) {
    const formCard = document.querySelector('.membership-form-card');
    const resultCard = document.getElementById('membership-result-card');
    if (formCard) formCard.hidden = false;
    if (resultCard) resultCard.hidden = true;
    lastRegisteredMember = null;
    return;
  }
  if (target.matches('[data-dashboard-tab]')) {
    adminTab = target.dataset.dashboardTab;
    drawDashboard();
    return;
  }
  if (target.matches('[data-add-member]')) {
    openAdminMemberDialog();
    return;
  }
  if (target.matches('[data-edit-member]')) {
    const member = dashboardData?.members.find((item) => item.id === target.dataset.editMember);
    if (!member) {
      showToast('Member record could not be found. Refresh the dashboard and try again.', true);
      return;
    }
    openAdminMemberDialog(member);
    return;
  }
  if (target.matches('[data-archive-member]')) {
    target.disabled = true;
    try {
      await archiveMember(target.dataset.archiveMember);
    } catch (error) {
      showToast(error.message, true);
      await loadDashboard();
    }
    return;
  }
  if (target.matches('[data-restore-member]')) {
    target.disabled = true;
    try {
      await restoreMember(target.dataset.restoreMember);
    } catch (error) {
      showToast(error.message, true);
      await loadDashboard();
    }
    return;
  }
  if (target.id === 'admin-refresh') {
    target.disabled = true;
    await loadDashboard();
    return;
  }
  if (target.id === 'admin-export-members') {
    if (!dashboardData) return;
    const search = adminMemberSearch.trim().toLowerCase();
    const filtered = dashboardData.members.filter((member) => {
      const archived = Boolean(member.archivedAt);
      if (adminMemberStatusFilter === 'active' && archived) return false;
      if (adminMemberStatusFilter === 'archived' && !archived) return false;
      if (adminPaymentFilter !== 'all' && member.paymentStatus !== adminPaymentFilter) return false;
      const text = [member.fullName, member.membershipId, member.id, member.mobile, member.email,
        member.district, member.localBodyName, member.taluk, member.pinCode,
        member.assemblyConstituency, member.parliamentaryConstituency].join(' ').toLowerCase();
      return text.includes(search);
    });
    exportMembersCsv(filtered);
    return;
  }
  if (target.matches('[data-update-payment]')) {
    target.disabled = true;
    try {
      const select = document.querySelector(`[data-payment-status="${CSS.escape(target.dataset.updatePayment)}"]`);
      if (!select) throw new Error('Payment status selector not found.');
      await updateMemberPayment(target.dataset.updatePayment, select.value);
    } catch (error) {
      showToast(error.message, true);
      await loadDashboard();
    }
    return;
  }
  if (target.matches('[data-update-request]')) {
    target.disabled = true;
    try {
      await updateRequest(target.dataset.updateRequest);
    } catch (error) {
      showToast(error.message, true);
      await loadDashboard();
    }
    return;
  }
  if (target.matches('[data-print-card]')) {
    await openMemberCard(target.dataset.printCard);
    return;
  }
  if (target.id === 'admin-logout') {
    try {
      await api('/api/admin/logout', { method: 'POST', body: '{}' });
    } catch (error) {
      showToast(error.message, true);
    } finally {
      adminToken = '';
      localStorage.removeItem('pms_admin_token');
      dashboardData = null;
      renderPage();
    }
    return;
  }
  if (target.id === 'admin-retry') {
    renderPage();
    return;
  }
  if (target.id === 'print-member-card') {
    if (!idCardMember) {
      showToast('The member card is not ready. Close it and generate the card again.', true);
      return;
    }
    target.disabled = true;
    const originalLabel = target.textContent;
    target.textContent = 'Preparing PDF…';
    try {
      const pdf = await buildMemberCardPdf(idCardMember);
      const url = URL.createObjectURL(pdf);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${idCardMember.membershipId.toLowerCase()}-membership-card.pdf`;
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      showToast('Membership card PDF downloaded. Open it to print.');
    } catch (error) {
      showToast(error.message || 'The membership card PDF could not be created.', true);
    } finally {
      target.disabled = false;
      target.textContent = originalLabel;
    }
    return;
  }
  if (target.id === 'member-card-resend') {
    target.disabled = true;
    try {
      await requestMemberCardCode(document.getElementById('member-card-request-form'), { resend: true });
    } finally {
      target.disabled = false;
    }
    return;
  }
  if (target.id === 'member-card-download') {
    await downloadMemberCard();
  }
});

document.addEventListener('keydown', (event) => {
  const input = event.target;
  if (input.matches('[data-tamil-input]')) {
    const list = input.closest('.tamil-input-field')?.querySelector('.tamil-suggestions');
    const options = [...(list?.querySelectorAll('[data-tamil-suggestion]') || [])];
    if (event.key === 'Escape') {
      closeTamilSuggestions(input);
      return;
    }
    if (!options.length) return;
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
      event.preventDefault();
      const activeIndex = Number(list.dataset.activeIndex);
      const direction = event.key === 'ArrowDown' ? 1 : -1;
      const nextIndex = activeIndex < 0
        ? (direction > 0 ? 0 : options.length - 1)
        : (activeIndex + direction + options.length) % options.length;
      list.dataset.activeIndex = String(nextIndex);
      options.forEach((option, index) => {
        const active = index === nextIndex;
        option.setAttribute('aria-selected', String(active));
        option.classList.toggle('is-active', active);
      });
      input.setAttribute('aria-activedescendant', options[nextIndex].id);
    } else if (event.key === 'Enter' && !(input instanceof HTMLTextAreaElement)) {
      const selectedIndex = Number(list.dataset.activeIndex);
      const activeIndex = selectedIndex >= 0 ? selectedIndex : 0;
      event.preventDefault();
      applyTamilSuggestion(input, options[activeIndex].dataset.tamilSuggestion);
    }
    return;
  }
  if (input.id !== 'member-pin') return;
  const options = [...input.form.querySelectorAll('.lookup-option')];
  if (event.key === 'Escape') {
    closePinSuggestions(input.form);
    return;
  }
  if (!options.length) return;
  if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
    event.preventDefault();
    const direction = event.key === 'ArrowDown' ? 1 : -1;
    pinSuggestionIndex = (pinSuggestionIndex + direction + options.length) % options.length;
    options.forEach((option, index) => {
      const active = index === pinSuggestionIndex;
      option.setAttribute('aria-selected', String(active));
      option.classList.toggle('is-active', active);
    });
    input.setAttribute('aria-activedescendant', options[pinSuggestionIndex].id);
  } else if (event.key === 'Enter' && pinSuggestionIndex >= 0) {
    event.preventDefault();
    options[pinSuggestionIndex].click();
  }
});

document.addEventListener('input', (event) => {
  if (event.target.matches('[data-tamil-input]')) {
    if (event.target.name === 'addressTamil' && event.target.dataset.generatedTamil !== event.target.value) {
      delete event.target.dataset.generatedTamil;
    }
    renderTamilSuggestions(event.target);
    return;
  }
  if (isEnglishAddressField(event.target)) updateTamilAddressSuggestion(event.target.form);
  if (event.target.id === 'member-pin') {
    renderPinSuggestions(event.target);
    return;
  }
  if (event.target.id === 'admin-member-search') {
    adminMemberSearch = event.target.value;
    updateAdminMemberSearch();
    return;
  }
  if (event.target.id !== 'service-search') return;
  serviceSearch = event.target.value;
  const filtered = services.map((service, index) => ({ service, index })).filter(({ service }) => {
    return (activeCategory === 'all' || activeCategory === service.category)
      && `${service.title} ${service.summary} ${service.group}`.toLowerCase().includes(serviceSearch.toLowerCase().trim());
  });
  const results = document.getElementById('service-results');
  if (results) results.innerHTML = servicesGrid(filtered);
});

document.addEventListener('submit', async (event) => {
  const form = event.target;
  if (form.id === 'admin-member-form') {
    event.preventDefault();
    await saveAdminMember(form);
  } else if (form.id === 'membership-form') {
    event.preventDefault();
    if (!form.reportValidity()) return;
    await submitMembership(form);
  } else if (form.id === 'help-form') {
    event.preventDefault();
    if (!form.reportValidity()) return;
    await submitHelp(form);
  } else if (form.id === 'member-card-request-form') {
    event.preventDefault();
    await requestMemberCardCode(form);
  } else if (form.id === 'member-card-otp-form') {
    event.preventDefault();
    await verifyMemberCardCode(form);
  } else if (form.matches('[data-track-form]')) {
    event.preventDefault();
    if (form.reportValidity()) await submitTrack(form);
  } else if (form.id === 'admin-login') {
    event.preventDefault();
    if (form.reportValidity()) await handleAdminLogin(form);
  }
});

document.addEventListener('change', (event) => {
  if (isEnglishAddressField(event.target)) updateTamilAddressSuggestion(event.target.form);
  if (event.target.matches('[data-request-status]')) event.target.dataset.changed = 'true';
  if (event.target.id === 'admin-member-filter') {
    adminMemberStatusFilter = event.target.value;
    drawDashboard();
  }
  if (event.target.id === 'admin-payment-filter') {
    adminPaymentFilter = event.target.value;
    drawDashboard();
  }
  if (event.target.id === 'member-district') {
    const form = event.target.form;
    updateTalukOptions(form, event.target.value);
    form.elements.localBodyType.disabled = !event.target.value;
    form.elements.localBodyType.value = '';
    updateLocalBodyFields(form);
  }
  if (event.target.id === 'member-taluk-select') {
    const other = event.target.form.querySelector('#member-taluk-other');
    const useOther = event.target.value === '__other__';
    other.hidden = !useOther;
    other.disabled = !useOther;
    other.required = useOther;
    if (!useOther) other.value = '';
  }
  if (event.target.id === 'member-local-body-type') updateLocalBodyFields(event.target.form);
  if (event.target.id === 'member-assembly') updateParliamentOptions(event.target.form, event.target.value);
  if (event.target.id === 'member-photo') {
    const preview = document.getElementById('member-photo-preview');
    const file = event.target.files[0];
    if (!preview) return;
    if (!file) {
      preview.removeAttribute('src');
      preview.hidden = true;
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      event.target.setCustomValidity('Choose a photo smaller than 12 MB.');
      showFormMessage('membership-message', 'Choose a photo smaller than 12 MB.');
      preview.removeAttribute('src');
      preview.hidden = true;
      return;
    }
    event.target.setCustomValidity('');
    const reader = new FileReader();
    reader.onload = () => {
      if (event.target.files[0] !== file) return;
      preview.src = String(reader.result);
      preview.hidden = false;
    };
    reader.onerror = () => {
      event.target.setCustomValidity('The selected photo could not be read.');
      showFormMessage('membership-message', 'The selected photo could not be read.');
    };
    reader.readAsDataURL(file);
  }
  if (event.target.id === 'admin-member-photo') {
    const input = event.target;
    const preview = document.getElementById('admin-photo-preview');
    const status = document.getElementById('admin-photo-status');
    const file = input.files[0];
    input.setCustomValidity('');
    if (!file) {
      if (status) status.textContent = 'No new photo selected. The saved photo will be kept.';
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      input.setCustomValidity('Choose a photo smaller than 12 MB.');
      if (status) status.textContent = 'This photo is larger than 12 MB. Choose a smaller file.';
      preview?.removeAttribute('src');
      if (preview) preview.hidden = true;
      return;
    }
    if (status) status.textContent = `${file.name} selected. It will be compressed and saved when you click Save member changes.`;
    const reader = new FileReader();
    reader.onload = () => {
      if (input.files[0] !== file || !preview) return;
      preview.src = String(reader.result);
      preview.hidden = false;
    };
    reader.onerror = () => {
      input.setCustomValidity('The selected member photo could not be read.');
      if (status) status.textContent = 'The selected photo could not be read. Choose it again.';
    };
    reader.readAsDataURL(file);
  }
});

window.addEventListener('hashchange', () => {
  const page = location.hash.slice(1);
  if (pageNames[page]) {
    closeActiveDialogs();
    currentPage = page;
    renderPage();
  }
});

window.addEventListener('afterprint', () => document.body.classList.remove('printing-id'));

document.getElementById('current-year').textContent = String(new Date().getFullYear());
renderPage();
