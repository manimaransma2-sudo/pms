import { createServer } from 'node:http';
import { createReadStream, promises as fs } from 'node:fs';
import path from 'node:path';
import { createCipheriv, createDecipheriv, createHash, createHmac, randomBytes, randomInt, timingSafeEqual } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { createTransport } from 'nodemailer';
import mysql from 'mysql2/promise';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(ROOT, 'public');
const DEFAULT_DATA_FILE = path.join(ROOT, 'data', 'records.json');
const BODY_LIMIT = 16 * 1024;
const MEMBERSHIP_BODY_LIMIT = 400 * 1024;
const PROFILE_PHOTO_LIMIT = 250 * 1024;
const MEMBERSHIP_FEE_RUPEES = 500;
const SESSION_DURATION_MS = 8 * 60 * 60 * 1000;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const MAX_LOGIN_ATTEMPTS = 5;
const CARD_OTP_WINDOW_MS = 15 * 60 * 1000;
const CARD_OTP_LIFETIME_MS = 10 * 60 * 1000;
const CARD_OTP_COOLDOWN_MS = 60 * 1000;
const CARD_OTP_MAX_ATTEMPTS = 5;
const CARD_OTP_MAX_REQUESTS = 5;
const ALLOWED_PAYMENT_STATUSES = new Set(['Pending verification', 'Verified', 'Needs review']);
const ALLOWED_REQUEST_STATUSES = new Set(['Received', 'In progress', 'Referred', 'Resolved', 'Closed']);
const ALLOWED_GENDERS = new Set(['Male', 'Female', 'Other']);
const ALLOWED_BLOOD_GROUPS = new Set(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-', 'Unknown']);
const ALLOWED_MEMBER_STATUSES = new Set(['Active member', 'Inactive']);
const LOCAL_BODY_FIELDS = new Map([
  ['corporation', 'corporation'],
  ['municipality', 'municipality'],
  ['townPanchayat', 'townPanchayat'],
  ['villagePanchayat', 'panchayat'],
]);

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function jsonResponse(response, status, payload) {
  response.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  });
  response.end(JSON.stringify(payload));
}

function equalSecret(provided, expected) {
  const left = Buffer.from(String(provided));
  const right = Buffer.from(String(expected));
  return left.length === right.length && timingSafeEqual(left, right);
}

function cleanText(value, field, maxLength, { required = false } = {}) {
  if (typeof value !== 'string') {
    if (required) throw new HttpError(400, `${field} is required.`);
    return '';
  }
  const cleaned = value.trim();
  if (required && !cleaned) throw new HttpError(400, `${field} is required.`);
  if (cleaned.length > maxLength) throw new HttpError(400, `${field} is too long.`);
  return cleaned;
}

function validateConsent(value) {
  if (value !== true) throw new HttpError(400, 'Please confirm that you agree to be contacted.');
}

function encryptField(value, key) {
  if (!value) return '';
  const nonce = randomBytes(12);
  const cipher = createCipheriv('aes-256-gcm', key, nonce);
  const ciphertext = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()]);
  return `${nonce.toString('hex')}:${cipher.getAuthTag().toString('hex')}:${ciphertext.toString('base64')}`;
}

function decryptField(value, key) {
  if (!value) return '';
  const [nonceHex, authTagHex, ciphertext] = value.split(':');
  if (!nonceHex || !authTagHex || !ciphertext) throw new Error('A protected member field could not be read.');
  const decipher = createDecipheriv('aes-256-gcm', key, Buffer.from(nonceHex, 'hex'));
  decipher.setAuthTag(Buffer.from(authTagHex, 'hex'));
  return Buffer.concat([
    decipher.update(Buffer.from(ciphertext, 'base64')),
    decipher.final(),
  ]).toString('utf8');
}

function getProfilePhotoData(value) {
  if (typeof value !== 'string' || !value) {
    throw new HttpError(400, 'Please add a member photo to the registration form.');
  }
  const match = value.match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/]+={0,2})$/);
  if (!match) throw new HttpError(400, 'Upload a JPEG, PNG or WebP member photo.');
  const bytes = Buffer.from(match[2], 'base64');
  if (!bytes.length || bytes.length > PROFILE_PHOTO_LIMIT) {
    throw new HttpError(400, 'The member photo must be smaller than 250 KB.');
  }
  const validSignature = match[1] === 'jpeg'
    ? bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff
    : match[1] === 'png'
      ? bytes.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))
      : bytes.length >= 12 && bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP';
  if (!validSignature || bytes.toString('base64') !== match[2]) {
    throw new HttpError(400, 'The uploaded file is not a valid JPEG, PNG or WebP image.');
  }
  return `data:image/${match[1]};base64,${bytes.toString('base64')}`;
}

function validateAdminMember(body, constituencyData, encryptionKey, existingMember = null) {
  const fullName = cleanText(body.fullName, 'Full name', 100, { required: true });
  const fullNameTamil = cleanText(body.fullNameTamil, 'Name in Tamil', 100, { required: !existingMember });
  const mobile = cleanText(body.mobile, 'Mobile number', 18, { required: true }).replaceAll(' ', '');
  if (!/^(\+91[-]?)?[6-9]\d{9}$/.test(mobile)) throw new HttpError(400, 'Enter a valid 10-digit Indian mobile number.');
  const email = cleanText(body.email, 'Email address', 254).toLowerCase();
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new HttpError(400, 'Enter a valid email address.');
  const gender = cleanText(body.gender, 'Gender', 12, { required: true });
  if (!ALLOWED_GENDERS.has(gender)) throw new HttpError(400, 'Choose a valid gender option.');
  const guardianRelation = cleanText(body.guardianRelation, 'Relationship', 8, { required: true });
  if (!['S/o', 'D/o', 'W/o'].includes(guardianRelation)) throw new HttpError(400, 'Choose a valid relationship option.');
  const guardianName = cleanText(body.guardianName, 'Parent / spouse name', 100, { required: true });
  const guardianNameTamil = cleanText(body.guardianNameTamil, 'Parent / spouse name in Tamil', 100, { required: !existingMember });
  const dateOfBirth = cleanText(body.dateOfBirth, 'Date of birth', 10, { required: true });
  const parsedDateOfBirth = new Date(`${dateOfBirth}T00:00:00Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateOfBirth)
    || Number.isNaN(parsedDateOfBirth.getTime())
    || parsedDateOfBirth.toISOString().slice(0, 10) !== dateOfBirth
    || dateOfBirth > new Date().toISOString().slice(0, 10)) {
    throw new HttpError(400, 'Enter a valid date of birth that is not in the future.');
  }
  const occupation = cleanText(body.occupation, 'Occupation', 100, { required: true });
  const country = cleanText(body.country, 'Country', 80, { required: true });
  const stateName = cleanText(body.state, 'State', 80, { required: true });
  const district = cleanText(body.district, 'District', 80, { required: true });
  const taluk = cleanText(body.taluk, 'Taluk', 80, { required: true });
  const localBodyType = cleanText(body.localBodyType, 'Local government type', 30, { required: true });
  const localBodyField = LOCAL_BODY_FIELDS.get(localBodyType);
  if (!localBodyField) throw new HttpError(400, 'Choose a valid local government type.');
  const localBodyNames = {
    corporation: cleanText(body.corporation, 'Corporation', 100),
    municipality: cleanText(body.municipality, 'Municipality', 100),
    townPanchayat: cleanText(body.townPanchayat, 'Town panchayat', 100),
    panchayat: cleanText(body.panchayat, 'Village panchayat', 100),
  };
  const localBodyName = localBodyNames[localBodyField];
  if (!localBodyName) throw new HttpError(400, `Enter the ${localBodyField === 'panchayat' ? 'village panchayat' : localBodyField} name.`);
  if (Object.entries(localBodyNames).some(([field, value]) => field !== localBodyField && value)) {
    throw new HttpError(400, 'Enter only the local-body name that matches the selected local government type.');
  }
  const assemblyConstituency = cleanText(body.assemblyConstituency, 'Assembly constituency', 100, { required: true });
  const parliamentaryConstituency = cleanText(body.parliamentaryConstituency, 'Parliamentary constituency', 100, { required: true });
  const expectedParliament = constituencyData.parliamentByAssembly[assemblyConstituency];
  if (!expectedParliament) throw new HttpError(400, 'Choose a valid Tamil Nadu Assembly constituency.');
  if (parliamentaryConstituency !== expectedParliament) {
    throw new HttpError(400, 'Choose the Parliament constituency that matches the selected Assembly constituency.');
  }
  const street = cleanText(body.street, 'Street', 160, { required: true });
  const villageArea = cleanText(body.villageArea, 'Village / area', 120, { required: true });
  const addressTamil = cleanText(body.addressTamil, 'Full address in Tamil', 500, { required: !existingMember });
  const wardNumber = cleanText(body.wardNumber, 'Ward number', 30);
  const pinCode = cleanText(body.pinCode, 'PIN code', 6, { required: true });
  if (!/^\d{6}$/.test(pinCode)) throw new HttpError(400, 'Enter a valid 6-digit PIN code.');
  const bloodGroup = cleanText(body.bloodGroup, 'Blood group', 10, { required: true });
  if (!ALLOWED_BLOOD_GROUPS.has(bloodGroup)) throw new HttpError(400, 'Choose a valid blood group.');
  const whatsapp = cleanText(body.whatsapp, 'WhatsApp number', 18).replaceAll(' ', '');
  if (whatsapp && !/^(\+91[-]?)?[6-9]\d{9}$/.test(whatsapp)) throw new HttpError(400, 'Enter a valid 10-digit WhatsApp number.');
  const upiTransactionId = cleanText(body.upiTransactionId, 'UPI transaction ID / UTR', 30).replaceAll(' ', '');
  if (upiTransactionId && !/^[A-Za-z0-9-]{6,30}$/.test(upiTransactionId)) {
    throw new HttpError(400, 'Enter a valid UPI transaction ID or UTR (6–30 letters or digits).');
  }
  const paymentStatus = body.paymentStatus || existingMember?.paymentStatus || 'Pending verification';
  if (!ALLOWED_PAYMENT_STATUSES.has(paymentStatus)) throw new HttpError(400, 'Choose a valid payment verification status.');
  const status = body.status || existingMember?.status || 'Active member';
  if (!ALLOWED_MEMBER_STATUSES.has(status)) throw new HttpError(400, 'Choose a valid membership status.');
  let aadhaarEncrypted = existingMember?.aadhaarEncrypted || '';
  if (typeof body.aadhaarNumber === 'string' && body.aadhaarNumber.trim()) {
    const aadhaarNumber = cleanText(body.aadhaarNumber, 'Aadhaar number', 14).replaceAll(/\s/g, '');
    if (!/^\d{12}$/.test(aadhaarNumber)) throw new HttpError(400, 'Aadhaar number must contain exactly 12 digits.');
    aadhaarEncrypted = encryptField(aadhaarNumber, encryptionKey);
  }
  let photoEncrypted = existingMember?.photoEncrypted || '';
  if (typeof body.photoData === 'string' && body.photoData) {
    photoEncrypted = encryptField(getProfilePhotoData(body.photoData), encryptionKey);
  }
  return {
    fullName, fullNameTamil, mobile, email, gender, guardianRelation, guardianName, guardianNameTamil, dateOfBirth, occupation,
    country, state: stateName, district, taluk, localBodyType, localBodyName,
    assemblyConstituency, parliamentaryConstituency, ...localBodyNames,
    street, villageArea, addressTamil, wardNumber, pinCode, bloodGroup, whatsapp, upiTransactionId,
    paymentStatus, status, aadhaarEncrypted, photoEncrypted,
  };
}

function createReference(prefix) {
  const day = new Date().toISOString().slice(0, 10).replaceAll('-', '');
  return `${prefix}-${day}-${randomBytes(8).toString('hex').toUpperCase()}`;
}

function makeInitialState() {
  return { members: [], requests: [], lastMemberSequence: 0 };
}

async function readState(dataFile) {
  await fs.mkdir(path.dirname(dataFile), { recursive: true });
  try {
    const content = await fs.readFile(dataFile, 'utf8');
    return parseState(content, 'The data file');
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    const initial = makeInitialState();
    await fs.writeFile(dataFile, JSON.stringify(initial, null, 2), { flag: 'wx', mode: 0o600 });
    return initial;
  }
}

function parseState(content, source) {
  const state = typeof content === 'string' ? JSON.parse(content) : content;
  if (!state || !Array.isArray(state.members) || !Array.isArray(state.requests)) {
    throw new Error(`${source} does not contain valid member and request lists.`);
  }
  return {
    members: state.members,
    requests: state.requests,
    lastMemberSequence: Number.isSafeInteger(state.lastMemberSequence) && state.lastMemberSequence >= 0
      ? state.lastMemberSequence
      : 0,
  };
}

async function readDatabaseState(pool) {
  await pool.query(`CREATE TABLE IF NOT EXISTS pms_portal_state (
    id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
    state_json LONGTEXT NOT NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`);
  const initial = JSON.stringify(makeInitialState());
  await pool.execute('INSERT IGNORE INTO pms_portal_state (id, state_json) VALUES (1, ?)', [initial]);
  return loadDatabaseState(pool);
}

async function loadDatabaseState(pool, connection = pool, lockRow = false) {
  const [rows] = await connection.execute(
    `SELECT state_json FROM pms_portal_state WHERE id = 1${lockRow ? ' FOR UPDATE' : ''}`,
  );
  if (!rows.length) throw new Error('The portal database state row could not be initialized.');
  return parseState(rows[0].state_json, 'The database');
}

async function readJsonBody(request, maxBytes = BODY_LIMIT) {
  let body = '';
  for await (const chunk of request) {
    body += chunk;
    if (Buffer.byteLength(body) > maxBytes) throw new HttpError(413, 'Request body is too large.');
  }
  if (!body) return {};
  try {
    const parsed = JSON.parse(body);
    if (!parsed || Array.isArray(parsed) || typeof parsed !== 'object') {
      throw new Error('Expected a JSON object.');
    }
    return parsed;
  } catch {
    throw new HttpError(400, 'Request body must be a valid JSON object.');
  }
}

function getClientAddress(request) {
  return request.socket.remoteAddress || 'unknown';
}

function sessionToken(request) {
  const authorization = request.headers.authorization || '';
  return authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
}

function setSecurityHeaders(response) {
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('X-Frame-Options', 'DENY');
  response.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  response.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'",
  );
}

function getContentType(filePath) {
  const extension = path.extname(filePath).toLowerCase();
  return ({
    '.css': 'text/css; charset=utf-8',
    '.html': 'text/html; charset=utf-8',
    '.ico': 'image/x-icon',
    '.jpeg': 'image/jpeg',
    '.jpg': 'image/jpeg',
    '.js': 'text/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.svg': 'image/svg+xml',
  })[extension] || 'application/octet-stream';
}

async function serveStatic(response, pathname) {
  let decodedPath;
  try {
    decodedPath = decodeURIComponent(pathname);
  } catch {
    throw new HttpError(400, 'The requested path is invalid.');
  }
  const requestedPath = decodedPath === '/' ? '/index.html' : decodedPath;
  const filePath = path.resolve(PUBLIC_DIR, `.${requestedPath}`);
  if (!filePath.startsWith(`${PUBLIC_DIR}${path.sep}`)) {
    throw new HttpError(404, 'Not found.');
  }
  let stat;
  try {
    stat = await fs.stat(filePath);
  } catch (error) {
    if (error.code === 'ENOENT' || error.code === 'ENOTDIR') throw new HttpError(404, 'Not found.');
    throw error;
  }
  if (!stat.isFile()) throw new HttpError(404, 'Not found.');
  response.writeHead(200, {
    'Content-Type': getContentType(filePath),
    'Content-Length': stat.size,
    'Cache-Control': /\.(?:html|css|js)$/i.test(filePath) ? 'no-cache' : 'public, max-age=3600',
  });
  createReadStream(filePath).pipe(response);
}

export async function createAppServer({
  dataFile = process.env.DATA_FILE || DEFAULT_DATA_FILE,
  username = process.env.ADMIN_USERNAME || 'admin',
  password = process.env.ADMIN_PASSWORD || 'pms-local-demo',
  production = process.env.NODE_ENV === 'production',
  sendMail = null,
} = {}) {
  if (production && (!process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD.length < 12)) {
    throw new Error('Set ADMIN_PASSWORD to at least 12 characters before starting in production.');
  }
  const resolvedDataFile = path.resolve(dataFile);
  const databaseEnvironment = {
    host: process.env.DB_HOST || '',
    user: process.env.DB_USER || '',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || '',
  };
  const databaseConfigured = Object.values(databaseEnvironment).some(Boolean);
  if (databaseConfigured && Object.values(databaseEnvironment).some((value) => !value)) {
    throw new Error('Set DB_HOST, DB_USER, DB_PASSWORD and DB_NAME together, or leave all four unset.');
  }
  const databasePool = databaseConfigured ? mysql.createPool({
    ...databaseEnvironment,
    port: Number(process.env.DB_PORT || 3306),
    connectionLimit: 5,
    charset: 'utf8mb4',
    ...(process.env.DB_SSL === 'true' ? { ssl: { rejectUnauthorized: true } } : {}),
  }) : null;
  if (databasePool && (!Number.isInteger(Number(process.env.DB_PORT || 3306))
    || Number(process.env.DB_PORT || 3306) < 1
    || Number(process.env.DB_PORT || 3306) > 65535)) {
    await databasePool.end();
    throw new Error('DB_PORT must be a valid TCP port.');
  }
  let encryptionKey;
  if (process.env.DATA_ENCRYPTION_KEY && !/^[\da-f]{64}$/i.test(process.env.DATA_ENCRYPTION_KEY)) {
    throw new Error('DATA_ENCRYPTION_KEY must contain exactly 64 hexadecimal characters.');
  }
  if (process.env.DATA_ENCRYPTION_KEY) {
    encryptionKey = Buffer.from(process.env.DATA_ENCRYPTION_KEY, 'hex');
  } else if (production) {
    throw new Error('Set DATA_ENCRYPTION_KEY to 64 hexadecimal characters before starting in production.');
  } else {
    const keyFile = path.join(path.dirname(resolvedDataFile), '.encryption-key');
    await fs.mkdir(path.dirname(keyFile), { recursive: true });
    try {
      encryptionKey = Buffer.from((await fs.readFile(keyFile, 'utf8')).trim(), 'hex');
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      encryptionKey = randomBytes(32);
      try {
        await fs.writeFile(keyFile, `${encryptionKey.toString('hex')}\n`, { flag: 'wx', mode: 0o600 });
      } catch (writeError) {
        if (writeError.code !== 'EEXIST') throw writeError;
        encryptionKey = Buffer.from((await fs.readFile(keyFile, 'utf8')).trim(), 'hex');
      }
    }
    if (encryptionKey.length !== 32) throw new Error(`The local encryption key at ${keyFile} must contain 64 hexadecimal characters.`);
  }
  const state = databasePool ? await readDatabaseState(databasePool) : await readState(resolvedDataFile);
  const constituencyData = JSON.parse(await fs.readFile(path.join(PUBLIC_DIR, 'constituency-data.json'), 'utf8'));
  if (!Array.isArray(constituencyData.assemblyConstituencies)
    || constituencyData.assemblyConstituencies.length !== 234
    || !Array.isArray(constituencyData.parliamentaryConstituencies)
    || constituencyData.parliamentaryConstituencies.length !== 39
    || !constituencyData.parliamentByAssembly
    || Object.keys(constituencyData.parliamentByAssembly).length !== 234) {
    throw new Error('The Tamil Nadu constituency lookup data is incomplete.');
  }
  const sessions = new Map();
  const loginAttempts = new Map();
  const cardOtpChallenges = new Map();
  const cardOtpRequests = new Map();
  const smtpConfigured = Boolean(
    process.env.SMTP_HOST
    && process.env.SMTP_PORT
    && process.env.SMTP_USER
    && process.env.SMTP_PASSWORD
    && process.env.SMTP_FROM,
  );
  const smtpPort = Number(process.env.SMTP_PORT || 587);
  if (smtpConfigured && (!Number.isInteger(smtpPort) || smtpPort < 1 || smtpPort > 65535)) {
    throw new Error('SMTP_PORT must be a valid TCP port.');
  }
  const smtpTransport = !sendMail && smtpConfigured
    ? createTransport({
      host: process.env.SMTP_HOST,
      port: smtpPort,
      secure: process.env.SMTP_SECURE === 'true',
      requireTLS: process.env.SMTP_SECURE !== 'true',
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD },
    })
    : null;
  const deliverMail = sendMail || (smtpTransport ? (message) => smtpTransport.sendMail(message) : null);
  let writeQueue = Promise.resolve();

  async function updateState(mutator) {
    const operation = writeQueue.then(async () => {
      if (databasePool) {
        const connection = await databasePool.getConnection();
        try {
          await connection.beginTransaction();
          const nextState = await loadDatabaseState(databasePool, connection, true);
          const result = mutator(nextState);
          await connection.execute('UPDATE pms_portal_state SET state_json = ? WHERE id = 1', [JSON.stringify(nextState)]);
          await connection.commit();
          Object.assign(state, nextState);
          return result;
        } catch (error) {
          await connection.rollback();
          throw error;
        } finally {
          connection.release();
        }
      }
      const nextState = structuredClone(state);
      const result = mutator(nextState);
      const temporaryFile = `${resolvedDataFile}.${process.pid}.tmp`;
      await fs.writeFile(temporaryFile, JSON.stringify(nextState, null, 2), { mode: 0o600 });
      await fs.rename(temporaryFile, resolvedDataFile);
      Object.assign(state, nextState);
      return result;
    });
    writeQueue = operation.catch(() => {});
    return operation;
  }

  function requireAdmin(request) {
    const token = sessionToken(request);
    const expiresAt = sessions.get(token);
    if (!token || !expiresAt || expiresAt <= Date.now()) {
      sessions.delete(token);
      throw new HttpError(401, 'Your admin session has expired. Please sign in again.');
    }
    sessions.set(token, Date.now() + SESSION_DURATION_MS);
  }

  const server = createServer(async (request, response) => {
    setSecurityHeaders(response);
    try {
      const url = new URL(request.url || '/', 'http://localhost');
      const pathname = url.pathname;
      const method = request.method || 'GET';
      if (databasePool && pathname.startsWith('/api/')) {
        Object.assign(state, await loadDatabaseState(databasePool));
      }

      if (method === 'GET' && pathname === '/api/health') {
        return jsonResponse(response, 200, { success: true, service: 'Parayar Mahasabai community portal' });
      }

      if (method === 'POST' && pathname === '/api/members') {
        const body = await readJsonBody(request, MEMBERSHIP_BODY_LIMIT);
        validateConsent(body.consent);
        const fullName = cleanText(body.fullName, 'Full name', 100, { required: true });
        const fullNameTamil = cleanText(body.fullNameTamil, 'Name in Tamil', 100, { required: true });
        const mobile = cleanText(body.mobile, 'Mobile number', 18, { required: true }).replaceAll(' ', '');
        const email = cleanText(body.email, 'Email address', 254).toLowerCase();
        const gender = cleanText(body.gender, 'Gender', 12, { required: true });
        if (!ALLOWED_GENDERS.has(gender)) throw new HttpError(400, 'Choose a valid gender option.');
        const guardianRelation = cleanText(body.guardianRelation, 'Relationship', 8, { required: true });
        if (!['S/o', 'D/o', 'W/o'].includes(guardianRelation)) throw new HttpError(400, 'Choose a valid relationship option.');
        const guardianName = cleanText(body.guardianName, 'Parent / spouse name', 100, { required: true });
        const guardianNameTamil = cleanText(body.guardianNameTamil, 'Parent / spouse name in Tamil', 100, { required: true });
        const dateOfBirth = cleanText(body.dateOfBirth, 'Date of birth', 10, { required: true });
        const parsedDateOfBirth = new Date(`${dateOfBirth}T00:00:00Z`);
        if (!/^\d{4}-\d{2}-\d{2}$/.test(dateOfBirth)
          || Number.isNaN(parsedDateOfBirth.getTime())
          || parsedDateOfBirth.toISOString().slice(0, 10) !== dateOfBirth
          || dateOfBirth > new Date().toISOString().slice(0, 10)) {
          throw new HttpError(400, 'Enter a valid date of birth that is not in the future.');
        }
        const occupation = cleanText(body.occupation, 'Occupation', 100, { required: true });
        const country = cleanText(body.country, 'Country', 80, { required: true });
        const stateName = cleanText(body.state, 'State', 80, { required: true });
        const district = cleanText(body.district, 'District', 80, { required: true });
        const taluk = cleanText(body.taluk, 'Taluk', 80, { required: true });
        const localBodyType = cleanText(body.localBodyType, 'Local government type', 30, { required: true });
        const localBodyField = LOCAL_BODY_FIELDS.get(localBodyType);
        if (!localBodyField) throw new HttpError(400, 'Choose a valid local government type.');
        const assemblyConstituency = cleanText(body.assemblyConstituency, 'Assembly constituency', 100, { required: true });
        const parliamentaryConstituency = cleanText(body.parliamentaryConstituency, 'Parliamentary constituency', 100, { required: true });
        const expectedParliament = constituencyData.parliamentByAssembly[assemblyConstituency];
        if (!expectedParliament) throw new HttpError(400, 'Choose a valid Tamil Nadu Assembly constituency.');
        if (parliamentaryConstituency !== expectedParliament) {
          throw new HttpError(400, 'Choose the Parliament constituency that matches the selected Assembly constituency.');
        }
        const corporation = cleanText(body.corporation, 'Corporation', 100);
        const municipality = cleanText(body.municipality, 'Municipality', 100);
        const townPanchayat = cleanText(body.townPanchayat, 'Town panchayat', 100);
        const panchayat = cleanText(body.panchayat, 'Village panchayat', 100);
        const localBodyNames = { corporation, municipality, townPanchayat, panchayat };
        const localBodyName = localBodyNames[localBodyField];
        if (!localBodyName) throw new HttpError(400, `Enter the ${localBodyField === 'panchayat' ? 'village panchayat' : localBodyField} name.`);
        if (Object.entries(localBodyNames).some(([field, value]) => field !== localBodyField && value)) {
          throw new HttpError(400, 'Enter only the local-body name that matches the selected local government type.');
        }
        const street = cleanText(body.street, 'Street', 160, { required: true });
        const villageArea = cleanText(body.villageArea, 'Village / area', 120, { required: true });
        const addressTamil = cleanText(body.addressTamil, 'Full address in Tamil', 500, { required: true });
        const wardNumber = cleanText(body.wardNumber, 'Ward number', 30);
        const pinCode = cleanText(body.pinCode, 'PIN code', 6, { required: true });
        if (!/^\d{6}$/.test(pinCode)) throw new HttpError(400, 'Enter a valid 6-digit PIN code.');
        const bloodGroup = cleanText(body.bloodGroup, 'Blood group', 10, { required: true });
        if (!ALLOWED_BLOOD_GROUPS.has(bloodGroup)) throw new HttpError(400, 'Choose a valid blood group.');
        const whatsapp = cleanText(body.whatsapp, 'WhatsApp number', 18).replaceAll(' ', '');
        if (whatsapp && !/^(\+91[-]?)?[6-9]\d{9}$/.test(whatsapp)) {
          throw new HttpError(400, 'Enter a valid 10-digit WhatsApp number.');
        }
        const aadhaarNumber = cleanText(body.aadhaarNumber, 'Aadhaar number', 14).replaceAll(/\s/g, '');
        if (aadhaarNumber && !/^\d{12}$/.test(aadhaarNumber)) {
          throw new HttpError(400, 'Aadhaar number must contain exactly 12 digits.');
        }
        const upiTransactionId = cleanText(body.upiTransactionId, 'UPI transaction ID / UTR', 30, { required: true }).replaceAll(' ', '');
        if (!/^[A-Za-z0-9-]{6,30}$/.test(upiTransactionId)) {
          throw new HttpError(400, 'Enter a valid UPI transaction ID or UTR (6–30 letters or digits).');
        }
        const signatureName = cleanText(body.signatureName, 'Digital signature', 100, { required: true });
        if (signatureName.toLocaleLowerCase() !== fullName.toLocaleLowerCase()) {
          throw new HttpError(400, 'Type your full name in the declaration signature field.');
        }
        const photoData = getProfilePhotoData(body.photoData);
        if (!/^(\+91[-]?)?[6-9]\d{9}$/.test(mobile)) {
          throw new HttpError(400, 'Enter a valid 10-digit Indian mobile number.');
        }
        if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
          throw new HttpError(400, 'Enter a valid email address.');
        }
        const member = {
          id: createReference('PMS-M'),
          fullName,
          fullNameTamil,
          mobile,
          email,
          gender,
          guardianRelation,
          guardianName,
          guardianNameTamil,
          dateOfBirth,
          occupation,
          country,
          state: stateName,
          district,
          taluk,
          localBodyType,
          localBodyName,
          assemblyConstituency,
          parliamentaryConstituency,
          corporation,
          municipality,
          townPanchayat,
          street,
          villageArea,
          addressTamil,
          wardNumber,
          panchayat,
          pinCode,
          bloodGroup,
          whatsapp,
          aadhaarEncrypted: encryptField(aadhaarNumber, encryptionKey),
          photoEncrypted: encryptField(photoData, encryptionKey),
          upiTransactionId,
          membershipFee: MEMBERSHIP_FEE_RUPEES,
          paymentStatus: 'Pending verification',
          status: 'Active member',
          createdAt: new Date().toISOString(),
          membershipId: '',
          approvedAt: new Date().toISOString(),
          signatureName,
        };
        await updateState((current) => {
          const year = new Date().getFullYear();
          const existingSequence = current.members.reduce((max, item) => {
            const match = String(item.membershipId || '').match(new RegExp(`^PMS-${year}-(\\d+)$`));
            return match ? Math.max(max, Number(match[1])) : max;
          }, 0);
          current.lastMemberSequence = Math.max(current.lastMemberSequence, existingSequence) + 1;
          member.membershipId = `PMS-${year}-${String(current.lastMemberSequence).padStart(4, '0')}`;
          current.members.unshift(member);
        });
        return jsonResponse(response, 201, {
          success: true,
          reference: member.id,
          membershipId: member.membershipId,
          status: member.status,
          fee: member.membershipFee,
          paymentStatus: member.paymentStatus,
          member: { ...member, aadhaarEncrypted: undefined, photoEncrypted: undefined, photoData },
          message: 'Membership registered. Your membership ID is ready. UPI payment receipt is pending admin verification.',
        });
      }

      if (method === 'POST' && pathname === '/api/member-card/request-otp') {
        if (!deliverMail) {
          throw new HttpError(503, 'Email verification is not configured yet. Please try again later.');
        }
        const address = getClientAddress(request);
        const now = Date.now();
        const attempts = cardOtpRequests.get(address);
        if (attempts && now - attempts.startedAt < CARD_OTP_WINDOW_MS && attempts.count >= CARD_OTP_MAX_REQUESTS) {
          throw new HttpError(429, 'Too many verification requests. Wait 15 minutes and try again.');
        }
        if (!attempts || now - attempts.startedAt >= CARD_OTP_WINDOW_MS) {
          cardOtpRequests.set(address, { startedAt: now, count: 0 });
        }
        const requestLimit = cardOtpRequests.get(address);
        requestLimit.count += 1;
        const body = await readJsonBody(request);
        const membershipId = cleanText(body.membershipId, 'Membership number', 40, { required: true }).toUpperCase();
        if (!/^PMS-\d{4}-\d{4,}$/.test(membershipId)) {
          throw new HttpError(400, 'Enter a valid membership number, such as PMS-2026-0001.');
        }
        const email = cleanText(body.email, 'Email address', 254, { required: true }).toLowerCase();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new HttpError(400, 'Enter a valid email address.');
        const previousChallenge = [...cardOtpChallenges.values()].find((challenge) => (
          challenge.address === address
          && challenge.membershipId === membershipId
          && challenge.email === email
          && challenge.expiresAt > now
          && now - challenge.createdAt < CARD_OTP_COOLDOWN_MS
        ));
        if (previousChallenge) {
          throw new HttpError(429, 'Wait one minute before requesting another verification code.');
        }
        for (const [id, challenge] of cardOtpChallenges) {
          if (challenge.address === address
            && challenge.membershipId === membershipId
            && challenge.email === email) cardOtpChallenges.delete(id);
        }
        const member = state.members.find((item) => (
          String(item.membershipId || '').toUpperCase() === membershipId
          && String(item.email || '').trim().toLowerCase() === email
          && !item.archivedAt
          && !['Inactive', 'Archived'].includes(item.status)
        ));
        const challengeId = randomBytes(24).toString('hex');
        const otp = String(randomInt(100000, 1000000));
        const challenge = {
          address,
          challengeId,
          createdAt: now,
          email,
          expiresAt: now + CARD_OTP_LIFETIME_MS,
          failedAttempts: 0,
          memberId: member?.id || '',
          membershipId,
          otpHash: createHmac('sha256', encryptionKey).update(`${challengeId}:${otp}`).digest('hex'),
          downloadTokenHash: '',
          verifiedAt: 0,
        };
        if (member) {
          try {
            await deliverMail({
              from: process.env.SMTP_FROM || 'info@parayarmahasabai.com',
              to: member.email,
              subject: 'Your Parayar Maha Sabai membership card verification code',
              text: `Your verification code is ${otp}. It expires in 10 minutes. Do not share this code with anyone.`,
            });
          } catch (error) {
            console.error('Membership-card verification email delivery failed.', error.message);
            throw new HttpError(503, 'Email delivery is temporarily unavailable. Please try again later.');
          }
        }
        cardOtpChallenges.set(challengeId, challenge);
        if (cardOtpChallenges.size > 2000) {
          for (const [id, item] of cardOtpChallenges) {
            if (item.expiresAt <= now) cardOtpChallenges.delete(id);
          }
          while (cardOtpChallenges.size > 2000) {
            cardOtpChallenges.delete(cardOtpChallenges.keys().next().value);
          }
        }
        if (cardOtpRequests.size > 1000) {
          for (const [ip, item] of cardOtpRequests) {
            if (now - item.startedAt >= CARD_OTP_WINDOW_MS) cardOtpRequests.delete(ip);
          }
          while (cardOtpRequests.size > 1000) {
            cardOtpRequests.delete(cardOtpRequests.keys().next().value);
          }
        }
        return jsonResponse(response, 202, {
          success: true,
          challengeId,
          message: 'If the membership number and registered email match an active member, a verification code has been sent.',
          expiresIn: CARD_OTP_LIFETIME_MS,
        });
      }

      if (method === 'POST' && pathname === '/api/member-card/verify-otp') {
        const body = await readJsonBody(request);
        const challengeId = cleanText(body.challengeId, 'Verification request', 64, { required: true });
        const otp = cleanText(body.otp, 'Verification code', 6, { required: true });
        if (!/^\d{6}$/.test(otp)) throw new HttpError(400, 'Enter the six-digit verification code.');
        const challenge = cardOtpChallenges.get(challengeId);
        const now = Date.now();
        if (!challenge || challenge.expiresAt <= now || !challenge.memberId) {
          if (challenge) cardOtpChallenges.delete(challengeId);
          throw new HttpError(400, 'The verification code is invalid or expired. Request a new code.');
        }
        if (challenge.failedAttempts >= CARD_OTP_MAX_ATTEMPTS) {
          cardOtpChallenges.delete(challengeId);
          throw new HttpError(429, 'Too many incorrect codes. Request a new verification code.');
        }
        const providedHash = createHmac('sha256', encryptionKey).update(`${challengeId}:${otp}`).digest();
        const expectedHash = Buffer.from(challenge.otpHash, 'hex');
        if (providedHash.length !== expectedHash.length || !timingSafeEqual(providedHash, expectedHash)) {
          challenge.failedAttempts += 1;
          if (challenge.failedAttempts >= CARD_OTP_MAX_ATTEMPTS) cardOtpChallenges.delete(challengeId);
          throw new HttpError(400, 'The verification code is invalid or expired. Request a new code.');
        }
        const downloadToken = randomBytes(32).toString('hex');
        challenge.downloadTokenHash = createHash('sha256').update(downloadToken).digest('hex');
        challenge.verifiedAt = now;
        return jsonResponse(response, 200, {
          success: true,
          downloadToken,
          message: 'Email verified. Your membership card is ready to download.',
        });
      }

      if (method === 'POST' && pathname === '/api/member-card/download') {
        const authorization = request.headers.authorization || '';
        const token = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
        const body = await readJsonBody(request);
        const challengeId = cleanText(body.challengeId, 'Verification request', 64, { required: true });
        const challenge = cardOtpChallenges.get(challengeId);
        const tokenHash = createHash('sha256').update(token).digest('hex');
        const expectedTokenHash = Buffer.from(challenge?.downloadTokenHash || '', 'hex');
        const providedTokenHash = Buffer.from(tokenHash, 'hex');
        if (!challenge
          || !token
          || challenge.expiresAt <= Date.now()
          || !challenge.verifiedAt
          || !challenge.downloadTokenHash
          || expectedTokenHash.length !== providedTokenHash.length
          || !timingSafeEqual(providedTokenHash, expectedTokenHash)) {
          throw new HttpError(401, 'Verify your registered email again to download this card.');
        }
        cardOtpChallenges.delete(challengeId);
        const member = state.members.find((item) => (
          item.id === challenge.memberId
          && !item.archivedAt
          && !['Inactive', 'Archived'].includes(item.status)
        ));
        if (!member) throw new HttpError(404, 'This membership card is no longer available.');
        return jsonResponse(response, 200, {
          success: true,
          member: {
            membershipId: member.membershipId,
            fullName: member.fullName,
            fullNameTamil: member.fullNameTamil || '',
            guardianRelation: member.guardianRelation,
            guardianName: member.guardianName,
            guardianNameTamil: member.guardianNameTamil || '',
            dateOfBirth: member.dateOfBirth,
            bloodGroup: member.bloodGroup,
            mobile: member.mobile,
            occupation: member.occupation,
            address: [member.localBodyName, member.street, member.villageArea, member.taluk, member.district, member.state, member.pinCode].filter(Boolean).join(', '),
            addressTamil: member.addressTamil || '',
            localBodyName: member.localBodyName,
            wardNumber: member.wardNumber,
            taluk: member.taluk,
            district: member.district,
            pinCode: member.pinCode,
            assemblyConstituency: member.assemblyConstituency,
            parliamentaryConstituency: member.parliamentaryConstituency,
            approvedAt: member.approvedAt || member.createdAt,
            photoData: decryptField(member.photoEncrypted, encryptionKey),
          },
        });
      }

      if (method === 'POST' && pathname === '/api/requests') {
        const body = await readJsonBody(request);
        validateConsent(body.consent);
        const name = cleanText(body.name, 'Name', 100, { required: true });
        const mobile = cleanText(body.mobile, 'Mobile number', 18, { required: true }).replaceAll(' ', '');
        const category = cleanText(body.category, 'Service area', 100, { required: true });
        const message = cleanText(body.message, 'How we can help', 1400, { required: true });
        if (!/^(\+91[-]?)?[6-9]\d{9}$/.test(mobile)) {
          throw new HttpError(400, 'Enter a valid 10-digit Indian mobile number.');
        }
        const item = {
          id: createReference('PMS-H'),
          name,
          mobile,
          category,
          message,
          status: 'Received',
          createdAt: new Date().toISOString(),
        };
        await updateState((current) => current.requests.unshift(item));
        return jsonResponse(response, 201, {
          success: true,
          reference: item.id,
          message: 'Your request has been received. Keep this reference to check its status.',
        });
      }

      const trackingMatch = pathname.match(/^\/api\/track\/([A-Z0-9-]{8,40})$/i);
      if (method === 'GET' && trackingMatch) {
        const reference = trackingMatch[1].toUpperCase();
        const item = [...state.members, ...state.requests].find((entry) => entry.id === reference);
        if (!item) throw new HttpError(404, 'No request was found for that reference. Check the code and try again.');
        return jsonResponse(response, 200, {
          success: true,
          reference: item.id,
          type: state.members.includes(item) ? 'Membership application' : 'Community service request',
          status: item.status,
          ...(state.members.includes(item) ? {
            membershipId: item.membershipId,
            paymentStatus: item.paymentStatus,
            fee: item.membershipFee,
          } : {}),
          received: item.createdAt,
          updated: item.updatedAt || item.approvedAt || item.createdAt,
        });
      }

      if (method === 'POST' && pathname === '/api/admin/login') {
        const address = getClientAddress(request);
        const now = Date.now();
        const current = loginAttempts.get(address);
        if (current && now - current.startedAt < LOGIN_WINDOW_MS && current.count >= MAX_LOGIN_ATTEMPTS) {
          throw new HttpError(429, 'Too many sign-in attempts. Wait 15 minutes and try again.');
        }
        if (!current || now - current.startedAt >= LOGIN_WINDOW_MS) {
          loginAttempts.set(address, { startedAt: now, count: 0 });
        }
        const body = await readJsonBody(request);
        if (!equalSecret(body.username, username) || !equalSecret(body.password, password)) {
          const attempts = loginAttempts.get(address);
          attempts.count += 1;
          throw new HttpError(401, 'The username or password is incorrect.');
        }
        loginAttempts.delete(address);
        const token = randomBytes(32).toString('hex');
        sessions.set(token, now + SESSION_DURATION_MS);
        if (loginAttempts.size > 500) {
          for (const [ip, attempt] of loginAttempts) {
            if (now - attempt.startedAt >= LOGIN_WINDOW_MS) loginAttempts.delete(ip);
          }
        }
        return jsonResponse(response, 200, { success: true, token, expiresIn: SESSION_DURATION_MS });
      }

      if (pathname.startsWith('/api/admin/')) {
        requireAdmin(request);

        if (method === 'POST' && pathname === '/api/admin/logout') {
          sessions.delete(sessionToken(request));
          return jsonResponse(response, 200, { success: true });
        }
        if (method === 'GET' && pathname === '/api/admin/overview') {
          return jsonResponse(response, 200, {
            success: true,
            stats: {
              members: state.members.filter((item) => !item.archivedAt).length,
              archivedMembers: state.members.filter((item) => item.archivedAt).length,
              pendingPayments: state.members.filter((item) => !item.archivedAt && item.paymentStatus !== 'Verified').length,
              requests: state.requests.length,
              openRequests: state.requests.filter((item) => !['Resolved', 'Closed'].includes(item.status)).length,
            },
            members: state.members.map((item) => ({
              ...item,
              status: item.status === 'Approved' ? 'Active member' : item.status || 'Active member',
              aadhaarEncrypted: undefined,
              photoEncrypted: undefined,
              photoData: decryptField(item.photoEncrypted, encryptionKey),
            })),
            requests: state.requests,
          });
        }
        if (method === 'POST' && pathname === '/api/admin/members') {
          const body = await readJsonBody(request, MEMBERSHIP_BODY_LIMIT);
          const member = {
            id: createReference('PMS-M'),
            ...validateAdminMember(body, constituencyData, encryptionKey),
            membershipFee: MEMBERSHIP_FEE_RUPEES,
            createdAt: new Date().toISOString(),
            approvedAt: new Date().toISOString(),
            membershipId: '',
          };
          await updateState((current) => {
            const year = new Date().getFullYear();
            const existingSequence = current.members.reduce((max, item) => {
              const match = String(item.membershipId || '').match(new RegExp(`^PMS-${year}-(\\d+)$`));
              return match ? Math.max(max, Number(match[1])) : max;
            }, 0);
            current.lastMemberSequence = Math.max(current.lastMemberSequence, existingSequence) + 1;
            member.membershipId = `PMS-${year}-${String(current.lastMemberSequence).padStart(4, '0')}`;
            current.members.unshift(member);
          });
          return jsonResponse(response, 201, {
            success: true,
            member: {
              ...member,
              aadhaarEncrypted: undefined,
              photoEncrypted: undefined,
              photoData: member.photoEncrypted ? decryptField(member.photoEncrypted, encryptionKey) : '',
            },
          });
        }
        const memberMatch = pathname.match(/^\/api\/admin\/members\/([A-Z0-9-]{8,40})$/i);
        if (method === 'PUT' && memberMatch) {
          const body = await readJsonBody(request, MEMBERSHIP_BODY_LIMIT);
          let updatedMember;
          await updateState((current) => {
            updatedMember = current.members.find((item) => item.id === memberMatch[1].toUpperCase());
            if (!updatedMember) throw new HttpError(404, 'Membership record not found.');
            if (Object.keys(body).length === 1 && Object.hasOwn(body, 'paymentStatus')) {
              if (!ALLOWED_PAYMENT_STATUSES.has(body.paymentStatus)) throw new HttpError(400, 'Choose a valid payment verification status.');
              updatedMember.paymentStatus = body.paymentStatus;
            } else {
              const validated = validateAdminMember(body, constituencyData, encryptionKey, updatedMember);
              Object.assign(updatedMember, validated);
            }
            updatedMember.updatedAt = new Date().toISOString();
          });
          return jsonResponse(response, 200, {
            success: true,
            member: {
              ...updatedMember,
              status: updatedMember.status === 'Approved' ? 'Active member' : updatedMember.status || 'Active member',
              aadhaarEncrypted: undefined,
              photoEncrypted: undefined,
              photoData: decryptField(updatedMember.photoEncrypted, encryptionKey),
            },
          });
        }
        if (method === 'DELETE' && memberMatch) {
          let updatedMember;
          await updateState((current) => {
            updatedMember = current.members.find((item) => item.id === memberMatch[1].toUpperCase());
            if (!updatedMember) throw new HttpError(404, 'Membership record not found.');
            if (updatedMember.archivedAt) throw new HttpError(409, 'This membership record is already archived.');
            updatedMember.archivedAt = new Date().toISOString();
            updatedMember.status = 'Inactive';
            updatedMember.updatedAt = updatedMember.archivedAt;
          });
          return jsonResponse(response, 200, {
            success: true,
            member: {
              ...updatedMember,
              aadhaarEncrypted: undefined,
              photoEncrypted: undefined,
              photoData: updatedMember.photoEncrypted ? decryptField(updatedMember.photoEncrypted, encryptionKey) : '',
            },
          });
        }
        const restoreMatch = pathname.match(/^\/api\/admin\/members\/([A-Z0-9-]{8,40})\/restore$/i);
        if (method === 'POST' && restoreMatch) {
          let updatedMember;
          await updateState((current) => {
            updatedMember = current.members.find((item) => item.id === restoreMatch[1].toUpperCase());
            if (!updatedMember) throw new HttpError(404, 'Membership record not found.');
            if (!updatedMember.archivedAt) throw new HttpError(409, 'This membership record is not archived.');
            delete updatedMember.archivedAt;
            updatedMember.status = 'Active member';
            updatedMember.updatedAt = new Date().toISOString();
          });
          return jsonResponse(response, 200, {
            success: true,
            member: {
              ...updatedMember,
              aadhaarEncrypted: undefined,
              photoEncrypted: undefined,
              photoData: updatedMember.photoEncrypted ? decryptField(updatedMember.photoEncrypted, encryptionKey) : '',
            },
          });
        }
        const requestMatch = pathname.match(/^\/api\/admin\/requests\/([A-Z0-9-]{8,40})$/i);
        if (method === 'PUT' && requestMatch) {
          const body = await readJsonBody(request);
          if (!ALLOWED_REQUEST_STATUSES.has(body.status)) throw new HttpError(400, 'Choose a valid service-request status.');
          let updatedRequest;
          await updateState((current) => {
            updatedRequest = current.requests.find((item) => item.id === requestMatch[1].toUpperCase());
            if (!updatedRequest) throw new HttpError(404, 'Service request not found.');
            updatedRequest.status = body.status;
            updatedRequest.updatedAt = new Date().toISOString();
          });
          return jsonResponse(response, 200, { success: true, request: updatedRequest });
        }
        throw new HttpError(404, 'Admin endpoint not found.');
      }

      if (pathname.startsWith('/api/')) throw new HttpError(404, 'API endpoint not found.');
      if (method !== 'GET' && method !== 'HEAD') throw new HttpError(405, 'Method not allowed.');
      return await serveStatic(response, pathname);
    } catch (error) {
      if (response.headersSent) {
        response.destroy(error);
        return;
      }
      if (!(error instanceof HttpError)) console.error('[Parayar Mahasabai server]', error);
      return jsonResponse(response, error instanceof HttpError ? error.status : 500, {
        success: false,
        message: error instanceof HttpError ? error.message : 'The request could not be completed. Please try again later.',
      });
    }
  });

  server.on('close', () => {
    smtpTransport?.close();
    if (databasePool) void databasePool.end();
  });
  return server;
}

const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  const port = Number(process.env.PORT || 4173);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT must be a valid TCP port.');
  const server = await createAppServer();
  server.listen(port, () => {
    console.log(`Parayar Mahasabai portal listening at http://localhost:${port}`);
    if (process.env.NODE_ENV !== 'production' && !process.env.ADMIN_PASSWORD) {
      console.warn('Local demo admin password: pms-local-demo (set ADMIN_PASSWORD before deployment).');
    }
  });
}
