import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createAppServer } from '../server.mjs';

const TEST_PNG = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jWZkAAAAASUVORK5CYII=';
let directory;
let server;
let origin;
const sentEmails = [];

before(async () => {
  directory = await mkdtemp(path.join(os.tmpdir(), 'pms-portal-test-'));
  server = await createAppServer({
    dataFile: path.join(directory, 'records.json'),
    username: 'test-admin',
    password: 'test-admin-password',
    production: false,
    sendMail: async (message) => sentEmails.push(message),
  });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  origin = `http://127.0.0.1:${server.address().port}`;
});

after(async () => {
  if (server) {
    server.closeAllConnections();
    await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  }
  if (directory) await rm(directory, { recursive: true, force: true });
});

async function json(pathname, options) {
  const response = await fetch(`${origin}${pathname}`, options);
  return { response, body: await response.json() };
}

function validMember(overrides = {}) {
  return {
    fullName: 'Test Member',
    fullNameTamil: 'வெ. சுரேஷ்',
    mobile: '9876543210',
    email: 'member@example.test',
    gender: 'Other',
    guardianRelation: 'S/o',
    guardianName: 'Test Parent',
    guardianNameTamil: 'சோதனை பெற்றோர்',
    dateOfBirth: '1990-01-01',
    occupation: 'Teacher',
    country: 'India',
    state: 'Tamil Nadu',
    district: 'Tirunelveli',
    taluk: 'Tirunelveli',
    localBodyType: 'villagePanchayat',
    assemblyConstituency: 'Tirunelveli',
    parliamentaryConstituency: 'Tirunelveli',
    corporation: '',
    municipality: '',
    townPanchayat: '',
    street: '1 Test Street',
    villageArea: 'Test Area',
    addressTamil: '1 சோதனை தெரு, சோதனை பகுதி, திருநெல்வேலி - 627001',
    wardNumber: '',
    panchayat: 'Test Village Panchayat',
    pinCode: '627001',
    bloodGroup: 'Unknown',
    whatsapp: '',
    aadhaarNumber: '1234 1234 1234',
    photoData: `data:image/png;base64,${TEST_PNG}`,
    upiTransactionId: 'UPI123456789',
    signatureName: 'Test Member',
    consent: true,
    ...overrides,
  };
}

test('serves the public site with security headers', async () => {
  const response = await fetch(origin);
  assert.equal(response.status, 200);
  assert.match(response.headers.get('content-type'), /text\/html/);
  assert.equal(response.headers.get('x-frame-options'), 'DENY');
  assert.match(await response.text(), /Parayar Maha Sabai/);
});

test('requires complete MySQL settings instead of silently falling back to JSON', async () => {
  const keys = ['DB_HOST', 'DB_USER', 'DB_PASSWORD', 'DB_NAME'];
  const original = Object.fromEntries(keys.map((key) => [key, process.env[key]]));
  for (const key of keys) delete process.env[key];
  process.env.DB_HOST = 'mysql.example.test';
  try {
    await assert.rejects(createAppServer({
      dataFile: path.join(directory, 'partial-database.json'),
      username: 'test-admin',
      password: 'test-admin-password',
      production: false,
    }), /Set DB_HOST, DB_USER, DB_PASSWORD and DB_NAME together/);
  } finally {
    for (const key of keys) {
      if (original[key] === undefined) delete process.env[key];
      else process.env[key] = original[key];
    }
  }
});

test('serves complete Tamil Nadu constituency and postal lookup data', async () => {
  const constituenciesResponse = await fetch(`${origin}/constituency-data.json`);
  assert.equal(constituenciesResponse.status, 200);
  const constituencies = await constituenciesResponse.json();
  assert.equal(constituencies.assemblyConstituencies.length, 234);
  assert.equal(constituencies.parliamentaryConstituencies.length, 39);
  assert.equal(Object.keys(constituencies.parliamentByAssembly).length, 234);
  assert.equal(new Set(constituencies.assemblyConstituencies).size, 234);
  assert.equal(new Set(constituencies.parliamentaryConstituencies).size, 39);
  assert.ok(Object.values(constituencies.parliamentByAssembly)
    .every((name) => constituencies.parliamentaryConstituencies.includes(name)));
  assert.equal(constituencies.parliamentByAssembly['Tirunelveli'], 'Tirunelveli');

  const postalResponse = await fetch(`${origin}/postal-directory.json`);
  assert.equal(postalResponse.status, 200);
  const postal = await postalResponse.json();
  assert.ok(postal.records.length > 10000);
  assert.ok(postal.records.some(([pin]) => pin === '627001'));
  assert.ok(postal.records.every(([pin]) => /^\d{6}$/.test(pin)));
});

test('registers members immediately, protects sensitive fields and verifies payment separately', async () => {
  const submitted = await json('/api/members', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(validMember()),
  });
  assert.equal(submitted.response.status, 201);
  assert.match(submitted.body.reference, /^PMS-M-\d{8}-[A-F0-9]{16}$/);
  assert.match(submitted.body.membershipId, /^PMS-\d{4}-\d{4}$/);
  assert.equal(submitted.body.status, 'Active member');
  assert.equal(submitted.body.paymentStatus, 'Pending verification');
  assert.equal(submitted.body.fee, 500);
  assert.equal(submitted.body.member.aadhaarNumber, undefined);
  assert.equal(submitted.body.member.aadhaarEncrypted, undefined);
  assert.equal(submitted.body.member.photoData, `data:image/png;base64,${TEST_PNG}`);

  const tracking = await json(`/api/track/${submitted.body.reference}`);
  assert.equal(tracking.response.status, 200);
  assert.equal(tracking.body.status, 'Active member');
  assert.equal(tracking.body.type, 'Membership application');
  assert.equal(tracking.body.membershipId, submitted.body.membershipId);
  assert.equal(tracking.body.paymentStatus, 'Pending verification');
  assert.equal('fullName' in tracking.body, false);

  const savedRecords = await readFile(path.join(directory, 'records.json'), 'utf8');
  assert.equal(savedRecords.includes('123412341234'), false);
  assert.equal(savedRecords.includes(`data:image/png;base64,${TEST_PNG}`), false);

  const denied = await json('/api/admin/overview');
  assert.equal(denied.response.status, 401);

  const login = await json('/api/admin/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'test-admin', password: 'test-admin-password' }),
  });
  assert.equal(login.response.status, 200);
  const auth = { Authorization: `Bearer ${login.body.token}`, 'Content-Type': 'application/json' };

  const verified = await json(`/api/admin/members/${submitted.body.reference}`, {
    method: 'PUT',
    headers: auth,
    body: JSON.stringify({ paymentStatus: 'Verified' }),
  });
  assert.equal(verified.response.status, 200);
  assert.equal(verified.body.member.membershipId, submitted.body.membershipId);
  assert.equal(verified.body.member.paymentStatus, 'Verified');
  assert.equal(verified.body.member.aadhaarNumber, undefined);
  assert.equal(verified.body.member.aadhaarEncrypted, undefined);
  assert.equal(verified.body.member.photoData, `data:image/png;base64,${TEST_PNG}`);

  const overview = await json('/api/admin/overview', { headers: auth });
  assert.equal(overview.body.stats.members, 1);
  assert.equal(overview.body.stats.pendingPayments, 0);
  assert.equal(overview.body.members[0].aadhaarNumber, undefined);
  assert.equal(overview.body.members[0].aadhaarEncrypted, undefined);
  assert.equal(overview.body.members[0].photoEncrypted, undefined);
});

test('sends an email OTP and permits a one-time membership-card data download', async () => {
  const registration = await json('/api/members', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(validMember({ fullName: 'Card Download Member', signatureName: 'Card Download Member' })),
  });
  assert.equal(registration.response.status, 201);
  sentEmails.length = 0;
  const requested = await json('/api/member-card/request-otp', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      membershipId: registration.body.membershipId,
      email: 'member@example.test',
    }),
  });
  assert.equal(requested.response.status, 202);
  assert.equal(sentEmails.length, 1);
  assert.equal(sentEmails[0].to, 'member@example.test');
  assert.match(sentEmails[0].text, /expires in 10 minutes/);
  const otp = sentEmails[0].text.match(/\b\d{6}\b/)[0];
  assert.equal(JSON.stringify(requested.body).includes(otp), false);
  assert.equal(requested.body.membershipId, undefined);

  const mismatch = await json('/api/member-card/request-otp', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      membershipId: registration.body.membershipId,
      email: 'wrong@example.test',
    }),
  });
  assert.equal(mismatch.response.status, 202);
  assert.equal(mismatch.body.message, requested.body.message);
  assert.equal(sentEmails.length, 1);

  const invalidCode = await json('/api/member-card/verify-otp', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ challengeId: requested.body.challengeId, otp: '000000' }),
  });
  assert.equal(invalidCode.response.status, 400);

  const verified = await json('/api/member-card/verify-otp', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ challengeId: requested.body.challengeId, otp }),
  });
  assert.equal(verified.response.status, 200);
  assert.equal(verified.body.member, undefined);
  assert.equal(typeof verified.body.downloadToken, 'string');

  const downloaded = await json('/api/member-card/download', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${verified.body.downloadToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ challengeId: requested.body.challengeId }),
  });
  assert.equal(downloaded.response.status, 200);
  assert.equal(downloaded.body.member.membershipId, registration.body.membershipId);
  assert.equal(downloaded.body.member.fullName, 'Card Download Member');
  assert.equal(downloaded.body.member.fullNameTamil, 'வெ. சுரேஷ்');
  assert.equal(downloaded.body.member.guardianNameTamil, 'சோதனை பெற்றோர்');
  assert.equal(downloaded.body.member.addressTamil, '1 சோதனை தெரு, சோதனை பகுதி, திருநெல்வேலி - 627001');
  assert.equal(downloaded.body.member.photoData, `data:image/png;base64,${TEST_PNG}`);
  assert.equal(downloaded.body.member.localBodyName, 'Test Village Panchayat');
  assert.equal(downloaded.body.member.assemblyConstituency, 'Tirunelveli');
  assert.equal(downloaded.body.member.parliamentaryConstituency, 'Tirunelveli');
  assert.equal(downloaded.body.member.district, 'Tirunelveli');
  assert.equal(downloaded.body.member.pinCode, '627001');
  assert.equal('aadhaarNumber' in downloaded.body.member, false);
  assert.equal('aadhaarEncrypted' in downloaded.body.member, false);

  const replay = await json('/api/member-card/download', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${verified.body.downloadToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ challengeId: requested.body.challengeId }),
  });
  assert.equal(replay.response.status, 401);
});

test('allows authenticated member creation, editing, archival and restoration', async () => {
  const denied = await json('/api/admin/members', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(validMember()),
  });
  assert.equal(denied.response.status, 401);

  const login = await json('/api/admin/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'test-admin', password: 'test-admin-password' }),
  });
  const auth = { Authorization: `Bearer ${login.body.token}`, 'Content-Type': 'application/json' };
  const created = await json('/api/admin/members', {
    method: 'POST',
    headers: auth,
    body: JSON.stringify(validMember({ fullName: 'Admin Created Member', photoData: '' })),
  });
  assert.equal(created.response.status, 201);
  assert.equal(created.body.member.fullName, 'Admin Created Member');
  assert.match(created.body.member.membershipId, /^PMS-\d{4}-\d{4}$/);
  assert.equal(created.body.member.aadhaarNumber, undefined);
  assert.equal(created.body.member.aadhaarEncrypted, undefined);
  assert.equal(created.body.member.photoData, '');

  const edited = await json(`/api/admin/members/${created.body.member.id}`, {
    method: 'PUT',
    headers: auth,
    body: JSON.stringify(validMember({
      fullName: 'Updated Member Name',
      mobile: '9876543211',
      district: 'Madurai',
      assemblyConstituency: 'Madurai Central',
      parliamentaryConstituency: 'Madurai',
      taluk: 'Madurai North',
      panchayat: 'Updated Village Panchayat',
      street: '42 Updated Street',
      pinCode: '625001',
      status: 'Inactive',
      paymentStatus: 'Verified',
      aadhaarNumber: '',
    })),
  });
  assert.equal(edited.response.status, 200);
  assert.equal(edited.body.member.fullName, 'Updated Member Name');
  assert.equal(edited.body.member.mobile, '9876543211');
  assert.equal(edited.body.member.photoData, `data:image/png;base64,${TEST_PNG}`);
  assert.equal(edited.body.member.district, 'Madurai');
  assert.equal(edited.body.member.status, 'Inactive');
  assert.equal(edited.body.member.paymentStatus, 'Verified');
  const stored = JSON.parse(await readFile(path.join(directory, 'records.json'), 'utf8'));
  const saved = stored.members.find((member) => member.id === created.body.member.id);
  assert.ok(saved.aadhaarEncrypted);
  assert.equal(JSON.stringify(saved).includes('123412341234'), false);

  const archived = await json(`/api/admin/members/${created.body.member.id}`, {
    method: 'DELETE',
    headers: auth,
  });
  assert.equal(archived.response.status, 200);
  assert.ok(archived.body.member.archivedAt);
  assert.equal(archived.body.member.status, 'Inactive');
  const archivedOverview = await json('/api/admin/overview', { headers: auth });
  assert.equal(archivedOverview.body.stats.members, 2);
  assert.equal(archivedOverview.body.stats.archivedMembers, 1);

  const restored = await json(`/api/admin/members/${created.body.member.id}/restore`, {
    method: 'POST',
    headers: auth,
    body: '{}',
  });
  assert.equal(restored.response.status, 200);
  assert.equal(restored.body.member.archivedAt, undefined);
  assert.equal(restored.body.member.status, 'Active member');

  const invalidEdit = await json(`/api/admin/members/${created.body.member.id}`, {
    method: 'PUT',
    headers: auth,
    body: JSON.stringify(validMember({ parliamentaryConstituency: 'Chennai North' })),
  });
  assert.equal(invalidEdit.response.status, 400);
});

test('validates public help requests and updates their status', async () => {
  const invalid = await json('/api/requests', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'No consent', mobile: '123', consent: false }),
  });
  assert.equal(invalid.response.status, 400);

  const submitted = await json('/api/requests', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: 'Test Neighbour',
      mobile: '9876543210',
      category: 'Income certificate',
      message: 'Which official portal should I use?',
      consent: true,
    }),
  });
  assert.equal(submitted.response.status, 201);
  const login = await json('/api/admin/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'test-admin', password: 'test-admin-password' }),
  });
  const updated = await json(`/api/admin/requests/${submitted.body.reference}`, {
    method: 'PUT',
    headers: { Authorization: `Bearer ${login.body.token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ status: 'In progress' }),
  });
  assert.equal(updated.response.status, 200);
  assert.equal(updated.body.request.status, 'In progress');

  const tracked = await json(`/api/track/${submitted.body.reference}`);
  assert.equal(tracked.body.status, 'In progress');
});

test('rejects invalid member data and traversal outside the public directory', async () => {
  const invalid = await json('/api/members', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(validMember({ mobile: '12345' })),
  });
  assert.equal(invalid.response.status, 400);

  const missingTamilDetails = await json('/api/members', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(validMember({ fullNameTamil: '', guardianNameTamil: '', addressTamil: '' })),
  });
  assert.equal(missingTamilDetails.response.status, 400);

  const badPaymentReference = await json('/api/members', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(validMember({ upiTransactionId: 'abc' })),
  });
  assert.equal(badPaymentReference.response.status, 400);

  const badPhoto = await json('/api/members', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(validMember({ photoData: 'data:image/png;base64,aGVsbG8=' })),
  });
  assert.equal(badPhoto.response.status, 400);

  const missingLocalBody = await json('/api/members', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(validMember({ panchayat: '' })),
  });
  assert.equal(missingLocalBody.response.status, 400);

  const inconsistentLocalBody = await json('/api/members', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(validMember({ localBodyType: 'municipality', municipality: 'Test Municipality', panchayat: '' })),
  });
  assert.equal(inconsistentLocalBody.response.status, 201);

  const mismatchedConstituencies = await json('/api/members', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(validMember({ parliamentaryConstituency: 'Madurai' })),
  });
  assert.equal(mismatchedConstituencies.response.status, 400);
  assert.match(mismatchedConstituencies.body.message, /matches the selected Assembly constituency/i);

  const impossibleDate = await json('/api/members', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(validMember({ dateOfBirth: '1990-02-31' })),
  });
  assert.equal(impossibleDate.response.status, 400);

  const traversal = await fetch(`${origin}/%2e%2e/server.mjs`);
  assert.equal(traversal.status, 404);
});
